import React from 'react';
import { useSchool } from '../context/SchoolContext';
import { Bell, ChevronRight } from 'lucide-react';
import { Notice } from '../types';

interface NoticeTickerProps {
  lang: 'bn' | 'en';
  onSelectNotice: (notice: Notice) => void;
  onViewAllNotices: () => void;
}

export const NoticeTicker: React.FC<NoticeTickerProps> = ({
  lang,
  onSelectNotice,
  onViewAllNotices
}) => {
  const { notices } = useSchool();
  return (
    <div className="bg-amber-50 border-b border-amber-200/80 text-amber-950 py-2 px-4">
      <div className="max-w-7xl mx-auto flex items-center gap-3">
        {/* Label Badge */}
        <div className="shrink-0 flex items-center gap-1.5 bg-gradient-to-r from-red-600 to-rose-700 text-white text-[11px] font-black px-2.5 py-1 rounded-md uppercase tracking-wider shadow-sm animate-pulse">
          <Bell size={13} className="animate-bounce" />
          <span>{lang === 'bn' ? 'জরুরি বিজ্ঞপ্তি' : 'Latest Alert'}</span>
        </div>

        {/* Ticker Container with Overflow hidden */}
        <div className="overflow-hidden flex-1 relative whitespace-nowrap">
          <div className="animate-marquee flex items-center gap-8 text-xs sm:text-sm font-semibold">
            {notices.map((notice) => (
              <button
                key={notice.id}
                onClick={() => onSelectNotice(notice)}
                className="inline-flex items-center gap-2 hover:text-emerald-700 hover:underline transition cursor-pointer"
              >
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-600"></span>
                <span>{lang === 'bn' ? notice.titleBn : notice.titleEn}</span>
                <span className="text-[11px] text-amber-700 bg-amber-100/80 px-1.5 py-0.5 rounded border border-amber-300">
                  {notice.date}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* All Notices button */}
        <button
          onClick={onViewAllNotices}
          className="shrink-0 text-xs font-bold text-emerald-800 hover:text-emerald-950 flex items-center gap-0.5 hover:underline"
        >
          <span>{lang === 'bn' ? 'সকল' : 'All'}</span>
          <ChevronRight size={14} />
        </button>
      </div>
    </div>
  );
};
