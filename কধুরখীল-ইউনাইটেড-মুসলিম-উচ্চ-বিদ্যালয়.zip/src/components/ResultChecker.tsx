import React, { useState } from 'react';
import { useSchool } from '../context/SchoolContext';
import { StudentResult } from '../types';
import { SchoolLogo } from './SchoolLogo';
import { 
  Search, 
  Printer, 
  Award, 
  CheckCircle, 
  AlertCircle, 
  RotateCcw,
  BookOpen,
  FileBadge
} from 'lucide-react';

interface ResultCheckerProps {
  lang: 'bn' | 'en';
}

export const ResultChecker: React.FC<ResultCheckerProps> = ({ lang }) => {
  const { results, schoolInfo } = useSchool();
  const [selectedClass, setSelectedClass] = useState<string>('১০ম শ্রেণি');
  const [selectedExam, setSelectedExam] = useState<string>('Test (SSC)');
  const [selectedYear, setSelectedYear] = useState<string>('২০২৬');
  const [rollInput, setRollInput] = useState<string>('');
  const [searchedResult, setSearchedResult] = useState<StudentResult | null>(null);
  const [errorMessage, setErrorMessage] = useState<string>('');
  const [hasSearched, setHasSearched] = useState<boolean>(false);

  // Normalize Bengali/English numerals
  const normalizeDigits = (str: string): string => {
    const banglaToEnglish: { [key: string]: string } = {
      '০': '0', '১': '1', '২': '2', '৩': '3', '৪': '4',
      '৫': '5', '৬': '6', '৭': '7', '৮': '8', '৯': '9'
    };
    return str.replace(/[০-৯]/g, (w) => banglaToEnglish[w] || w).trim();
  };

  const handleSearch = (customRoll?: string) => {
    const queryRoll = customRoll !== undefined ? customRoll : rollInput;
    setErrorMessage('');
    setHasSearched(true);

    if (!queryRoll.trim()) {
      setErrorMessage(lang === 'bn' ? 'অনুগ্রহ করে রোল নম্বর প্রদান করুন।' : 'Please enter student roll number.');
      setSearchedResult(null);
      return;
    }

    const normalizedQuery = normalizeDigits(queryRoll);

    const found = results.find((res) => {
      const normalizedResRoll = normalizeDigits(res.rollNo);
      return normalizedResRoll === normalizedQuery;
    });

    if (found) {
      setSearchedResult(found);
    } else {
      setSearchedResult(null);
      setErrorMessage(
        lang === 'bn' 
          ? `রোল নং "${queryRoll}" এর জন্য কোনো ফলাফল পাওয়া যায়নি। নমুনা রোল যেমন ১০১, ১০২, ২০১, ৩০১ বা ১০৫ দিয়ে চেষ্টা করুন।` 
          : `No result record found for Roll: "${queryRoll}". Try sample rolls like 101, 102, 201, 301, 105.`
      );
    }
  };

  const handleQuickTest = (roll: string, cls: string) => {
    setRollInput(roll);
    setSelectedClass(cls);
    handleSearch(roll);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <section id="results" className="py-14 sm:py-20 bg-slate-50 border-b border-slate-200">
      <div className="max-w-5xl mx-auto px-4 sm:px-8">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-10">
          <span className="text-xs font-bold uppercase tracking-wider text-emerald-800 bg-emerald-100 px-3 py-1 rounded-full border border-emerald-300">
            {lang === 'bn' ? 'অনলাইন ফলাফল পোর্টাল' : 'Online Results Portal'}
          </span>
          <h2 className="font-bengali-serif text-2xl sm:text-4xl font-black text-slate-900 mt-2">
            {lang === 'bn' ? 'পরীক্ষার ফলাফল ও মার্কশিট অনুসন্ধান' : 'Student Result & Marksheet Lookup'}
          </h2>
          <p className="text-slate-600 text-xs sm:text-sm mt-2">
            {lang === 'bn'
              ? 'শ্রেণি, পরীক্ষার নাম এবং রোল নম্বর প্রদান করে তাৎক্ষণিক নম্বরপত্র বা প্রগ্রেস রিপোর্ট কার্ড ডাউনলোড ও প্রিন্ট করুন।'
              : 'Enter student roll number, examination, and class to view or print official grade sheets.'}
          </p>
          <div className="w-16 h-1 bg-amber-500 mx-auto mt-3 rounded-full"></div>
        </div>

        {/* Search Filter Card */}
        <div className="bg-white rounded-2xl shadow-md border border-slate-200 p-6 sm:p-8 mb-8 no-print">
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
            {/* Class Selection */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                {lang === 'bn' ? 'শ্রেণি নির্বাচন' : 'Class'}
              </label>
              <select
                value={selectedClass}
                onChange={(e) => setSelectedClass(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2.5 text-xs sm:text-sm font-semibold focus:outline-none focus:border-emerald-600"
              >
                <option value="১০ম শ্রেণি">১০ম শ্রেণি (Class 10)</option>
                <option value="৯ম শ্রেণি">৯ম শ্রেণি (Class 9)</option>
                <option value="৮ম শ্রেণি">৮ম শ্রেণি (Class 8)</option>
                <option value="৭ম শ্রেণি">৭ম শ্রেণি (Class 7)</option>
                <option value="৬ষ্ঠ শ্রেণি">৬ষ্ঠ শ্রেণি (Class 6)</option>
              </select>
            </div>

            {/* Exam Selection */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                {lang === 'bn' ? 'পরীক্ষার নাম' : 'Examination'}
              </label>
              <select
                value={selectedExam}
                onChange={(e) => setSelectedExam(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2.5 text-xs sm:text-sm font-semibold focus:outline-none focus:border-emerald-600"
              >
                <option value="Test (SSC)">টেস্ট / নির্বাচনী পরীক্ষা (SSC Test)</option>
                <option value="Annual">বার্ষিক মূল্যায়ন পরীক্ষা (Annual)</option>
                <option value="Half-Yearly">অর্ধবার্ষিক পরীক্ষা (Half-Yearly)</option>
                <option value="Pre-Test">প্রাক-নির্বাচনী পরীক্ষা (Pre-Test)</option>
              </select>
            </div>

            {/* Exam Year */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                {lang === 'bn' ? 'পরীক্ষার বছর' : 'Year'}
              </label>
              <select
                value={selectedYear}
                onChange={(e) => setSelectedYear(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2.5 text-xs sm:text-sm font-semibold focus:outline-none focus:border-emerald-600"
              >
                <option value="২০২৬">২০২৬ (2026)</option>
                <option value="২০২৫">২০২৫ (2025)</option>
              </select>
            </div>

            {/* Roll Number Input */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                {lang === 'bn' ? 'শিক্ষার্থীর রোল নং' : 'Student Roll No.'}
              </label>
              <input
                type="text"
                value={rollInput}
                onChange={(e) => setRollInput(e.target.value)}
                placeholder={lang === 'bn' ? 'যেমন: ১০১ বা 101' : 'e.g. 101'}
                className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2.5 text-xs sm:text-sm font-semibold focus:outline-none focus:border-emerald-600"
                onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
              />
            </div>
          </div>

          {/* Quick Demo Roll Pill Buttons */}
          <div className="flex flex-wrap items-center gap-2 mt-4 pt-3 border-t border-slate-100 text-xs">
            <span className="text-slate-500 font-semibold">{lang === 'bn' ? 'দ্রুত টেস্ট রোল:' : 'Quick Demo Rolls:'}</span>
            <button
              onClick={() => handleQuickTest('১০১', '১০ম শ্রেণি')}
              className="px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 rounded-md border border-emerald-200 font-bold transition"
            >
              ১০১ (১০ম বিজ্ঞান - GPA 5.00)
            </button>
            <button
              onClick={() => handleQuickTest('১০২', '১০ম শ্রেণি')}
              className="px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 rounded-md border border-emerald-200 font-bold transition"
            >
              ১০২ (১০ম বিজ্ঞান - GPA 4.89)
            </button>
            <button
              onClick={() => handleQuickTest('২০১', '১০ম শ্রেণি')}
              className="px-2.5 py-1 bg-amber-50 hover:bg-amber-100 text-amber-900 rounded-md border border-amber-200 font-bold transition"
            >
              ২০১ (১০ম ব্যবসায় শিক্ষা - GPA 4.67)
            </button>
            <button
              onClick={() => handleQuickTest('৩০১', '৮ম শ্রেণি')}
              className="px-2.5 py-1 bg-blue-50 hover:bg-blue-100 text-blue-900 rounded-md border border-blue-200 font-bold transition"
            >
              ৩০১ (৮ম শ্রেণি - GPA 5.00)
            </button>
          </div>

          {/* Search Button */}
          <div className="mt-5 flex justify-end">
            <button
              onClick={() => handleSearch()}
              className="flex items-center gap-2 bg-emerald-800 hover:bg-emerald-900 text-white font-bold px-6 py-2.5 rounded-xl shadow-md transition"
            >
              <Search size={16} />
              <span>{lang === 'bn' ? 'ফলাফল অনুসন্ধান করুন' : 'Find Marksheet'}</span>
            </button>
          </div>

          {/* Error Message */}
          {errorMessage && (
            <div className="mt-4 p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 text-xs sm:text-sm flex items-center gap-2">
              <AlertCircle size={16} className="shrink-0 text-rose-600" />
              <span>{errorMessage}</span>
            </div>
          )}
        </div>

        {/* Official Marksheet Presentation */}
        {searchedResult && (
          <div id="printable-section" className="bg-white rounded-3xl shadow-xl border-2 border-emerald-900/30 overflow-hidden p-6 sm:p-10 relative">
            {/* Background Watermark Crest */}
            <div className="absolute inset-0 flex items-center justify-center opacity-[0.03] pointer-events-none">
              <SchoolLogo size={400} />
            </div>

            {/* Print action header (no print) */}
            <div className="flex items-center justify-between pb-6 mb-6 border-b border-slate-200 no-print">
              <div className="flex items-center gap-2 text-emerald-800 font-bold text-sm">
                <CheckCircle size={18} className="text-emerald-600" />
                <span>{lang === 'bn' ? 'অফিসিয়াল নম্বরপত্র প্রস্তুত রয়েছে' : 'Official Marksheet Ready'}</span>
              </div>
              <button
                onClick={handlePrint}
                className="flex items-center gap-2 bg-slate-900 hover:bg-emerald-950 text-white px-4 py-2 rounded-xl text-xs font-bold shadow-md transition"
              >
                <Printer size={15} />
                <span>{lang === 'bn' ? 'প্রিন্ট / ডাউনলোড পিডিএফ' : 'Print / Download PDF'}</span>
              </button>
            </div>

            {/* Marksheet Official Header */}
            <div className="text-center pb-6 border-b-2 border-emerald-900/20">
              <div className="flex items-center justify-center gap-3 mb-2">
                <SchoolLogo size={70} />
                <div className="text-left">
                  <h3 className="font-bengali-serif text-xl sm:text-2xl font-black text-emerald-950">
                    {lang === 'bn' ? schoolInfo.nameBn : schoolInfo.nameEn}
                  </h3>
                  <p className="text-xs text-slate-600 font-medium">
                    {lang === 'bn' ? schoolInfo.addressBn : schoolInfo.addressEn}
                  </p>
                  <p className="text-[11px] font-bold text-emerald-900">
                    EIIN: {schoolInfo.eiinEn} • {lang === 'bn' ? schoolInfo.boardBn : schoolInfo.boardEn}
                  </p>
                </div>
              </div>

              <div className="inline-block bg-emerald-900 text-amber-300 font-black text-xs sm:text-sm px-6 py-1 rounded-full uppercase tracking-wider mt-2">
                {lang === 'bn' ? 'একাডেমিক ট্রান্সক্রিপ্ট / প্রগ্রেস রিপোর্ট' : 'ACADEMIC TRANSCRIPT / PROGRESS REPORT'}
              </div>
            </div>

            {/* Student Info Metadata Table */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 my-6 bg-slate-50/80 p-4 rounded-xl border border-slate-200 text-xs sm:text-sm">
              <div>
                <span className="text-slate-400 text-[11px] block">শিক্ষার্থীর নাম:</span>
                <span className="font-bold text-slate-900">{searchedResult.studentNameBn}</span>
                <span className="text-slate-500 text-[11px] block font-mono">({searchedResult.studentNameEn})</span>
              </div>
              <div>
                <span className="text-slate-400 text-[11px] block">পিতার নাম:</span>
                <span className="font-semibold text-slate-800">{searchedResult.fatherNameBn}</span>
              </div>
              <div>
                <span className="text-slate-400 text-[11px] block">মাতার নাম:</span>
                <span className="font-semibold text-slate-800">{searchedResult.motherNameBn}</span>
              </div>
              <div>
                <span className="text-slate-400 text-[11px] block">শ্রেণি ও শাখা:</span>
                <span className="font-bold text-emerald-900">{searchedResult.classGrade} ({searchedResult.section})</span>
              </div>
              <div>
                <span className="text-slate-400 text-[11px] block">রোল নম্বর:</span>
                <span className="font-bold text-slate-900 font-mono text-sm">{searchedResult.rollNo}</span>
              </div>
              <div>
                <span className="text-slate-400 text-[11px] block">রেজিস্ট্রেশন নং:</span>
                <span className="font-semibold text-slate-700 font-mono text-xs">{searchedResult.regNo}</span>
              </div>
            </div>

            {/* Subject-Wise Marks & Grade Table */}
            <div className="overflow-x-auto border border-slate-200 rounded-xl mb-6">
              <table className="w-full text-xs sm:text-sm text-left">
                <thead className="bg-emerald-950 text-white font-bold">
                  <tr>
                    <th className="py-2.5 px-3">বিষয় কোড</th>
                    <th className="py-2.5 px-3">বিষয়ের নাম</th>
                    <th className="py-2.5 px-3 text-center">পূর্ণমান</th>
                    <th className="py-2.5 px-3 text-center">প্রাপ্ত নম্বর</th>
                    <th className="py-2.5 px-3 text-center">লেটার গ্রেড</th>
                    <th className="py-2.5 px-3 text-center">গ্রেড পয়েন্ট</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 font-medium">
                  {searchedResult.subjects.map((sub, idx) => (
                    <tr key={idx} className={idx % 2 === 0 ? 'bg-white' : 'bg-slate-50/60'}>
                      <td className="py-2 px-3 font-mono text-slate-500">{sub.code}</td>
                      <td className="py-2 px-3 font-semibold text-slate-800">
                        {lang === 'bn' ? sub.subjectNameBn : sub.subjectNameEn}
                      </td>
                      <td className="py-2 px-3 text-center text-slate-600">{sub.totalMarks}</td>
                      <td className="py-2 px-3 text-center font-bold text-slate-900">{sub.obtainedMarks}</td>
                      <td className="py-2 px-3 text-center font-black text-emerald-800">{sub.letterGrade}</td>
                      <td className="py-2 px-3 text-center font-bold font-mono text-slate-800">{sub.gradePoint.toFixed(1)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* GPA Summary Card */}
            <div className="bg-gradient-to-r from-emerald-900 to-emerald-800 text-white rounded-2xl p-5 flex flex-wrap items-center justify-between gap-4 mb-8">
              <div className="space-y-1">
                <span className="text-amber-300 text-xs font-bold uppercase tracking-wider">সার্বিক মূল্যায়ন ফলাফল</span>
                <h4 className="text-xl sm:text-2xl font-black">
                  অবস্থা: <span className="text-emerald-300">কৃতকার্য ({searchedResult.resultStatus})</span>
                </h4>
              </div>

              <div className="flex items-center gap-6">
                <div className="text-center bg-emerald-950/60 px-4 py-2 rounded-xl border border-emerald-700">
                  <span className="text-slate-300 text-[10px] block font-bold uppercase">প্রাপ্ত লেটার গ্রেড</span>
                  <span className="text-2xl font-black text-amber-300">{searchedResult.overallGrade}</span>
                </div>
                <div className="text-center bg-emerald-950/60 px-5 py-2 rounded-xl border border-amber-400">
                  <span className="text-slate-300 text-[10px] block font-bold uppercase">জিপিএ (GPA)</span>
                  <span className="text-2xl sm:text-3xl font-black text-amber-400 font-mono">
                    {searchedResult.gpa.toFixed(2)}
                  </span>
                </div>
              </div>
            </div>

            {/* Official Signatures */}
            <div className="pt-10 grid grid-cols-3 gap-4 text-center text-xs text-slate-600">
              <div>
                <div className="w-28 mx-auto border-b border-slate-400 mb-1"></div>
                <span className="font-semibold text-slate-700 block">শ্রেণি শিক্ষকের স্বাক্ষর</span>
                <span className="text-[10px] text-slate-400">তারিখ: {new Date().toLocaleDateString('bn-BD')}</span>
              </div>
              <div>
                <div className="w-28 mx-auto border-b border-slate-400 mb-1"></div>
                <span className="font-semibold text-slate-700 block">পরীক্ষা নিয়ন্ত্রক</span>
                <span className="text-[10px] text-slate-400">কধুরখীল ইউ. মু. উচ্চ বিদ্যালয়</span>
              </div>
              <div>
                <div className="w-32 mx-auto border-b-2 border-emerald-900 mb-1"></div>
                <span className="font-bold text-slate-900 block font-bengali-serif">মোহাম্মদ ইলিয়াছ</span>
                <span className="text-[10px] text-emerald-900 font-bold block">প্রধান শিক্ষক</span>
                <span className="text-[9px] text-slate-400">EIIN: ১০৪১১১</span>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
