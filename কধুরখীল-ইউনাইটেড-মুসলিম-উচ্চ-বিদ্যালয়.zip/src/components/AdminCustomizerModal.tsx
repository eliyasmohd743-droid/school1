import React, { useState } from 'react';
import { useSchool } from '../context/SchoolContext';
import { Teacher, Notice, StudentResult, ClassRoutineDay, GalleryItem } from '../types';
import { 
  X, 
  Settings, 
  Building2, 
  Users, 
  Bell, 
  Award, 
  Calendar, 
  Image as ImageIcon, 
  Palette, 
  Database, 
  Save, 
  Plus, 
  Trash2, 
  Edit3, 
  Upload, 
  RotateCcw, 
  Check, 
  AlertCircle,
  Download,
  FileCode,
  ShieldAlert,
  Sparkles
} from 'lucide-react';

interface AdminCustomizerModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: 'bn' | 'en';
}

export const AdminCustomizerModal: React.FC<AdminCustomizerModalProps> = ({
  isOpen,
  onClose,
  lang
}) => {
  const {
    schoolInfo,
    updateSchoolInfo,
    teachers,
    addTeacher,
    updateTeacher,
    deleteTeacher,
    notices,
    addNotice,
    updateNotice,
    deleteNotice,
    results,
    addOrUpdateResult,
    deleteResult,
    routines,
    updateRoutine,
    gallery,
    addGalleryItem,
    deleteGalleryItem,
    resetAllData,
    exportBackupJson,
    importBackupJson,
    themeColor,
    setThemeColor
  } = useSchool();

  const [activeTab, setActiveTab] = useState<'info' | 'teachers' | 'notices' | 'results' | 'routine' | 'gallery' | 'theme' | 'backup'>('info');

  // Success message toaster
  const [successMsg, setSuccessMsg] = useState<string>('');
  const triggerSuccess = (msg: string) => {
    setSuccessMsg(msg);
    setTimeout(() => setSuccessMsg(''), 3000);
  };

  // State for editing School Info
  const [infoForm, setInfoForm] = useState({ ...schoolInfo });

  // State for Teachers Form
  const [editingTeacher, setEditingTeacher] = useState<Teacher | null>(null);
  const [isAddingTeacher, setIsAddingTeacher] = useState(false);
  const [teacherFormData, setTeacherFormData] = useState<Partial<Teacher>>({
    nameBn: '',
    nameEn: '',
    designationBn: 'সহকারী শিক্ষক',
    designationEn: 'Assistant Teacher',
    departmentBn: 'বিজ্ঞান বিভাগ',
    departmentEn: 'Science Department',
    subjectBn: '',
    subjectEn: '',
    qualificationBn: 'বি.এসসি (সম্মান), বি.এড',
    qualificationEn: 'B.Sc (Hons), B.Ed',
    photoUrl: 'https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&w=600&q=80',
    email: '',
    phone: '+880 1819-000000',
    bloodGroup: 'B+',
    joinDate: '২০২০ খ্রি.',
    bioBn: '',
    bioEn: ''
  });

  // State for Notice Form
  const [editingNotice, setEditingNotice] = useState<Notice | null>(null);
  const [isAddingNotice, setIsAddingNotice] = useState(false);
  const [noticeFormData, setNoticeFormData] = useState<Partial<Notice>>({
    titleBn: '',
    titleEn: '',
    category: 'academic',
    date: new Date().toISOString().split('T')[0],
    isUrgent: false,
    summaryBn: '',
    summaryEn: '',
    contentBn: '',
    contentEn: '',
    authorBn: 'প্রধান শিক্ষক'
  });

  // State for Result Form
  const [editingResult, setEditingResult] = useState<StudentResult | null>(null);
  const [isAddingResult, setIsAddingResult] = useState(false);
  const [resultFormData, setResultFormData] = useState<Partial<StudentResult>>({
    rollNo: '',
    regNo: '202610411100',
    studentNameBn: '',
    studentNameEn: '',
    fatherNameBn: '',
    motherNameBn: '',
    classGrade: '১০ম শ্রেণি',
    section: 'ক (বিজ্ঞান)',
    group: 'Science',
    examType: 'Test (SSC)',
    examYear: '২০২৬',
    gpa: 5.00,
    overallGrade: 'A+',
    resultStatus: 'Passed',
    subjects: [
      { code: '101', subjectNameBn: 'বাংলা', subjectNameEn: 'Bangla', totalMarks: 100, obtainedMarks: 85, letterGrade: 'A+', gradePoint: 5.0 },
      { code: '107', subjectNameBn: 'ইংরেজি', subjectNameEn: 'English', totalMarks: 100, obtainedMarks: 82, letterGrade: 'A+', gradePoint: 5.0 },
      { code: '109', subjectNameBn: 'গণিত', subjectNameEn: 'Mathematics', totalMarks: 100, obtainedMarks: 90, letterGrade: 'A+', gradePoint: 5.0 }
    ]
  });

  // State for Gallery Form
  const [isAddingGallery, setIsAddingGallery] = useState(false);
  const [galleryFormData, setGalleryFormData] = useState<Partial<GalleryItem>>({
    titleBn: '',
    titleEn: '',
    category: 'campus',
    imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/c/cf/Parbati_Charan_Dhigi.jpg/800px-Parbati_Charan_Dhigi.jpg',
    date: '২০২৬',
    captionBn: ''
  });

  // State for JSON backup import
  const [importJsonText, setImportJsonText] = useState('');

  if (!isOpen) return null;

  const handleSaveInfo = (e: React.FormEvent) => {
    e.preventDefault();
    updateSchoolInfo(infoForm);
    triggerSuccess('প্রাতিষ্ঠানিক তথ্য সফলভাবে আপডেট হয়েছে!');
  };

  const handleSaveTeacher = (e: React.FormEvent) => {
    e.preventDefault();
    if (!teacherFormData.nameBn) return;
    
    if (editingTeacher) {
      updateTeacher({ ...editingTeacher, ...(teacherFormData as Teacher) });
      triggerSuccess('শিক্ষকের তথ্য হালনাগাদ করা হয়েছে!');
    } else {
      const newTeacher: Teacher = {
        ...(teacherFormData as Teacher),
        id: `t-custom-${Date.now()}`
      };
      addTeacher(newTeacher);
      triggerSuccess('নতুন শিক্ষক সফলভাবে যুক্ত হয়েছে!');
    }
    setEditingTeacher(null);
    setIsAddingTeacher(false);
  };

  const handleSaveNotice = (e: React.FormEvent) => {
    e.preventDefault();
    if (!noticeFormData.titleBn) return;

    if (editingNotice) {
      updateNotice({ ...editingNotice, ...(noticeFormData as Notice) });
      triggerSuccess('নোটিশ সফলভাবে হালনাগাদ হয়েছে!');
    } else {
      const newNotice: Notice = {
        ...(noticeFormData as Notice),
        id: `n-${Date.now()}`
      };
      addNotice(newNotice);
      triggerSuccess('নতুন নোটিশ প্রকাশিত হয়েছে!');
    }
    setEditingNotice(null);
    setIsAddingNotice(false);
  };

  const handleSaveResult = (e: React.FormEvent) => {
    e.preventDefault();
    if (!resultFormData.rollNo || !resultFormData.studentNameBn) return;

    addOrUpdateResult(resultFormData as StudentResult);
    triggerSuccess('শিক্ষার্থীর পরীক্ষার ফলাফল সংরক্ষিত হয়েছে!');
    setEditingResult(null);
    setIsAddingResult(false);
  };

  const handleSaveGallery = (e: React.FormEvent) => {
    e.preventDefault();
    if (!galleryFormData.titleBn || !galleryFormData.imageUrl) return;

    const newItem: GalleryItem = {
      ...(galleryFormData as GalleryItem),
      id: `g-${Date.now()}`
    };
    addGalleryItem(newItem);
    triggerSuccess('নতুন ছবি সফলভাবে গ্যালারিতে যুক্ত হয়েছে!');
    setIsAddingGallery(false);
    setGalleryFormData({
      titleBn: '',
      titleEn: '',
      category: 'campus',
      imageUrl: '',
      date: '২০২৬',
      captionBn: ''
    });
  };

  const handleTeacherPhotoFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (uploadEvent) => {
        const result = uploadEvent.target?.result as string;
        if (result) {
          setTeacherFormData({ ...teacherFormData, photoUrl: result });
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleGalleryPhotoFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (uploadEvent) => {
        const result = uploadEvent.target?.result as string;
        if (result) {
          setGalleryFormData({ ...galleryFormData, imageUrl: result });
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleExport = () => {
    const jsonStr = exportBackupJson();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `kadhurkhil-school-backup-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
    triggerSuccess('সম্পূর্ণ ব্যাকআপ ফাইল ডাউনলোড সম্পন্ন হয়েছে!');
  };

  const handleImport = () => {
    if (!importJsonText.trim()) return;
    const success = importBackupJson(importJsonText.trim());
    if (success) {
      triggerSuccess('ব্যাকআপ সফলভাবে রিস্টোর করা হয়েছে!');
      setImportJsonText('');
    } else {
      alert('অবৈধ ব্যাকআপ ফাইল। অনুগ্রহ করে সঠিক JSON ফরম্যাট প্রদান করুন।');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/70 backdrop-blur-sm animate-fadeIn">
      <div 
        className="bg-white rounded-3xl max-w-5xl w-full h-[92vh] shadow-2xl border border-slate-300 flex flex-col overflow-hidden animate-scaleUp"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Top Header */}
        <div className="bg-gradient-to-r from-emerald-950 via-emerald-900 to-slate-900 text-white px-6 py-4 flex items-center justify-between border-b border-emerald-800 shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-amber-500 text-slate-950 rounded-xl shadow-md">
              <Settings size={22} className="animate-spin-slow" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bengali-serif text-lg sm:text-xl font-bold">
                  {lang === 'bn' ? 'ওয়েবসাইট কাস্টমাইজেশন ও অ্যাডমিন প্যানেল' : 'Full Customization Control Panel'}
                </h3>
                <span className="bg-amber-400 text-slate-950 font-black text-[10px] px-2 py-0.5 rounded-full uppercase">
                  লাইভ এডিটর
                </span>
              </div>
              <p className="text-xs text-emerald-200">
                {lang === 'bn' 
                  ? 'সকল তথ্য, শিক্ষক, ফলাফল, নোটিশ, রুটিন ও ছবি তাৎক্ষণিক পরিবর্তন ও সংরক্ষণ করুন' 
                  : 'Customize all school data, faculty, notices, results and routines with persistence'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition"
            aria-label="Close"
          >
            <X size={20} />
          </button>
        </div>

        {/* Success Alert Banner */}
        {successMsg && (
          <div className="bg-emerald-600 text-white text-xs font-bold py-2 px-6 flex items-center justify-between animate-fadeIn shrink-0">
            <span className="flex items-center gap-2">
              <Check size={16} />
              <span>{successMsg}</span>
            </span>
            <button onClick={() => setSuccessMsg('')}><X size={14} /></button>
          </div>
        )}

        {/* Main Body with Sidebar Tabs */}
        <div className="flex-1 flex flex-col md:flex-row overflow-hidden bg-slate-100">
          {/* Sidebar Nav Tabs */}
          <div className="w-full md:w-64 bg-slate-900 text-slate-300 p-3 space-y-1 overflow-y-auto shrink-0 border-r border-slate-800 text-xs font-semibold">
            <div className="px-3 py-2 text-[10px] font-bold uppercase tracking-wider text-slate-400">
              কাস্টমাইজেশন মডিউল
            </div>

            <button
              onClick={() => setActiveTab('info')}
              className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl transition ${
                activeTab === 'info' ? 'bg-emerald-700 text-white font-bold shadow-sm' : 'hover:bg-slate-800'
              }`}
            >
              <Building2 size={16} className="text-amber-400" />
              <span>স্কুল পরিচিতি ও যোগাযোগ</span>
            </button>

            <button
              onClick={() => setActiveTab('teachers')}
              className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl transition ${
                activeTab === 'teachers' ? 'bg-emerald-700 text-white font-bold shadow-sm' : 'hover:bg-slate-800'
              }`}
            >
              <Users size={16} className="text-amber-400" />
              <span>শিক্ষক ও স্টাফ পরিচালনা ({teachers.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('notices')}
              className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl transition ${
                activeTab === 'notices' ? 'bg-emerald-700 text-white font-bold shadow-sm' : 'hover:bg-slate-800'
              }`}
            >
              <Bell size={16} className="text-amber-400" />
              <span>নোটিশ ও বিজ্ঞপ্তি ({notices.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('results')}
              className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl transition ${
                activeTab === 'results' ? 'bg-emerald-700 text-white font-bold shadow-sm' : 'hover:bg-slate-800'
              }`}
            >
              <Award size={16} className="text-amber-400" />
              <span>পরীক্ষার ফলাফল ডাটাবেজ ({results.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('routine')}
              className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl transition ${
                activeTab === 'routine' ? 'bg-emerald-700 text-white font-bold shadow-sm' : 'hover:bg-slate-800'
              }`}
            >
              <Calendar size={16} className="text-amber-400" />
              <span>সাপ্তাহিক ক্লাস রুটিন</span>
            </button>

            <button
              onClick={() => setActiveTab('gallery')}
              className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl transition ${
                activeTab === 'gallery' ? 'bg-emerald-700 text-white font-bold shadow-sm' : 'hover:bg-slate-800'
              }`}
            >
              <ImageIcon size={16} className="text-amber-400" />
              <span>চিত্রশালা ও ছবি ({gallery.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('theme')}
              className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl transition ${
                activeTab === 'theme' ? 'bg-emerald-700 text-white font-bold shadow-sm' : 'hover:bg-slate-800'
              }`}
            >
              <Palette size={16} className="text-amber-400" />
              <span>থিম ও কালার স্কিম</span>
            </button>

            <button
              onClick={() => setActiveTab('backup')}
              className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl transition ${
                activeTab === 'backup' ? 'bg-emerald-700 text-white font-bold shadow-sm' : 'hover:bg-slate-800'
              }`}
            >
              <Database size={16} className="text-amber-400" />
              <span>ব্যাকআপ, এক্সপোর্ট ও রিস্টোর</span>
            </button>
          </div>

          {/* Tab Content Panel */}
          <div className="flex-1 p-6 overflow-y-auto bg-white">
            {/* TAB 1: SCHOOL INFO */}
            {activeTab === 'info' && (
              <form onSubmit={handleSaveInfo} className="space-y-6 max-w-3xl">
                <div>
                  <h4 className="font-bengali-serif text-lg font-bold text-slate-900">
                    প্রাতিষ্ঠানিক মৌলিক তথ্য ও ঠিকানা
                  </h4>
                  <p className="text-xs text-slate-500">
                    এখানে করা যেকোনো পরিবর্তন ওয়েবসাইটের ব্যানার, ফুটার ও মার্কশিটে সরাসরি দৃশ্যমান হবে।
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">বিদ্যালয়ের নাম (বাংলায়) *</label>
                    <input
                      type="text"
                      value={infoForm.nameBn}
                      onChange={(e) => setInfoForm({ ...infoForm, nameBn: e.target.value })}
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 focus:outline-none focus:border-emerald-600"
                      required
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">বিদ্যালয়ের নাম (ইংরেজিতে) *</label>
                    <input
                      type="text"
                      value={infoForm.nameEn}
                      onChange={(e) => setInfoForm({ ...infoForm, nameEn: e.target.value })}
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 focus:outline-none focus:border-emerald-600"
                      required
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">EIIN নম্বর *</label>
                    <input
                      type="text"
                      value={infoForm.eiinEn}
                      onChange={(e) => setInfoForm({ ...infoForm, eiinEn: e.target.value, eiin: e.target.value })}
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 font-mono font-bold focus:outline-none focus:border-emerald-600"
                      required
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">বিদ্যালয় কোড</label>
                    <input
                      type="text"
                      value={infoForm.schoolCodeEn}
                      onChange={(e) => setInfoForm({ ...infoForm, schoolCodeEn: e.target.value, schoolCode: e.target.value })}
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 font-mono font-bold focus:outline-none focus:border-emerald-600"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">মোবাইল ফোন (হেল্পলাইন)</label>
                    <input
                      type="text"
                      value={infoForm.phone}
                      onChange={(e) => setInfoForm({ ...infoForm, phone: e.target.value })}
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 focus:outline-none focus:border-emerald-600"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">অফিসিয়াল ইমেইল</label>
                    <input
                      type="email"
                      value={infoForm.email}
                      onChange={(e) => setInfoForm({ ...infoForm, email: e.target.value })}
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 focus:outline-none focus:border-emerald-600"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block font-bold text-slate-700 mb-1">বিদ্যালয়ের পূর্ণ ঠিকানা *</label>
                    <input
                      type="text"
                      value={infoForm.addressBn}
                      onChange={(e) => setInfoForm({ ...infoForm, addressBn: e.target.value })}
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 focus:outline-none focus:border-emerald-600"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block font-bold text-slate-700 mb-1">বিদ্যালয়ের মূল বাণী / নীতিবাক্য (Motto)</label>
                    <input
                      type="text"
                      value={infoForm.mottoBn}
                      onChange={(e) => setInfoForm({ ...infoForm, mottoBn: e.target.value })}
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 focus:outline-none focus:border-emerald-600"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block font-bold text-slate-700 mb-1">অফিসিয়াল ফেসবুক পেজ লিংক</label>
                    <input
                      type="url"
                      value={infoForm.facebookPage}
                      onChange={(e) => setInfoForm({ ...infoForm, facebookPage: e.target.value })}
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 font-mono text-[11px] focus:outline-none focus:border-emerald-600"
                    />
                  </div>
                </div>

                <div className="pt-4 flex justify-end">
                  <button
                    type="submit"
                    className="flex items-center gap-2 bg-emerald-800 hover:bg-emerald-900 text-white font-bold px-6 py-2.5 rounded-xl shadow-md transition"
                  >
                    <Save size={16} />
                    <span>পরিবর্তন সংরক্ষণ করুন</span>
                  </button>
                </div>
              </form>
            )}

            {/* TAB 2: TEACHERS MANAGEMENT */}
            {activeTab === 'teachers' && (
              <div className="space-y-6">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-200">
                  <div>
                    <h4 className="font-bengali-serif text-lg font-bold text-slate-900">
                      শিক্ষক ও কর্মচারীবৃন্দ ব্যবস্থাপনা
                    </h4>
                    <p className="text-xs text-slate-500">
                      নতুন শিক্ষক যোগ করুন, প্রোফাইল ছবি ও তথ্য আপডেট করুন বা মুছে ফেলুন।
                    </p>
                  </div>

                  {!isAddingTeacher && !editingTeacher && (
                    <button
                      onClick={() => {
                        setIsAddingTeacher(true);
                        setEditingTeacher(null);
                        setTeacherFormData({
                          nameBn: '',
                          nameEn: '',
                          designationBn: 'সহকারী শিক্ষক',
                          designationEn: 'Assistant Teacher',
                          departmentBn: 'বিজ্ঞান বিভাগ',
                          departmentEn: 'Science Department',
                          subjectBn: '',
                          subjectEn: '',
                          qualificationBn: 'বি.এসসি (সম্মান), বি.এড',
                          qualificationEn: 'B.Sc (Hons), B.Ed',
                          photoUrl: 'https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&w=600&q=80',
                          email: '',
                          phone: '+880 1819-000000',
                          bloodGroup: 'B+',
                          joinDate: '২০২৩ খ্রি.',
                          bioBn: '',
                          bioEn: ''
                        });
                      }}
                      className="flex items-center gap-1.5 bg-emerald-800 hover:bg-emerald-900 text-white text-xs font-bold px-4 py-2 rounded-xl shadow-sm transition"
                    >
                      <Plus size={16} />
                      <span>নতুন শিক্ষক যুক্ত করুন</span>
                    </button>
                  )}
                </div>

                {/* Add/Edit Teacher Sub-Form */}
                {(isAddingTeacher || editingTeacher) ? (
                  <form onSubmit={handleSaveTeacher} className="bg-slate-50 p-5 rounded-2xl border border-slate-300 space-y-4 text-xs">
                    <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                      <h5 className="font-bold text-sm text-emerald-950">
                        {editingTeacher ? `শিক্ষক সম্পাদনা: ${editingTeacher.nameBn}` : 'নতুন শিক্ষক নিবন্ধন'}
                      </h5>
                      <button
                        type="button"
                        onClick={() => { setIsAddingTeacher(false); setEditingTeacher(null); }}
                        className="text-slate-500 hover:text-slate-800 font-bold"
                      >
                        বাতিল
                      </button>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block font-bold text-slate-700 mb-1">শিক্ষকের নাম (বাংলা) *</label>
                        <input
                          type="text"
                          value={teacherFormData.nameBn || ''}
                          onChange={(e) => setTeacherFormData({ ...teacherFormData, nameBn: e.target.value })}
                          className="w-full bg-white border border-slate-300 rounded-lg px-3 py-1.5"
                          required
                        />
                      </div>

                      <div>
                        <label className="block font-bold text-slate-700 mb-1">শিক্ষকের নাম (ইংরেজি) *</label>
                        <input
                          type="text"
                          value={teacherFormData.nameEn || ''}
                          onChange={(e) => setTeacherFormData({ ...teacherFormData, nameEn: e.target.value })}
                          className="w-full bg-white border border-slate-300 rounded-lg px-3 py-1.5"
                          required
                        />
                      </div>

                      <div>
                        <label className="block font-bold text-slate-700 mb-1">পদবী (বাংলা) *</label>
                        <input
                          type="text"
                          value={teacherFormData.designationBn || ''}
                          onChange={(e) => setTeacherFormData({ ...teacherFormData, designationBn: e.target.value })}
                          className="w-full bg-white border border-slate-300 rounded-lg px-3 py-1.5"
                          required
                        />
                      </div>

                      <div>
                        <label className="block font-bold text-slate-700 mb-1">পাঠদানের বিষয় *</label>
                        <input
                          type="text"
                          value={teacherFormData.subjectBn || ''}
                          onChange={(e) => setTeacherFormData({ ...teacherFormData, subjectBn: e.target.value })}
                          className="w-full bg-white border border-slate-300 rounded-lg px-3 py-1.5"
                          required
                        />
                      </div>

                      <div>
                        <label className="block font-bold text-slate-700 mb-1">শিক্ষাগত যোগ্যতা</label>
                        <input
                          type="text"
                          value={teacherFormData.qualificationBn || ''}
                          onChange={(e) => setTeacherFormData({ ...teacherFormData, qualificationBn: e.target.value })}
                          className="w-full bg-white border border-slate-300 rounded-lg px-3 py-1.5"
                        />
                      </div>

                      <div>
                        <label className="block font-bold text-slate-700 mb-1">মোবাইল নম্বর</label>
                        <input
                          type="text"
                          value={teacherFormData.phone || ''}
                          onChange={(e) => setTeacherFormData({ ...teacherFormData, phone: e.target.value })}
                          className="w-full bg-white border border-slate-300 rounded-lg px-3 py-1.5 font-mono"
                        />
                      </div>

                      <div className="sm:col-span-2">
                        <label className="block font-bold text-slate-700 mb-1">শিক্ষকের ছবি (ফাইল আপলোড অথবা ইমেজ লিংক)</label>
                        <div className="flex items-center gap-3">
                          <label className="cursor-pointer bg-emerald-800 hover:bg-emerald-700 text-white font-bold py-1.5 px-3 rounded-lg flex items-center gap-1.5 shrink-0">
                            <Upload size={14} />
                            <span>ডিভাইস থেকে আপলোড</span>
                            <input type="file" accept="image/*" className="hidden" onChange={handleTeacherPhotoFile} />
                          </label>
                          <input
                            type="url"
                            placeholder="বা ছবির অনলাইন লিংক (URL) দিন..."
                            value={teacherFormData.photoUrl || ''}
                            onChange={(e) => setTeacherFormData({ ...teacherFormData, photoUrl: e.target.value })}
                            className="flex-1 bg-white border border-slate-300 rounded-lg px-3 py-1.5 font-mono text-[11px]"
                          />
                        </div>
                      </div>

                      <div className="sm:col-span-2">
                        <label className="block font-bold text-slate-700 mb-1">সংক্ষিপ্ত পরিচিতি ও বায়ো</label>
                        <textarea
                          rows={2}
                          value={teacherFormData.bioBn || ''}
                          onChange={(e) => setTeacherFormData({ ...teacherFormData, bioBn: e.target.value })}
                          className="w-full bg-white border border-slate-300 rounded-lg px-3 py-1.5"
                        />
                      </div>
                    </div>

                    <div className="flex justify-end gap-2 pt-2">
                      <button
                        type="button"
                        onClick={() => { setIsAddingTeacher(false); setEditingTeacher(null); }}
                        className="px-4 py-2 rounded-lg border border-slate-300 text-slate-700 font-bold"
                      >
                        বাতিল
                      </button>
                      <button
                        type="submit"
                        className="bg-emerald-800 hover:bg-emerald-900 text-white font-bold px-5 py-2 rounded-lg"
                      >
                        সংরক্ষণ করুন
                      </button>
                    </div>
                  </form>
                ) : (
                  /* Teachers Table */
                  <div className="border border-slate-200 rounded-xl overflow-hidden">
                    <table className="w-full text-xs text-left">
                      <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
                        <tr>
                          <th className="py-2.5 px-3">ছবি</th>
                          <th className="py-2.5 px-3">নাম ও পদবী</th>
                          <th className="py-2.5 px-3">বিষয়</th>
                          <th className="py-2.5 px-3">ফোন</th>
                          <th className="py-2.5 px-3 text-right">অ্যাকশন</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {teachers.map((teacher) => (
                          <tr key={teacher.id} className="hover:bg-slate-50 transition">
                            <td className="py-2 px-3">
                              <img
                                src={teacher.photoUrl}
                                alt={teacher.nameBn}
                                className="w-10 h-10 rounded-lg object-cover border border-slate-200"
                                onError={(e) => {
                                  (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&w=600&q=80';
                                }}
                              />
                            </td>
                            <td className="py-2 px-3">
                              <span className="font-bold text-slate-900 block">{teacher.nameBn}</span>
                              <span className="text-[11px] text-emerald-800 font-medium">{teacher.designationBn}</span>
                            </td>
                            <td className="py-2 px-3 font-medium text-slate-700">{teacher.subjectBn}</td>
                            <td className="py-2 px-3 font-mono text-[11px] text-slate-600">{teacher.phone}</td>
                            <td className="py-2 px-3 text-right">
                              <div className="flex items-center justify-end gap-1.5">
                                <button
                                  onClick={() => {
                                    setEditingTeacher(teacher);
                                    setTeacherFormData(teacher);
                                    setIsAddingTeacher(false);
                                  }}
                                  className="p-1.5 text-blue-600 hover:bg-blue-50 rounded-lg transition"
                                  title="সম্পাদনা করুন"
                                >
                                  <Edit3 size={15} />
                                </button>
                                <button
                                  onClick={() => {
                                    if (confirm(`আপনি কি সত্যিই "${teacher.nameBn}"-কে তালিকা থেকে মুছে ফেলতে চান?`)) {
                                      deleteTeacher(teacher.id);
                                      triggerSuccess('শিক্ষক মুছে ফেলা হয়েছে।');
                                    }
                                  }}
                                  className="p-1.5 text-rose-600 hover:bg-rose-50 rounded-lg transition"
                                  title="মুছে ফেলুন"
                                >
                                  <Trash2 size={15} />
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            )}

            {/* TAB 3: NOTICES MANAGEMENT */}
            {activeTab === 'notices' && (
              <div className="space-y-6">
                <div className="flex items-center justify-between pb-4 border-b border-slate-200">
                  <div>
                    <h4 className="font-bengali-serif text-lg font-bold text-slate-900">
                      নোটিশ বোর্ড ও জরুরি বিজ্ঞপ্তি
                    </h4>
                    <p className="text-xs text-slate-500">
                      নতুন বিজ্ঞপ্তি জারি করুন, সম্পাদনা করুন বা ড্রাফট আপডেট করুন।
                    </p>
                  </div>

                  {!isAddingNotice && !editingNotice && (
                    <button
                      onClick={() => {
                        setIsAddingNotice(true);
                        setEditingNotice(null);
                        setNoticeFormData({
                          titleBn: '',
                          titleEn: '',
                          category: 'academic',
                          date: new Date().toISOString().split('T')[0],
                          isUrgent: false,
                          summaryBn: '',
                          summaryEn: '',
                          contentBn: '',
                          contentEn: '',
                          authorBn: 'প্রধান শিক্ষক'
                        });
                      }}
                      className="flex items-center gap-1.5 bg-emerald-800 hover:bg-emerald-900 text-white text-xs font-bold px-4 py-2 rounded-xl shadow-sm transition"
                    >
                      <Plus size={16} />
                      <span>নতুন নোটিশ প্রকাশ করুন</span>
                    </button>
                  )}
                </div>

                {/* Notice Form */}
                {(isAddingNotice || editingNotice) ? (
                  <form onSubmit={handleSaveNotice} className="bg-slate-50 p-5 rounded-2xl border border-slate-300 space-y-4 text-xs">
                    <h5 className="font-bold text-sm text-emerald-950 border-b border-slate-200 pb-2">
                      {editingNotice ? 'বিজ্ঞপ্তি সম্পাদনা' : 'নতুন বিজ্ঞপ্তি প্রকাশ'}
                    </h5>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="sm:col-span-2">
                        <label className="block font-bold text-slate-700 mb-1">নোটিশের শিরোনাম (বাংলা) *</label>
                        <input
                          type="text"
                          value={noticeFormData.titleBn || ''}
                          onChange={(e) => setNoticeFormData({ ...noticeFormData, titleBn: e.target.value })}
                          className="w-full bg-white border border-slate-300 rounded-lg px-3 py-1.5"
                          required
                        />
                      </div>

                      <div>
                        <label className="block font-bold text-slate-700 mb-1">ক্যাটাগরি</label>
                        <select
                          value={noticeFormData.category}
                          onChange={(e: any) => setNoticeFormData({ ...noticeFormData, category: e.target.value })}
                          className="w-full bg-white border border-slate-300 rounded-lg px-3 py-1.5"
                        >
                          <option value="academic">একাডেমিক (Academic)</option>
                          <option value="exam">পরীক্ষা সংক্রান্ত (Exam)</option>
                          <option value="admission">ভর্তি সংক্রান্ত (Admission)</option>
                          <option value="holiday">ছুটির নোটিশ (Holiday)</option>
                          <option value="event">ইভেন্ট ও ক্রীড়া (Event)</option>
                        </select>
                      </div>

                      <div>
                        <label className="block font-bold text-slate-700 mb-1">প্রকাশের তারিখ</label>
                        <input
                          type="date"
                          value={noticeFormData.date || ''}
                          onChange={(e) => setNoticeFormData({ ...noticeFormData, date: e.target.value })}
                          className="w-full bg-white border border-slate-300 rounded-lg px-3 py-1.5"
                        />
                      </div>

                      <div className="sm:col-span-2">
                        <label className="flex items-center gap-2 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={noticeFormData.isUrgent || false}
                            onChange={(e) => setNoticeFormData({ ...noticeFormData, isUrgent: e.target.checked })}
                            className="w-4 h-4 text-emerald-600 rounded"
                          />
                          <span className="font-bold text-red-600">জরুরি নোটিশ হিসেবে শীর্ষ টিকারে প্রদর্শন করুন</span>
                        </label>
                      </div>

                      <div className="sm:col-span-2">
                        <label className="block font-bold text-slate-700 mb-1">বিস্তারিত বিজ্ঞপ্তি পরিপত্র *</label>
                        <textarea
                          rows={4}
                          value={noticeFormData.contentBn || ''}
                          onChange={(e) => setNoticeFormData({ ...noticeFormData, contentBn: e.target.value })}
                          className="w-full bg-white border border-slate-300 rounded-lg px-3 py-1.5 leading-relaxed"
                          required
                        />
                      </div>
                    </div>

                    <div className="flex justify-end gap-2 pt-2">
                      <button
                        type="button"
                        onClick={() => { setIsAddingNotice(false); setEditingNotice(null); }}
                        className="px-4 py-2 rounded-lg border border-slate-300 text-slate-700 font-bold"
                      >
                        বাতিল
                      </button>
                      <button
                        type="submit"
                        className="bg-emerald-800 hover:bg-emerald-900 text-white font-bold px-5 py-2 rounded-lg"
                      >
                        প্রকাশ করুন
                      </button>
                    </div>
                  </form>
                ) : (
                  /* Notices list */
                  <div className="space-y-3">
                    {notices.map((n) => (
                      <div key={n.id} className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between gap-3">
                        <div>
                          <div className="flex items-center gap-2">
                            {n.isUrgent && (
                              <span className="bg-red-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded">জরুরি</span>
                            )}
                            <span className="text-[10px] bg-slate-200 text-slate-700 px-2 py-0.5 rounded font-mono">{n.date}</span>
                            <span className="text-[10px] bg-amber-100 text-amber-900 px-2 py-0.5 rounded">{n.category}</span>
                          </div>
                          <h5 className="font-bold text-slate-900 mt-1">{n.titleBn}</h5>
                        </div>

                        <div className="flex items-center gap-1 shrink-0">
                          <button
                            onClick={() => { setEditingNotice(n); setNoticeFormData(n); }}
                            className="p-1.5 text-blue-600 hover:bg-blue-100 rounded-lg"
                          >
                            <Edit3 size={15} />
                          </button>
                          <button
                            onClick={() => {
                              if (confirm(`আপনি কি এই নোটিশটি ডিলিট করতে চান?`)) {
                                deleteNotice(n.id);
                                triggerSuccess('নোটিশ মুছে ফেলা হয়েছে।');
                              }
                            }}
                            className="p-1.5 text-rose-600 hover:bg-rose-100 rounded-lg"
                          >
                            <Trash2 size={15} />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* TAB 4: RESULTS DATABASE */}
            {activeTab === 'results' && (
              <div className="space-y-6">
                <div className="flex items-center justify-between pb-4 border-b border-slate-200">
                  <div>
                    <h4 className="font-bengali-serif text-lg font-bold text-slate-900">
                      শিক্ষার্থীদের ফলাফল ও নম্বরপত্র এন্ট্রি
                    </h4>
                    <p className="text-xs text-slate-500">
                      রোল নম্বর, বিষয়ভিত্তিক নম্বর, জিপিএ এবং গ্রেড সহজে যোগ বা এডিট করুন।
                    </p>
                  </div>

                  {!isAddingResult && !editingResult && (
                    <button
                      onClick={() => {
                        setIsAddingResult(true);
                        setEditingResult(null);
                        setResultFormData({
                          rollNo: '',
                          regNo: `202610411${Math.floor(100 + Math.random() * 900)}`,
                          studentNameBn: '',
                          studentNameEn: '',
                          fatherNameBn: '',
                          motherNameBn: '',
                          classGrade: '১০ম শ্রেণি',
                          section: 'ক (বিজ্ঞান)',
                          group: 'Science',
                          examType: 'Test (SSC)',
                          examYear: '২০২৬',
                          gpa: 5.00,
                          overallGrade: 'A+',
                          resultStatus: 'Passed',
                          subjects: [
                            { code: '101', subjectNameBn: 'বাংলা', subjectNameEn: 'Bangla', totalMarks: 100, obtainedMarks: 85, letterGrade: 'A+', gradePoint: 5.0 },
                            { code: '107', subjectNameBn: 'ইংরেজি', subjectNameEn: 'English', totalMarks: 100, obtainedMarks: 80, letterGrade: 'A+', gradePoint: 5.0 },
                            { code: '109', subjectNameBn: 'গণিত', subjectNameEn: 'Mathematics', totalMarks: 100, obtainedMarks: 92, letterGrade: 'A+', gradePoint: 5.0 },
                            { code: '136', subjectNameBn: 'পদার্থবিজ্ঞান', subjectNameEn: 'Physics', totalMarks: 100, obtainedMarks: 88, letterGrade: 'A+', gradePoint: 5.0 }
                          ]
                        });
                      }}
                      className="flex items-center gap-1.5 bg-emerald-800 hover:bg-emerald-900 text-white text-xs font-bold px-4 py-2 rounded-xl shadow-sm transition"
                    >
                      <Plus size={16} />
                      <span>নতুন ফলাফল এন্ট্রি করুন</span>
                    </button>
                  )}
                </div>

                {(isAddingResult || editingResult) ? (
                  <form onSubmit={handleSaveResult} className="bg-slate-50 p-5 rounded-2xl border border-slate-300 space-y-4 text-xs">
                    <h5 className="font-bold text-sm text-emerald-950 border-b border-slate-200 pb-2">
                      {editingResult ? `ফলাফল সম্পাদন: রোল ${editingResult.rollNo}` : 'নতুন রেজাল্ট এন্ট্রি'}
                    </h5>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <div>
                        <label className="block font-bold text-slate-700 mb-1">রোল নম্বর *</label>
                        <input
                          type="text"
                          value={resultFormData.rollNo || ''}
                          onChange={(e) => setResultFormData({ ...resultFormData, rollNo: e.target.value })}
                          className="w-full bg-white border border-slate-300 rounded-lg px-3 py-1.5 font-bold"
                          placeholder="যেমন: ১০১ বা 101"
                          required
                        />
                      </div>

                      <div>
                        <label className="block font-bold text-slate-700 mb-1">শিক্ষার্থীর নাম (বাংলা) *</label>
                        <input
                          type="text"
                          value={resultFormData.studentNameBn || ''}
                          onChange={(e) => setResultFormData({ ...resultFormData, studentNameBn: e.target.value })}
                          className="w-full bg-white border border-slate-300 rounded-lg px-3 py-1.5 font-bold"
                          required
                        />
                      </div>

                      <div>
                        <label className="block font-bold text-slate-700 mb-1">জিপিএ (GPA) *</label>
                        <input
                          type="number"
                          step="0.01"
                          min="0"
                          max="5.00"
                          value={resultFormData.gpa || 5.0}
                          onChange={(e) => setResultFormData({ ...resultFormData, gpa: parseFloat(e.target.value) || 0 })}
                          className="w-full bg-white border border-slate-300 rounded-lg px-3 py-1.5 font-mono font-bold text-emerald-800"
                          required
                        />
                      </div>

                      <div>
                        <label className="block font-bold text-slate-700 mb-1">শ্রেণি</label>
                        <input
                          type="text"
                          value={resultFormData.classGrade || '১০ম শ্রেণি'}
                          onChange={(e) => setResultFormData({ ...resultFormData, classGrade: e.target.value })}
                          className="w-full bg-white border border-slate-300 rounded-lg px-3 py-1.5"
                        />
                      </div>

                      <div>
                        <label className="block font-bold text-slate-700 mb-1">শাখা / বিভাগ</label>
                        <input
                          type="text"
                          value={resultFormData.section || 'ক (বিজ্ঞান)'}
                          onChange={(e) => setResultFormData({ ...resultFormData, section: e.target.value })}
                          className="w-full bg-white border border-slate-300 rounded-lg px-3 py-1.5"
                        />
                      </div>

                      <div>
                        <label className="block font-bold text-slate-700 mb-1">লেটার গ্রেড</label>
                        <input
                          type="text"
                          value={resultFormData.overallGrade || 'A+'}
                          onChange={(e) => setResultFormData({ ...resultFormData, overallGrade: e.target.value })}
                          className="w-full bg-white border border-slate-300 rounded-lg px-3 py-1.5 font-bold text-amber-700"
                        />
                      </div>
                    </div>

                    <div className="flex justify-end gap-2 pt-2">
                      <button
                        type="button"
                        onClick={() => { setIsAddingResult(false); setEditingResult(null); }}
                        className="px-4 py-2 rounded-lg border border-slate-300 text-slate-700 font-bold"
                      >
                        বাতিল
                      </button>
                      <button
                        type="submit"
                        className="bg-emerald-800 hover:bg-emerald-900 text-white font-bold px-5 py-2 rounded-lg"
                      >
                        সংরক্ষণ করুন
                      </button>
                    </div>
                  </form>
                ) : (
                  <div className="border border-slate-200 rounded-xl overflow-hidden">
                    <table className="w-full text-xs text-left">
                      <thead className="bg-slate-100 font-bold text-slate-700">
                        <tr>
                          <th className="py-2.5 px-3">রোল</th>
                          <th className="py-2.5 px-3">শিক্ষার্থীর নাম</th>
                          <th className="py-2.5 px-3">শ্রেণি</th>
                          <th className="py-2.5 px-3">জিপিএ (GPA)</th>
                          <th className="py-2.5 px-3">গ্রেড</th>
                          <th className="py-2.5 px-3 text-right">অ্যাকশন</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {results.map((res) => (
                          <tr key={res.rollNo} className="hover:bg-slate-50 transition">
                            <td className="py-2 px-3 font-mono font-bold text-slate-900">{res.rollNo}</td>
                            <td className="py-2 px-3 font-semibold text-slate-800">{res.studentNameBn}</td>
                            <td className="py-2 px-3 text-slate-600">{res.classGrade}</td>
                            <td className="py-2 px-3 font-mono font-black text-emerald-800">{res.gpa.toFixed(2)}</td>
                            <td className="py-2 px-3 font-black text-amber-600">{res.overallGrade}</td>
                            <td className="py-2 px-3 text-right">
                              <div className="flex items-center justify-end gap-1.5">
                                <button
                                  onClick={() => { setEditingResult(res); setResultFormData(res); }}
                                  className="p-1.5 text-blue-600 hover:bg-blue-50 rounded"
                                >
                                  <Edit3 size={15} />
                                </button>
                                <button
                                  onClick={() => {
                                    if (confirm(`রোল ${res.rollNo} এর রেজাল্ট মুছে ফেলতে চান?`)) {
                                      deleteResult(res.rollNo);
                                      triggerSuccess('রেজাল্ট মুছে ফেলা হয়েছে।');
                                    }
                                  }}
                                  className="p-1.5 text-rose-600 hover:bg-rose-50 rounded"
                                >
                                  <Trash2 size={15} />
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            )}

            {/* TAB 5: CLASS ROUTINE */}
            {activeTab === 'routine' && (
              <div className="space-y-6">
                <div>
                  <h4 className="font-bengali-serif text-lg font-bold text-slate-900">
                    দৈনিক ক্লাস রুটিন কাস্টমাইজেশন
                  </h4>
                  <p className="text-xs text-slate-500">
                    রবিবার থেকে বৃহস্পতিবার প্রতিটি দিনের পিরিয়ড ও শিক্ষক পরিবর্তন করুন।
                  </p>
                </div>

                <div className="space-y-4">
                  {routines.map((day, dayIdx) => (
                    <div key={dayIdx} className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
                      <div className="flex items-center justify-between">
                        <h5 className="font-bold text-emerald-900 text-sm">{day.dayBn} ({day.dayEn})</h5>
                        <span className="text-[11px] text-slate-500 font-semibold">{day.periods.length}টি পিরিয়ড</span>
                      </div>

                      <div className="space-y-2 text-xs">
                        {day.periods.map((p, pIdx) => (
                          <div key={pIdx} className="grid grid-cols-1 sm:grid-cols-4 gap-2 bg-white p-2 rounded-lg border border-slate-200 items-center">
                            <span className="font-bold text-emerald-900">পিরিয়ড {p.period}: {p.time}</span>
                            <input
                              type="text"
                              value={p.subjectBn}
                              onChange={(e) => {
                                const updatedPeriods = [...day.periods];
                                updatedPeriods[pIdx] = { ...p, subjectBn: e.target.value };
                                updateRoutine(dayIdx, { ...day, periods: updatedPeriods });
                              }}
                              className="bg-slate-50 border border-slate-300 rounded px-2 py-1 text-xs"
                              placeholder="বিষয়"
                            />
                            <input
                              type="text"
                              value={p.teacherBn}
                              onChange={(e) => {
                                const updatedPeriods = [...day.periods];
                                updatedPeriods[pIdx] = { ...p, teacherBn: e.target.value };
                                updateRoutine(dayIdx, { ...day, periods: updatedPeriods });
                              }}
                              className="bg-slate-50 border border-slate-300 rounded px-2 py-1 text-xs"
                              placeholder="শিক্ষকের নাম"
                            />
                            <input
                              type="text"
                              value={p.room}
                              onChange={(e) => {
                                const updatedPeriods = [...day.periods];
                                updatedPeriods[pIdx] = { ...p, room: e.target.value };
                                updateRoutine(dayIdx, { ...day, periods: updatedPeriods });
                              }}
                              className="bg-slate-50 border border-slate-300 rounded px-2 py-1 text-xs"
                              placeholder="রুম"
                            />
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* TAB 6: GALLERY */}
            {activeTab === 'gallery' && (
              <div className="space-y-6">
                <div className="flex items-center justify-between pb-4 border-b border-slate-200">
                  <div>
                    <h4 className="font-bengali-serif text-lg font-bold text-slate-900">
                      ফটো গ্যালারি পরিচালনা
                    </h4>
                    <p className="text-xs text-slate-500">
                      বিদ্যালয়ের নতুন ছবি যুক্ত করুন অথবা আগের ছবি মুছে ফেলুন।
                    </p>
                  </div>

                  {!isAddingGallery && (
                    <button
                      onClick={() => setIsAddingGallery(true)}
                      className="flex items-center gap-1.5 bg-emerald-800 hover:bg-emerald-900 text-white text-xs font-bold px-4 py-2 rounded-xl shadow-sm transition"
                    >
                      <Plus size={16} />
                      <span>নতুন ছবি যুক্ত করুন</span>
                    </button>
                  )}
                </div>

                {isAddingGallery && (
                  <form onSubmit={handleSaveGallery} className="bg-slate-50 p-5 rounded-2xl border border-slate-300 space-y-4 text-xs">
                    <h5 className="font-bold text-sm text-emerald-950 border-b border-slate-200 pb-2">
                      নতুন আলোকচিত্র আপলোড
                    </h5>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block font-bold text-slate-700 mb-1">ছবির শিরোনাম *</label>
                        <input
                          type="text"
                          value={galleryFormData.titleBn || ''}
                          onChange={(e) => setGalleryFormData({ ...galleryFormData, titleBn: e.target.value })}
                          className="w-full bg-white border border-slate-300 rounded-lg px-3 py-1.5"
                          required
                        />
                      </div>

                      <div>
                        <label className="block font-bold text-slate-700 mb-1">ক্যাটাগরি</label>
                        <select
                          value={galleryFormData.category}
                          onChange={(e: any) => setGalleryFormData({ ...galleryFormData, category: e.target.value })}
                          className="w-full bg-white border border-slate-300 rounded-lg px-3 py-1.5"
                        >
                          <option value="campus">ক্যাম্পাস ও দীঘি</option>
                          <option value="academic">শিক্ষা ও ল্যাব</option>
                          <option value="sports">খেলাধুলা</option>
                          <option value="national">জাতীয় দিবস</option>
                          <option value="cultural">সাংস্কৃতিক</option>
                        </select>
                      </div>

                      <div className="sm:col-span-2">
                        <label className="block font-bold text-slate-700 mb-1">ছবি আপলোড অথবা লিংক *</label>
                        <div className="flex items-center gap-2">
                          <label className="cursor-pointer bg-emerald-800 hover:bg-emerald-700 text-white font-bold py-1.5 px-3 rounded-lg flex items-center gap-1.5 shrink-0">
                            <Upload size={14} />
                            <span>ডিভাইস থেকে ছবি বাছুন</span>
                            <input type="file" accept="image/*" className="hidden" onChange={handleGalleryPhotoFile} />
                          </label>
                          <input
                            type="url"
                            value={galleryFormData.imageUrl || ''}
                            onChange={(e) => setGalleryFormData({ ...galleryFormData, imageUrl: e.target.value })}
                            placeholder="বা ছবির ওয়েব লিংক (URL) দিন..."
                            className="flex-1 bg-white border border-slate-300 rounded-lg px-3 py-1.5 font-mono text-[11px]"
                            required
                          />
                        </div>
                      </div>

                      <div className="sm:col-span-2">
                        <label className="block font-bold text-slate-700 mb-1">ক্যাপশন বা বিবরণ</label>
                        <input
                          type="text"
                          value={galleryFormData.captionBn || ''}
                          onChange={(e) => setGalleryFormData({ ...galleryFormData, captionBn: e.target.value })}
                          className="w-full bg-white border border-slate-300 rounded-lg px-3 py-1.5"
                        />
                      </div>
                    </div>

                    <div className="flex justify-end gap-2 pt-2">
                      <button
                        type="button"
                        onClick={() => setIsAddingGallery(false)}
                        className="px-4 py-2 rounded-lg border border-slate-300 text-slate-700 font-bold"
                      >
                        বাতিল
                      </button>
                      <button
                        type="submit"
                        className="bg-emerald-800 hover:bg-emerald-900 text-white font-bold px-5 py-2 rounded-lg"
                      >
                        যুক্ত করুন
                      </button>
                    </div>
                  </form>
                )}

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                  {gallery.map((g) => (
                    <div key={g.id} className="relative group rounded-xl overflow-hidden border border-slate-200 bg-slate-100">
                      <img src={g.imageUrl} alt={g.titleBn} className="w-full aspect-4/3 object-cover" />
                      <div className="p-2 text-[11px] bg-white">
                        <p className="font-bold text-slate-900 line-clamp-1">{g.titleBn}</p>
                        <p className="text-slate-500 text-[10px]">{g.category}</p>
                      </div>
                      <button
                        onClick={() => {
                          if (confirm('ছবিটি ডিলিট করতে চান?')) {
                            deleteGalleryItem(g.id);
                            triggerSuccess('ছবি মুছে ফেলা হয়েছে।');
                          }
                        }}
                        className="absolute top-2 right-2 p-1.5 bg-rose-600 text-white rounded-lg opacity-0 group-hover:opacity-100 transition shadow-md"
                      >
                        <Trash2 size={13} />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* TAB 7: THEME */}
            {activeTab === 'theme' && (
              <div className="space-y-6 max-w-xl">
                <div>
                  <h4 className="font-bengali-serif text-lg font-bold text-slate-900">
                    ওয়েবসাইট থিম ও কালার স্কিম
                  </h4>
                  <p className="text-xs text-slate-500">
                    বিদ্যালয়ের রঙ ও পছন্দের প্যালেটে ওয়েবসাইটের সামগ্রিক রূপ নির্বাচন করুন।
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div
                    onClick={() => setThemeColor('emerald')}
                    className={`p-4 rounded-2xl border-2 cursor-pointer transition flex items-center gap-3 ${
                      themeColor === 'emerald' ? 'border-emerald-600 bg-emerald-50 ring-2 ring-emerald-200' : 'border-slate-200'
                    }`}
                  >
                    <div className="w-10 h-10 rounded-xl bg-emerald-900 border-2 border-amber-400"></div>
                    <div>
                      <h5 className="font-bold text-sm text-slate-900">এমারেল্ড গ্রিন ও গোল্ড</h5>
                      <p className="text-[11px] text-slate-500">ঐতিহ্যবাহী বাংলাদেশি সরকারি ও মডেল স্কুলের ক্লাসিক রঙ</p>
                    </div>
                  </div>

                  <div
                    onClick={() => setThemeColor('navy')}
                    className={`p-4 rounded-2xl border-2 cursor-pointer transition flex items-center gap-3 ${
                      themeColor === 'navy' ? 'border-blue-600 bg-blue-50 ring-2 ring-blue-200' : 'border-slate-200'
                    }`}
                  >
                    <div className="w-10 h-10 rounded-xl bg-slate-950 border-2 border-blue-400"></div>
                    <div>
                      <h5 className="font-bold text-sm text-slate-900">রয়্যাল নেভি ব্লু</h5>
                      <p className="text-[11px] text-slate-500">আধুনিক প্রাতিষ্ঠানিক ও প্রযুক্তিধর্মী লুক</p>
                    </div>
                  </div>

                  <div
                    onClick={() => setThemeColor('forest')}
                    className={`p-4 rounded-2xl border-2 cursor-pointer transition flex items-center gap-3 ${
                      themeColor === 'forest' ? 'border-emerald-700 bg-emerald-50 ring-2 ring-emerald-200' : 'border-slate-200'
                    }`}
                  >
                    <div className="w-10 h-10 rounded-xl bg-emerald-950 border-2 border-emerald-400"></div>
                    <div>
                      <h5 className="font-bold text-sm text-slate-900">ডিপ ফরেস্ট গ্রিন</h5>
                      <p className="text-[11px] text-slate-500">শান্ত ও সবুজ নিসর্গের অনুভূতি</p>
                    </div>
                  </div>

                  <div
                    onClick={() => setThemeColor('maroon')}
                    className={`p-4 rounded-2xl border-2 cursor-pointer transition flex items-center gap-3 ${
                      themeColor === 'maroon' ? 'border-rose-700 bg-rose-50 ring-2 ring-rose-200' : 'border-slate-200'
                    }`}
                  >
                    <div className="w-10 h-10 rounded-xl bg-rose-950 border-2 border-amber-400"></div>
                    <div>
                      <h5 className="font-bold text-sm text-slate-900">হেরিটেজ মেরুন</h5>
                      <p className="text-[11px] text-slate-500">গৌরবোজ্জ্বল প্রাচীন ঐতিহ্যবাহী লালচে আভিজাত্য</p>
                    </div>
                  </div>
                </div>

                <div className="p-4 bg-amber-50 rounded-xl border border-amber-200 text-xs text-amber-950 flex items-center gap-2">
                  <Sparkles size={18} className="text-amber-600 shrink-0" />
                  <span>কালার স্কিম সিলেক্ট করলেই তা সরাসরি কার্যকর হবে এবং ব্রাউজারে সংরক্ষিত থাকবে।</span>
                </div>
              </div>
            )}

            {/* TAB 8: BACKUP & RESTORE */}
            {activeTab === 'backup' && (
              <div className="space-y-6 max-w-2xl">
                <div>
                  <h4 className="font-bengali-serif text-lg font-bold text-slate-900">
                    ব্যাকআপ, এক্সপোর্ট ও ফ্যাক্টরি রিস্টোর
                  </h4>
                  <p className="text-xs text-slate-500">
                    আপনার তৈরি করা সকল কাস্টমাইজেশন ব্যাকআপ ফাইল হিসেবে ডাউনলোড করুন বা নতুন ডিভাইসে রিস্টোর করুন।
                  </p>
                </div>

                {/* Export Card */}
                <div className="p-5 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
                  <div className="flex items-center gap-2 text-slate-900 font-bold text-sm">
                    <Download className="text-emerald-700" size={18} />
                    <span>১. সম্পূর্ণ সাইটের ব্যাকআপ ডাউনলোড করুন</span>
                  </div>
                  <p className="text-xs text-slate-600">
                    সকল শিক্ষক, নোটিশ, রেজাল্ট, ক্লাস রুটিন ও প্রাতিষ্ঠানিক তথ্যের একটি একক JSON ব্যাকআপ কপি ডাউনলোড করে নিরাপদে সংরক্ষণ করুন।
                  </p>
                  <button
                    onClick={handleExport}
                    className="flex items-center gap-2 bg-emerald-800 hover:bg-emerald-900 text-white text-xs font-bold px-4 py-2.5 rounded-xl shadow-sm transition"
                  >
                    <Download size={15} />
                    <span>ব্যাকআপ ফাইল ডাউনলোড করুন (.json)</span>
                  </button>
                </div>

                {/* Import Card */}
                <div className="p-5 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
                  <div className="flex items-center gap-2 text-slate-900 font-bold text-sm">
                    <FileCode className="text-blue-700" size={18} />
                    <span>২. ব্যাকআপ রিস্টোর বা ইমপোর্ট করুন</span>
                  </div>
                  <textarea
                    rows={3}
                    placeholder="পূর্বে ডাউনলোডকৃত JSON ফাইলের কোড এখানে পেস্ট করুন..."
                    value={importJsonText}
                    onChange={(e) => setImportJsonText(e.target.value)}
                    className="w-full bg-white border border-slate-300 rounded-xl p-3 text-xs font-mono focus:outline-none focus:border-blue-600"
                  />
                  <button
                    onClick={handleImport}
                    disabled={!importJsonText.trim()}
                    className="flex items-center gap-2 bg-blue-700 hover:bg-blue-800 disabled:bg-slate-300 text-white text-xs font-bold px-4 py-2.5 rounded-xl shadow-sm transition"
                  >
                    <Upload size={15} />
                    <span>ডাটা রিস্টোর করুন</span>
                  </button>
                </div>

                {/* Factory Reset */}
                <div className="p-5 bg-rose-50 rounded-2xl border border-rose-200 space-y-3">
                  <div className="flex items-center gap-2 text-rose-900 font-bold text-sm">
                    <ShieldAlert size={18} className="text-rose-600" />
                    <span>৩. ফ্যাক্টরি ডিফল্ট ডাটা রিস্টোর</span>
                  </div>
                  <p className="text-xs text-rose-700">
                    সতর্কতা: এটি আপনার করা সকল কাস্টম পরিবর্তন মুছে ফেলে স্কুলের মূল ডিফল্ট ডাটাবেজ ফিরিয়ে আনবে।
                  </p>
                  <button
                    onClick={() => {
                      if (confirm('আপনি কি নিশ্চিত যে সমস্ত কাস্টম ডাটা মুছে ফেলে মূল ডিফল্ট ডাটায় ফিরতে চান?')) {
                        resetAllData();
                        setInfoForm({ ...schoolInfo });
                        triggerSuccess('সকল ডাটা সফলভাবে ডিফল্ট অবস্থায় রিস্টোর হয়েছে!');
                      }
                    }}
                    className="flex items-center gap-2 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold px-4 py-2 rounded-xl shadow-sm transition"
                  >
                    <RotateCcw size={14} />
                    <span>ফ্যাক্টরি রিসেট করুন</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
