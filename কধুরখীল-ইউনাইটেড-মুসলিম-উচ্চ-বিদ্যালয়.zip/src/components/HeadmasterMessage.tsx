import React from 'react';
import { historyDetails } from '../data/schoolData';
import { useSchool } from '../context/SchoolContext';
import { Quote, Award, BookCheck, History, HeartHandshake } from 'lucide-react';

interface HeadmasterMessageProps {
  lang: 'bn' | 'en';
}

export const HeadmasterMessage: React.FC<HeadmasterMessageProps> = ({ lang }) => {
  const { teachers, committee, schoolInfo } = useSchool();
  const headmaster = teachers.find((t) => t.isHeadmaster) || teachers[0];
  const committeeHead = committee[0] || {
    id: 'cm-1',
    nameBn: 'আলহাজ্ব রেজাউল করিম চৌধুরী',
    nameEn: 'Alhaj Rezaul Karim Chowdhury',
    roleBn: 'সভাপতি, বিদ্যালয় পরিচালনা পর্ষদ',
    roleEn: 'President, Managing Committee',
    occupationBn: 'বিশিষ্ট সমাজসেবক ও শিক্ষানুরাগী',
    photoUrl: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=600&q=80',
    phone: '+880 1819-100200'
  };

  const [headmasterPhoto, setHeadmasterPhoto] = React.useState<string>(headmaster?.photoUrl || '');

  React.useEffect(() => {
    try {
      const saved = localStorage.getItem('kumhs_teacher_custom_photos');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed[headmaster.id]) {
          setHeadmasterPhoto(parsed[headmaster.id]);
        }
      }
    } catch (e) {
      console.error(e);
    }
  }, [headmaster.id]);

  return (
    <section id="about" className="py-14 sm:py-20 bg-slate-50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-8">
        {/* Section Heading */}
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="text-xs font-bold uppercase tracking-wider text-emerald-800 bg-emerald-100/80 px-3 py-1 rounded-full border border-emerald-300">
            {lang === 'bn' ? 'আমাদের বার্তা ও ইতিহাস' : 'Institutional Heritage & Messages'}
          </span>
          <h2 className="font-bengali-serif text-2xl sm:text-4xl font-black text-slate-900 mt-2">
            {lang === 'bn' ? 'প্রধান শিক্ষক ও সভাপতির বাণী' : 'Messages from Leadership'}
          </h2>
          <div className="w-16 h-1 bg-amber-500 mx-auto mt-3 rounded-full"></div>
        </div>

        {/* Messages Side-by-Side Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-16">
          {/* Headmaster Card */}
          <div className="bg-white rounded-2xl shadow-md border border-slate-200 overflow-hidden flex flex-col hover:shadow-xl transition duration-300">
            <div className="bg-gradient-to-r from-emerald-900 to-emerald-800 text-white p-6 sm:p-7 relative">
              <Quote className="absolute right-6 top-6 text-emerald-700/50 w-16 h-16 pointer-events-none" />
              <div className="flex items-center gap-4">
                <img
                  src={headmasterPhoto}
                  alt={lang === 'bn' ? headmaster.nameBn : headmaster.nameEn}
                  className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl object-cover border-4 border-amber-400 shadow-md shrink-0"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&w=600&q=80';
                  }}
                />
                <div>
                  <span className="text-amber-300 text-xs font-bold uppercase tracking-wider bg-emerald-950/60 px-2 py-0.5 rounded">
                    {lang === 'bn' ? 'প্রধান শিক্ষকের বাণী' : "Headmaster's Message"}
                  </span>
                  <h3 className="font-bengali-serif text-xl sm:text-2xl font-bold text-white mt-1">
                    {lang === 'bn' ? headmaster.nameBn : headmaster.nameEn}
                  </h3>
                  <p className="text-emerald-200 text-xs sm:text-sm font-medium">
                    {lang === 'bn' ? headmaster.qualificationBn : headmaster.qualificationEn}
                  </p>
                  <p className="text-amber-200 text-xs mt-0.5 font-semibold">
                    {lang === 'bn' ? schoolInfo.nameBn : schoolInfo.nameEn}
                  </p>
                </div>
              </div>
            </div>

            <div className="p-6 sm:p-8 flex-1 flex flex-col justify-between text-slate-700 text-sm sm:text-base leading-relaxed space-y-4">
              <p>
                {lang === 'bn' ? (
                  <>
                    <strong className="text-emerald-900 font-bold">বিসমিল্লাহির রাহমানির রাহীম।</strong> ঐতিহ্যবাহী কধুরখীল ইউনাইটেড মুসলিম উচ্চ বিদ্যালয় ১৯৪৭ সালে প্রতিষ্ঠার পর থেকে চট্টগ্রামের বোয়ালখালী অঞ্চলের শিক্ষা বিস্তারে এক অনন্য বাতিঘর হিসেবে দায়িত্ব পালন করে আসছে। আমাদের লক্ষ্য কেবল পুঁথিগত শিক্ষাদান নয়, বরং প্রতিটি শিক্ষার্থীকে নৈতিকতা, মানবিক মূল্যবোধ ও আধুনিক বিজ্ঞান-প্রযুক্তির জ্ঞানে আলোকিত আদর্শ মানুষ হিসেবে গড়ে তোলা।
                  </>
                ) : (
                  <>
                    In the name of Allah, the Most Gracious, the Most Merciful. Since our foundation in 1947, Kadhurkhil United Muslim High School has served as a lighthouse of secondary education in Boalkhali. We empower students with both ethical virtues and scientific competencies.
                  </>
                )}
              </p>
              <p className="text-slate-600 text-xs sm:text-sm">
                {lang === 'bn'
                  ? 'সুদক্ষ শিক্ষক মণ্ডলী, অভিভাবকবৃন্দের সহযোগিতা এবং স্থানীয় সুধী সমাজের আন্তরিকতায় আমাদের শিক্ষার্থীরা এসএসসিতে প্রতিবছর কৃতিত্বপূর্ণ ফলাফল অর্জন করছে। ডিজিটাল ক্লাসরুম ও খেলাধুলার মাধ্যমে আমরা শিক্ষার্থীদের সার্বিক বিকাশ নিশ্চিত করতে সচেষ্ট।'
                  : 'Through disciplined mentorship, smart labs, and community partnership, we ensure continuous academic excellence and moral leadership.'}
              </p>

              <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
                <div>
                  <span className="block text-xs text-slate-400">যোগাযোগ:</span>
                  <span className="text-xs font-bold text-emerald-800">{headmaster.phone}</span>
                </div>
                <div className="text-right">
                  <span className="font-bengali-serif text-sm font-bold text-slate-900 block">মোহাম্মদ ইলিয়াছ</span>
                  <span className="text-[11px] text-slate-500">প্রধান শিক্ষক, কধুরখীল ইউ. মু. উচ্চ বিদ্যালয়</span>
                </div>
              </div>
            </div>
          </div>

          {/* Managing Committee President Card */}
          <div className="bg-white rounded-2xl shadow-md border border-slate-200 overflow-hidden flex flex-col hover:shadow-xl transition duration-300">
            <div className="bg-gradient-to-r from-slate-900 to-emerald-950 text-white p-6 sm:p-7 relative">
              <Award className="absolute right-6 top-6 text-emerald-800/40 w-16 h-16 pointer-events-none" />
              <div className="flex items-center gap-4">
                <img
                  src={committeeHead.photoUrl}
                  alt={lang === 'bn' ? committeeHead.nameBn : committeeHead.nameEn}
                  className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl object-cover border-4 border-amber-400 shadow-md shrink-0"
                />
                <div>
                  <span className="text-amber-300 text-xs font-bold uppercase tracking-wider bg-black/40 px-2 py-0.5 rounded">
                    {lang === 'bn' ? 'সভাপতির বাণী' : "President's Message"}
                  </span>
                  <h3 className="font-bengali-serif text-xl sm:text-2xl font-bold text-white mt-1">
                    {lang === 'bn' ? committeeHead.nameBn : committeeHead.nameEn}
                  </h3>
                  <p className="text-emerald-200 text-xs sm:text-sm font-medium">
                    {lang === 'bn' ? committeeHead.roleBn : committeeHead.roleEn}
                  </p>
                  <p className="text-slate-300 text-xs mt-0.5">
                    {lang === 'bn' ? committeeHead.occupationBn : 'Distinguished Patron & Social Worker'}
                  </p>
                </div>
              </div>
            </div>

            <div className="p-6 sm:p-8 flex-1 flex flex-col justify-between text-slate-700 text-sm sm:text-base leading-relaxed space-y-4">
              <p>
                {lang === 'bn' ? (
                  <>
                    কধুরখীল ইউনাইটেড মুসলিম উচ্চ বিদ্যালয় বোয়ালখালীর গর্ব। পরিচালনা পর্ষদের পক্ষ থেকে আমরা বিদ্যালয়ের অবকাঠামো আধুনিকায়ন, চারতলা বিশিষ্ট নতুন একাডেমিক ভবনের সুষ্ঠু পরিচালনা এবং শেখ রাসেল ডিজিটাল ল্যাবের সর্বোচ্চ ব্যবহারে প্রতিশ্রুতিবদ্ধ।
                  </>
                ) : (
                  <>
                    Kadhurkhil United Muslim High School is our community pride. The school managing committee remains dedicated to providing modern infrastructure, multi-storied academic facilities, and a safe educational sanctuary for every child.
                  </>
                )}
              </p>
              <p className="text-slate-600 text-xs sm:text-sm">
                {lang === 'bn'
                  ? 'আমরা বিশ্বাস করি প্রতিটি শিশুই অপার সম্ভাবনাময়। শিক্ষক-অভিভাবক যৌথ উদ্যোগে এই প্রতিষ্ঠান বোয়ালখালী তথা চট্টগ্রামের অন্যতম শ্রেষ্ঠ বিদ্যাপীঠ হিসেবে তার অগ্রযাত্রা অব্যাহত রাখবে, ইনশাআল্লাহ।'
                  : 'We foster collective synergy among guardians, alumni, and teachers to uphold high standards and inclusive educational access.'}
              </p>

              <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
                <div>
                  <span className="block text-xs text-slate-400">দায়িত্বকাল:</span>
                  <span className="text-xs font-bold text-slate-700">২০২৪-২০২৬ মেয়াদ</span>
                </div>
                <div className="text-right">
                  <span className="font-bengali-serif text-sm font-bold text-slate-900 block">আলহাজ্ব রেজাউল করিম চৌধুরী</span>
                  <span className="text-[11px] text-slate-500">সভাপতি, পরিচালনা পর্ষদ</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* History & Heritage Spotlight Card */}
        <div className="bg-gradient-to-r from-amber-50 to-emerald-50 rounded-2xl border border-amber-200/80 p-6 sm:p-10 shadow-sm">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 pb-6 border-b border-amber-200/60">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-amber-500 text-white rounded-xl shadow-md">
                <History size={26} />
              </div>
              <div>
                <h3 className="font-bengali-serif text-xl sm:text-2xl font-bold text-emerald-950">
                  {lang === 'bn' ? 'বিদ্যালয়ের সংক্ষিপ্ত ইতিহাস ও ঐতিহ্য' : 'Brief History & Heritage'}
                </h3>
                <p className="text-xs sm:text-sm text-slate-600 font-medium">
                  {lang === 'bn' ? '১৯৪৭ খ্রিষ্টাব্দে প্রতিষ্ঠার পর থেকে গৌরবের ৭৯ বছর' : '79+ Years of Inspiring Education'}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 bg-white px-3.5 py-1.5 rounded-lg border border-emerald-200 text-xs font-bold text-emerald-900 shadow-xs">
              <BookCheck size={16} className="text-emerald-600" />
              <span>EIIN: {schoolInfo.eiinEn} • {lang === 'bn' ? 'কধুরখীল, বোয়ালখালী' : 'Boalkhali'}</span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-6 text-xs sm:text-sm leading-relaxed text-slate-700">
            <div className="space-y-3">
              <p>
                <strong className="text-emerald-950 font-bold">{lang === 'bn' ? 'প্রতিষ্ঠার পটভূমি:' : 'Foundation Background:'}</strong> {historyDetails.foundersBn}
              </p>
              <p>
                {historyDetails.significanceBn}
              </p>
            </div>
            <div className="space-y-3 bg-white/70 p-5 rounded-xl border border-emerald-100">
              <p className="font-semibold text-emerald-900">
                {lang === 'bn' ? 'অবস্থান ও প্রাকৃতিক পরিবেশ:' : 'Location & Natural Ambience:'}
              </p>
              <p>
                {lang === 'bn'
                  ? 'বিদ্যালয়টি বোয়ালখালী উপজেলার ১নং কধুরখীল ইউনিয়নের মধ্যভাগে ঐতিহাসিক ও সুবিশাল "লালার দীঘি"র তীরে অবস্থিত। বিদ্যালয় প্রাঙ্গণের চারপাশ সবুজ নারিকেল ও সুপারি গাছে পরিবেষ্টিত। বিদ্যালয়ের সম্মুখস্থ সুবিশাল খেলার মাঠ ও ত্রি-মুখী সংযোগ সড়ক শহর থেকে সহজ যাতায়াতের সুযোগ সৃষ্টি করেছে।'
                  : 'Located beside the historic Lalar Dighi pond in Kadhurkhil Union, Boalkhali, Chattogram, surrounded by lush palm greens and well-connected roads.'}
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
