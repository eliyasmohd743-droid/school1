import React from 'react';
import { SchoolLogo } from './SchoolLogo';
import { useSchool } from '../context/SchoolContext';
import { 
  GraduationCap, 
  Search, 
  Users, 
  FileText, 
  MapPin, 
  ShieldCheck, 
  CheckCircle2, 
  Sparkles,
  Award,
  BookOpen
} from 'lucide-react';

interface HeroProps {
  lang: 'bn' | 'en';
  onOpenAdmission: () => void;
  onOpenResults: () => void;
  onNavigateTeachers: () => void;
  onNavigateNotices: () => void;
}

export const Hero: React.FC<HeroProps> = ({
  lang,
  onOpenAdmission,
  onOpenResults,
  onNavigateTeachers,
  onNavigateNotices
}) => {
  const { schoolInfo, themeColor } = useSchool();

  const themeGradient = 
    themeColor === 'navy' 
      ? 'from-slate-950 via-slate-900 to-blue-950' 
      : themeColor === 'maroon' 
      ? 'from-rose-950 via-red-950 to-slate-950' 
      : themeColor === 'forest' 
      ? 'from-emerald-950 via-green-950 to-emerald-950' 
      : 'from-emerald-950 via-emerald-900 to-emerald-950';

  return (
    <div className={`relative bg-gradient-to-b ${themeGradient} text-white overflow-hidden border-b-4 border-amber-500`}>
      {/* Decorative Background Patterns & Highlights */}
      <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#ca8a04_1px,transparent_1px)] [background-size:24px_24px]"></div>
      <div className="absolute -top-32 -right-32 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none"></div>
      <div className="absolute bottom-0 -left-20 w-80 h-80 bg-amber-500/10 rounded-full blur-3xl pointer-events-none"></div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-8 pt-10 pb-16 sm:pb-20">
        {/* Top Heritage Badge */}
        <div className="flex flex-wrap items-center justify-center gap-2 mb-6">
          <div className="inline-flex items-center gap-2 bg-emerald-800/80 border border-emerald-600/70 backdrop-blur-md px-3.5 py-1.5 rounded-full text-xs font-semibold text-amber-300 shadow-inner">
            <Sparkles size={14} className="text-amber-400" />
            <span>
              {lang === 'bn' 
                ? 'ঐতিহ্য ও আধুনিক শিক্ষার ৭৯তম বর্ষ • স্থাপিত ১৯৪৭ খ্রিষ্টাব্দ' 
                : '79+ Years of Academic Heritage • Founded in 1947'}
            </span>
          </div>

          <div className="inline-flex items-center gap-1.5 bg-amber-500/20 border border-amber-400/40 px-3 py-1.5 rounded-full text-xs font-semibold text-amber-200">
            <ShieldCheck size={14} className="text-amber-300" />
            <span>EIIN: {schoolInfo.eiinEn} • চট্টগ্রাম শিক্ষা বোর্ড</span>
          </div>
        </div>

        {/* Center Presentation: Large Crest + Name + Motto */}
        <div className="text-center max-w-4xl mx-auto space-y-4">
          <div className="flex justify-center mb-3">
            <SchoolLogo size={110} className="sm:w-32 sm:h-32 drop-shadow-2xl hover:scale-105 duration-300" />
          </div>

          <h1 className="font-bengali-serif text-3xl sm:text-5xl md:text-6xl font-black tracking-tight leading-tight drop-shadow-lg text-white">
            {lang === 'bn' ? schoolInfo.nameBn : schoolInfo.nameEn}
          </h1>

          <p className="text-emerald-200 text-sm sm:text-lg font-medium tracking-wide">
            {lang === 'bn' 
              ? 'লালার দীঘির পাড়, ১নং কধুরখীল, বোয়ালখালী, চট্টগ্রাম-৪৩৬১' 
              : 'Lalar Dighi Par, Kadhurkhil Union, Boalkhali, Chattogram, Bangladesh'}
          </p>

          <div className="inline-block bg-emerald-950/70 border border-amber-500/40 rounded-xl px-4 py-2 mt-2">
            <p className="font-bengali-serif text-amber-300 text-sm sm:text-base font-bold italic tracking-wide">
              "{lang === 'bn' ? schoolInfo.mottoBn : schoolInfo.mottoEn}"
            </p>
          </div>

          <p className="text-slate-300 text-xs sm:text-base max-w-2xl mx-auto pt-2 leading-relaxed">
            {lang === 'bn'
              ? 'বোয়ালখালী উপজেলার কর্ণফুলী নদী তীরবর্তী ঐতিহাসিক বিদ্যাপীঠ; সুশৃঙ্খল পাঠদান, আধুনিক বিজ্ঞান ল্যাব, শেখ রাসেল ডিজিটাল ল্যাব ও সমৃদ্ধ পাঠাগারের মাধ্যমে আদর্শ দেশপ্রেমিক সুনাগরিক গড়ার অঙ্গীকার।'
              : 'A distinguished secondary academy in Boalkhali providing holistic education, modern digital labs, dedicated faculty, and historic campus environments since 1947.'}
          </p>

          {/* Action CTAs */}
          <div className="flex flex-wrap items-center justify-center gap-3 sm:gap-4 pt-5">
            <button
              onClick={onOpenAdmission}
              className="group flex items-center gap-2.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-emerald-950 font-black text-sm sm:text-base px-6 py-3.5 rounded-xl shadow-xl hover:shadow-amber-500/30 transition transform hover:-translate-y-0.5"
            >
              <GraduationCap size={20} className="text-emerald-950 group-hover:rotate-12 transition-transform" />
              <span>{lang === 'bn' ? 'অনলাইন ভর্তি আবেদন ২০২৬' : 'Online Admission 2026'}</span>
            </button>

            <button
              onClick={onOpenResults}
              className="flex items-center gap-2 bg-emerald-800/90 hover:bg-emerald-700/90 border border-emerald-600 text-white font-bold text-sm sm:text-base px-5 py-3.5 rounded-xl shadow-lg transition backdrop-blur-sm hover:border-amber-400"
            >
              <Search size={18} className="text-amber-300" />
              <span>{lang === 'bn' ? 'ফলাফল অনুসন্ধান' : 'Student Result Portal'}</span>
            </button>

            <button
              onClick={onNavigateTeachers}
              className="flex items-center gap-2 bg-emerald-950/80 hover:bg-emerald-900 border border-emerald-700 text-emerald-100 font-semibold text-sm sm:text-base px-5 py-3.5 rounded-xl transition"
            >
              <Users size={18} className="text-emerald-400" />
              <span>{lang === 'bn' ? 'শিক্ষক মণ্ডলী' : 'Our Teachers'}</span>
            </button>

            <button
              onClick={onNavigateNotices}
              className="flex items-center gap-2 bg-emerald-950/80 hover:bg-emerald-900 border border-emerald-700 text-emerald-100 font-semibold text-sm sm:text-base px-5 py-3.5 rounded-xl transition"
            >
              <FileText size={18} className="text-emerald-400" />
              <span>{lang === 'bn' ? 'নোটিশ বোর্ড' : 'Notices'}</span>
            </button>
          </div>
        </div>

        {/* Institutional Statistics Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4 mt-12 sm:mt-16">
          {schoolInfo.stats.map((stat, idx) => (
            <div
              key={idx}
              className="bg-emerald-900/40 border border-emerald-700/60 rounded-xl p-3.5 sm:p-4 text-center backdrop-blur-sm hover:bg-emerald-800/50 hover:border-amber-400/60 transition group shadow-md"
            >
              <div className="font-bengali-serif text-xl sm:text-2xl lg:text-3xl font-black text-amber-300 group-hover:scale-105 transition-transform">
                {lang === 'bn' ? stat.valueBn : stat.valueEn}
              </div>
              <div className="text-[11px] sm:text-xs text-emerald-200/90 font-medium mt-1 leading-snug">
                {lang === 'bn' ? stat.labelBn : stat.labelEn}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
