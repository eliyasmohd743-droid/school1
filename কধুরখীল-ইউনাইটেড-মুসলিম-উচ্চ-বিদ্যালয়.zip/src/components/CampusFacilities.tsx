import React from 'react';
import { useSchool } from '../context/SchoolContext';
import { CheckCircle2, Sparkles, Building, Laptop, Compass, Award } from 'lucide-react';

interface CampusFacilitiesProps {
  lang: 'bn' | 'en';
}

export const CampusFacilities: React.FC<CampusFacilitiesProps> = ({ lang }) => {
  const { facilities } = useSchool();
  return (
    <section id="facilities" className="py-14 sm:py-20 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <span className="text-xs font-bold uppercase tracking-wider text-emerald-800 bg-emerald-100 px-3 py-1 rounded-full border border-emerald-300">
            {lang === 'bn' ? 'ক্যাম্পাস ও আধুনিক সুযোগ-সুবিধা' : 'Campus Infrastructure & Facilities'}
          </span>
          <h2 className="font-bengali-serif text-2xl sm:text-4xl font-black text-slate-900 mt-2">
            {lang === 'bn' 
              ? 'শিক্ষা সহায়ক বিশ্বমানের পরিবেশ' 
              : 'Empowering Student Success with Modern Amenities'}
          </h2>
          <p className="text-slate-600 text-xs sm:text-sm mt-2">
            {lang === 'bn'
              ? 'ঐতিহাসিক লালার দীঘির স্নিগ্ধ প্রাকৃতিক সান্নিধ্য, ডিজিটাল প্রযুক্তি ও আধুনিক বিজ্ঞানের অপূর্ব মেলবন্ধন।'
              : 'A serene historical campus enhanced by state-of-the-art technological and scientific resources.'}
          </p>
          <div className="w-16 h-1 bg-amber-500 mx-auto mt-3 rounded-full"></div>
        </div>

        {/* Facilities Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {facilities.map((facility) => (
            <div
              key={facility.id}
              className="bg-slate-50 rounded-2xl border border-slate-200 overflow-hidden shadow-xs hover:shadow-xl transition-all duration-300 flex flex-col group hover:-translate-y-1"
            >
              <div className="relative aspect-16/10 overflow-hidden bg-slate-200">
                <img
                  src={facility.imageUrl}
                  alt={facility.titleBn}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  loading="lazy"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1562774053-701939374585?auto=format&fit=crop&w=800&q=80';
                  }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent"></div>
                <div className="absolute bottom-3 left-3 right-3">
                  <span className="bg-emerald-900/90 text-amber-300 text-[10px] font-bold px-2 py-0.5 rounded backdrop-blur-xs">
                    {lang === 'bn' ? 'কধুরখীল ইউ. মু. উচ্চ বিদ্যালয়' : 'KUMHS Campus'}
                  </span>
                </div>
              </div>

              <div className="p-6 flex-1 flex flex-col justify-between space-y-4">
                <div>
                  <h3 className="font-bengali-serif text-lg font-bold text-slate-900 group-hover:text-emerald-800 transition-colors">
                    {lang === 'bn' ? facility.titleBn : facility.titleEn}
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-600 mt-2 leading-relaxed">
                    {lang === 'bn' ? facility.descriptionBn : facility.descriptionEn}
                  </p>
                </div>

                <div className="pt-3 border-t border-slate-200 space-y-1.5">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
                    {lang === 'bn' ? 'প্রধান বৈশিষ্ঠ্যসমূহ:' : 'Key Highlights:'}
                  </span>
                  <div className="grid grid-cols-2 gap-1.5 text-xs text-slate-700">
                    {facility.features.map((feat, idx) => (
                      <div key={idx} className="flex items-center gap-1.5">
                        <CheckCircle2 size={13} className="text-emerald-600 shrink-0" />
                        <span className="text-[11px] font-medium">{feat}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
