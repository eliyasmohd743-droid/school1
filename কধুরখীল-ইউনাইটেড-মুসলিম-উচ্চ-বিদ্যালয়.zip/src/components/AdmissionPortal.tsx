import React, { useState } from 'react';
import { useSchool } from '../context/SchoolContext';
import { SchoolLogo } from './SchoolLogo';
import { 
  GraduationCap, 
  CheckCircle2, 
  FileCheck, 
  Printer, 
  AlertCircle, 
  Clock, 
  Send,
  Calendar,
  Sparkles,
  X
} from 'lucide-react';

interface AdmissionPortalProps {
  lang: 'bn' | 'en';
  isModal?: boolean;
  onCloseModal?: () => void;
}

export const AdmissionPortal: React.FC<AdmissionPortalProps> = ({
  lang,
  isModal = false,
  onCloseModal
}) => {
  const { schoolInfo } = useSchool();
  const [formData, setFormData] = useState({
    studentNameBn: '',
    studentNameEn: '',
    desiredClass: '৬ষ্ঠ শ্রেণি',
    gender: 'ছাত্র',
    dob: '',
    bloodGroup: 'B+',
    religion: 'ইসলাম',
    fatherName: '',
    fatherPhone: '',
    motherName: '',
    address: 'কধুরখীল, বোয়ালখালী, চট্টগ্রাম',
    prevSchool: '',
    prevGpa: '',
  });

  const [submittedApp, setSubmittedApp] = useState<any>(null);
  const [error, setError] = useState<string>('');

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.studentNameBn || !formData.studentNameEn || !formData.fatherName || !formData.fatherPhone) {
      setError(lang === 'bn' ? 'অনুগ্রহ করে সকল তারকা (*) চিহ্নিত প্রয়োজনীয় তথ্য পূরণ করুন।' : 'Please fill all mandatory fields marked with (*).');
      return;
    }

    const applicationNo = `KUMHS-2026-${Math.floor(100000 + Math.random() * 900000)}`;
    setSubmittedApp({
      ...formData,
      applicationNo,
      submissionDate: new Date().toLocaleDateString('bn-BD', { day: 'numeric', month: 'long', year: 'numeric' })
    });
    setError('');
  };

  const content = (
    <div className="max-w-5xl mx-auto px-4 sm:px-8">
      {/* Section Header */}
      <div className="text-center max-w-2xl mx-auto mb-10">
        <span className="text-xs font-bold uppercase tracking-wider text-emerald-800 bg-emerald-100 px-3 py-1 rounded-full border border-emerald-300">
          {lang === 'bn' ? 'অনলাইন ভর্তি ২০২৬' : 'Admission 2026'}
        </span>
        <h2 className="font-bengali-serif text-2xl sm:text-4xl font-black text-slate-900 mt-2">
          {lang === 'bn' ? 'অনলাইন ভর্তি আবেদন ও নির্দেশিকা' : 'Online Admission Application'}
        </h2>
        <p className="text-slate-600 text-xs sm:text-sm mt-2">
          {lang === 'bn'
            ? '২০২৬ শিক্ষাবর্ষে ৬ষ্ঠ হতে ৯ম শ্রেণির সীমিত সংখ্যক শূন্য আসনে ভর্তির জন্য আবেদনপত্র আহ্বান করা যাচ্ছে।'
            : 'Apply online for secondary grade admissions with fast digital verification.'}
        </p>
        <div className="w-16 h-1 bg-amber-500 mx-auto mt-3 rounded-full"></div>
      </div>

      {!submittedApp ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Left Column: Guidelines & Required Documents */}
          <div className="lg:col-span-5 space-y-6">
            <div className="bg-gradient-to-br from-emerald-900 to-emerald-950 text-white p-6 rounded-2xl shadow-md border border-emerald-800">
              <div className="flex items-center gap-2 text-amber-300 text-xs font-bold uppercase mb-2">
                <Sparkles size={15} />
                <span>ভর্তি যোগ্যতা ও তথ্য</span>
              </div>
              <h3 className="font-bengali-serif text-xl font-bold mb-3">
                {lang === 'bn' ? 'ভর্তির সাধারণ নীতিমালা' : 'Admission Requirements'}
              </h3>
              <ul className="space-y-2.5 text-xs text-emerald-100 leading-relaxed">
                <li className="flex items-start gap-2">
                  <CheckCircle2 size={15} className="text-amber-400 shrink-0 mt-0.5" />
                  <span>৬ষ্ঠ শ্রেণিতে ভর্তির ক্ষেত্রে ৫ম শ্রেণি উত্তীর্ণের সনদ ও প্রাথমিক সমাপনী মার্কশিট প্রযোজ্য।</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 size={15} className="text-amber-400 shrink-0 mt-0.5" />
                  <span>৭ম, ৮ম ও ৯ম শ্রেণিতে পূর্ববর্তী বিদ্যালয়ের ছাড়পত্র (টিসি) ও প্রশংসাপত্র প্রয়োজন।</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 size={15} className="text-amber-400 shrink-0 mt-0.5" />
                  <span>অনলাইন আবেদন জমা হওয়ার পর প্রাপ্ত অ্যাপ্লিকেশন স্লিপ প্রিন্ট করে অফিসে জমা দিতে হবে।</span>
                </li>
              </ul>

              <div className="mt-5 pt-4 border-t border-emerald-800 text-xs text-amber-200">
                <span className="font-bold">ভর্তি হেল্পলাইন:</span> {schoolInfo.phone}
              </div>
            </div>

            <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 space-y-3">
              <h4 className="font-bengali-serif text-base font-bold text-slate-900 flex items-center gap-2">
                <FileCheck size={18} className="text-emerald-700" />
                <span>প্রয়োজনীয় কাগজপত্র</span>
              </h4>
              <ul className="text-xs text-slate-600 space-y-2 list-disc list-inside">
                <li>শিক্ষার্থীর অনলাইন জন্ম নিবন্ধন সনদের ফটোকপি</li>
                <li>পিতা ও মাতার জাতীয় পরিচয়পত্রের (NID) ফটোকপি</li>
                <li>শিক্ষার্থীর ৩ কপি সদ্য তোলা পাসপোর্ট সাইজ রঙিন ছবি</li>
                <li>পূর্ববর্তী বিদ্যালয়ের মূল ছাড়পত্র (প্রযোজ্য ক্ষেত্রে)</li>
              </ul>
            </div>
          </div>

          {/* Right Column: Interactive Admission Form */}
          <div className="lg:col-span-7 bg-white p-6 sm:p-8 rounded-2xl shadow-md border border-slate-200">
            <h3 className="font-bengali-serif text-xl font-black text-slate-900 mb-4 pb-3 border-b border-slate-100">
              {lang === 'bn' ? 'অনলাইন ভর্তি ফরম ২০২৬' : 'Online Admission Form 2026'}
            </h3>

            {error && (
              <div className="mb-4 p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 text-xs flex items-center gap-2">
                <AlertCircle size={15} className="shrink-0 text-rose-600" />
                <span>{error}</span>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4 text-xs sm:text-sm">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    শিক্ষার্থীর নাম (বাংলায়) *
                  </label>
                  <input
                    type="text"
                    name="studentNameBn"
                    value={formData.studentNameBn}
                    onChange={handleInputChange}
                    placeholder="যেমন: তানভীর হাসান"
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-emerald-600"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    শিক্ষার্থীর নাম (ইংরেজিতে বড় অক্ষরে) *
                  </label>
                  <input
                    type="text"
                    name="studentNameEn"
                    value={formData.studentNameEn}
                    onChange={handleInputChange}
                    placeholder="e.g. TANVIR HASAN"
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs uppercase focus:outline-none focus:border-emerald-600"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    আবেদনের শ্রেণি *
                  </label>
                  <select
                    name="desiredClass"
                    value={formData.desiredClass}
                    onChange={handleInputChange}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-emerald-600 font-semibold"
                  >
                    <option value="৬ষ্ঠ শ্রেণি">৬ষ্ঠ শ্রেণি (Class 6)</option>
                    <option value="৭ম শ্রেণি">৭ম শ্রেণি (Class 7)</option>
                    <option value="৮ম শ্রেণি">৮ম শ্রেণি (Class 8)</option>
                    <option value="৯ম শ্রেণি (বিজ্ঞান)">৯ম শ্রেণি (বিজ্ঞান)</option>
                    <option value="৯ম শ্রেণি (ব্যবসায়)">৯ম শ্রেণি (ব্যবসায়)</option>
                    <option value="৯ম শ্রেণি (মানবিক)">৯ম শ্রেণি (মানবিক)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    জন্ম তারিখ *
                  </label>
                  <input
                    type="date"
                    name="dob"
                    value={formData.dob}
                    onChange={handleInputChange}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-emerald-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    রক্তের গ্রুপ
                  </label>
                  <select
                    name="bloodGroup"
                    value={formData.bloodGroup}
                    onChange={handleInputChange}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-emerald-600"
                  >
                    <option value="A+">A+</option>
                    <option value="A-">A-</option>
                    <option value="B+">B+</option>
                    <option value="B-">B-</option>
                    <option value="O+">O+</option>
                    <option value="O-">O-</option>
                    <option value="AB+">AB+</option>
                    <option value="AB-">AB-</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    পিতার নাম *
                  </label>
                  <input
                    type="text"
                    name="fatherName"
                    value={formData.fatherName}
                    onChange={handleInputChange}
                    placeholder="পিতার নাম লিখুন"
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-emerald-600"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    অভিভাবকের মোবাইল নম্বর *
                  </label>
                  <input
                    type="tel"
                    name="fatherPhone"
                    value={formData.fatherPhone}
                    onChange={handleInputChange}
                    placeholder="০১৮... / ০১..."
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-emerald-600 font-mono"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  বর্তমান ঠিকানা (গ্রাম, ইউনিয়ন, উপজেলা) *
                </label>
                <input
                  type="text"
                  name="address"
                  value={formData.address}
                  onChange={handleInputChange}
                  placeholder="যেমন: কধুরখীল, বোয়ালখালী, চট্টগ্রাম"
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-emerald-600"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    পূর্ববর্তী বিদ্যালয়ের নাম
                  </label>
                  <input
                    type="text"
                    name="prevSchool"
                    value={formData.prevSchool}
                    onChange={handleInputChange}
                    placeholder="আগের বিদ্যালয়ের নাম"
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-emerald-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    পূর্ববর্তী শ্রেণির রেজাল্ট / জিপিএ
                  </label>
                  <input
                    type="text"
                    name="prevGpa"
                    value={formData.prevGpa}
                    onChange={handleInputChange}
                    placeholder="যেমন: GPA 5.00 বা ১ম স্থান"
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-emerald-600"
                  />
                </div>
              </div>

              <div className="pt-3">
                <button
                  type="submit"
                  className="w-full bg-emerald-800 hover:bg-emerald-900 text-white font-bold py-3 rounded-xl shadow-md transition flex items-center justify-center gap-2"
                >
                  <Send size={16} />
                  <span>{lang === 'bn' ? 'অনলাইন আবেদন সাবমিট করুন' : 'Submit Application'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      ) : (
        /* Printable Official Application Slip */
        <div id="printable-section" className="bg-white rounded-3xl shadow-xl border-2 border-emerald-900 p-6 sm:p-10 relative">
          <div className="flex items-center justify-between pb-6 mb-6 border-b border-slate-200 no-print">
            <div className="flex items-center gap-2 text-emerald-800 font-bold text-sm">
              <CheckCircle2 size={20} className="text-emerald-600" />
              <span>আবেদন সফলভাবে গৃহীত হয়েছে! নিচে আপনার ভর্তি স্লিপ।</span>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setSubmittedApp(null)}
                className="text-xs font-bold text-slate-600 hover:text-slate-900 px-3 py-1.5 rounded-lg border border-slate-300"
              >
                নতুন আবেদন
              </button>
              <button
                onClick={() => window.print()}
                className="flex items-center gap-1.5 bg-emerald-800 hover:bg-emerald-900 text-white text-xs font-bold px-4 py-2 rounded-xl shadow-md"
              >
                <Printer size={15} />
                <span>স্লিপ প্রিন্ট করুন</span>
              </button>
            </div>
          </div>

          {/* Slip Header */}
          <div className="text-center pb-6 border-b border-emerald-800/30">
            <div className="flex items-center justify-center gap-3">
              <SchoolLogo size={60} />
              <div className="text-left">
                <h3 className="font-bengali-serif text-xl sm:text-2xl font-black text-emerald-950">
                  {schoolInfo.nameBn}
                </h3>
                <p className="text-xs text-slate-600">
                  {schoolInfo.addressBn} • EIIN: {schoolInfo.eiinEn}
                </p>
              </div>
            </div>
            <div className="inline-block bg-emerald-900 text-amber-300 font-black text-xs px-4 py-1 rounded-full uppercase mt-3">
              ভর্তি আবেদন নিশ্চিতকরণ স্লিপ (ADMISSION SLIP - 2026)
            </div>
          </div>

          {/* Slip Body */}
          <div className="grid grid-cols-2 gap-4 my-6 text-xs sm:text-sm bg-slate-50 p-5 rounded-2xl border border-slate-200">
            <div>
              <span className="text-slate-400 block text-[11px]">ট্র্যাকিং / অ্যাপ্লিকেশন নং:</span>
              <span className="font-mono font-black text-emerald-900 text-base">{submittedApp.applicationNo}</span>
            </div>
            <div>
              <span className="text-slate-400 block text-[11px]">আবেদনের তারিখ:</span>
              <span className="font-bold text-slate-800">{submittedApp.submissionDate}</span>
            </div>
            <div>
              <span className="text-slate-400 block text-[11px]">শিক্ষার্থীর নাম:</span>
              <span className="font-bold text-slate-900">{submittedApp.studentNameBn} ({submittedApp.studentNameEn})</span>
            </div>
            <div>
              <span className="text-slate-400 block text-[11px]">ভর্তির শ্রেণি:</span>
              <span className="font-bold text-emerald-800">{submittedApp.desiredClass}</span>
            </div>
            <div>
              <span className="text-slate-400 block text-[11px]">পিতার নাম ও মোবাইল:</span>
              <span className="font-semibold text-slate-800">{submittedApp.fatherName} ({submittedApp.fatherPhone})</span>
            </div>
            <div>
              <span className="text-slate-400 block text-[11px]">রক্তের গ্রুপ ও ধর্ম:</span>
              <span className="font-bold text-slate-800">{submittedApp.bloodGroup} • {submittedApp.religion}</span>
            </div>
          </div>

          <div className="p-4 bg-amber-50 rounded-xl border border-amber-200 text-xs text-amber-950 space-y-1">
            <p className="font-bold">গুরুত্বপূর্ণ নির্দেশনা:</p>
            <p>এই স্লিপটি প্রিন্ট করে উল্লেখিত কাগজপত্রসহ আগামী ৭ কর্মদিবসের মধ্যে বিদ্যালয় প্রশাসনিক কার্যালয়ে জমা প্রদান করার জন্য অনুরোধ করা হলো।</p>
          </div>

          <div className="pt-10 flex justify-between text-xs text-slate-500 text-center">
            <div>
              <div className="w-28 border-b border-slate-400 mb-1"></div>
              <span>অভিভাবকের স্বাক্ষর</span>
            </div>
            <div>
              <div className="w-32 border-b border-emerald-900 mb-1"></div>
              <span className="font-bold text-emerald-900">ভর্তি কমিটির স্বাক্ষর ও সিল</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );

  if (isModal) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs overflow-y-auto animate-fadeIn">
        <div 
          className="bg-slate-50 rounded-3xl max-w-4xl w-full shadow-2xl border border-slate-200 overflow-hidden transform animate-scaleUp my-8 relative max-h-[90vh] overflow-y-auto"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="sticky top-0 right-0 z-20 flex justify-end p-4 bg-white/80 backdrop-blur-sm border-b border-slate-200">
            <button
              onClick={onCloseModal}
              className="p-1.5 rounded-full bg-slate-200 hover:bg-slate-300 text-slate-800 transition"
              aria-label="Close"
            >
              <X size={20} />
            </button>
          </div>
          <div className="py-6">
            {content}
          </div>
        </div>
      </div>
    );
  }

  return (
    <section id="admission" className="py-14 sm:py-20 bg-slate-50 border-b border-slate-200">
      {content}
    </section>
  );
};
