import React from 'react';

interface SchoolLogoProps {
  className?: string;
  size?: number;
  showText?: boolean;
  textClassName?: string;
  subTextClassName?: string;
  variant?: 'full' | 'icon' | 'badge';
}

export const SchoolLogo: React.FC<SchoolLogoProps> = ({
  className = '',
  size = 64,
  showText = false,
  textClassName = 'text-emerald-950',
  subTextClassName = 'text-emerald-800',
  variant = 'icon'
}) => {
  return (
    <div className={`inline-flex items-center gap-3 ${className}`}>
      {/* Authentic High-Resolution Vector Crest */}
      <svg
        width={size}
        height={size}
        viewBox="0 0 200 200"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="shrink-0 drop-shadow-md select-none transition-transform hover:scale-105 duration-300"
      >
        <defs>
          {/* Radial & Linear Gradients */}
          <linearGradient id="crestGold" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#fef08a" />
            <stop offset="35%" stopColor="#eab308" />
            <stop offset="70%" stopColor="#ca8a04" />
            <stop offset="100%" stopColor="#854d0e" />
          </linearGradient>

          <linearGradient id="crestGreen" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#065f46" />
            <stop offset="60%" stopColor="#047857" />
            <stop offset="100%" stopColor="#064e3b" />
          </linearGradient>

          <linearGradient id="flameGrad" x1="0%" y1="100%" x2="0%" y2="0%">
            <stop offset="0%" stopColor="#dc2626" />
            <stop offset="50%" stopColor="#f97316" />
            <stop offset="100%" stopColor="#fde047" />
          </linearGradient>

          <filter id="logoShadow" x="-10%" y="-10%" width="120%" height="120%">
            <feDropShadow dx="0" dy="2" stdDeviation="3" floodOpacity="0.25" />
          </filter>

          {/* Text paths for curved text */}
          <path id="textPathTop" d="M 30,100 A 70,70 0 1,1 170,100" fill="none" />
          <path id="textPathBottom" d="M 170,100 A 70,70 0 0,1 30,100" fill="none" />
        </defs>

        {/* Outer Golden Serrated / Beaded Ring */}
        <circle cx="100" cy="100" r="96" fill="url(#crestGold)" stroke="#78350f" strokeWidth="2" filter="url(#logoShadow)" />
        <circle cx="100" cy="100" r="91" fill="#ffffff" stroke="url(#crestGold)" strokeWidth="1.5" />

        {/* Main Emerald Circular Ribbon */}
        <circle cx="100" cy="100" r="87" fill="url(#crestGreen)" stroke="#ca8a04" strokeWidth="2.5" />

        {/* Inner Golden Ring */}
        <circle cx="100" cy="100" r="61" fill="#f8fafc" stroke="url(#crestGold)" strokeWidth="3" />

        {/* Curved Bengali Inscription on Ribbon */}
        <text fill="#ffffff" fontSize="11" fontWeight="700" letterSpacing="0.8">
          <textPath href="#textPathTop" startOffset="50%" textAnchor="middle">
            কধুরখীল ইউনাইটেড মুসলিম উচ্চ বিদ্যালয়
          </textPath>
        </text>

        <text fill="#fef08a" fontSize="9.5" fontWeight="600" letterSpacing="0.5">
          <textPath href="#textPathBottom" startOffset="50%" textAnchor="middle">
            ★ বোয়ালখালী, চট্টগ্রাম • স্থাপিত: ১৯৪৭ ★
          </textPath>
        </text>

        {/* Inner Center Scene: Rising Sun of Wisdom behind Lake & Book */}
        {/* Sun rays */}
        <g stroke="#f59e0b" strokeWidth="1.5" opacity="0.6">
          <line x1="100" y1="58" x2="100" y2="48" />
          <line x1="86" y1="62" x2="79" y2="54" />
          <line x1="114" y1="62" x2="121" y2="54" />
          <line x1="75" y1="73" x2="66" y2="67" />
          <line x1="125" y1="73" x2="134" y2="67" />
        </g>
        
        {/* Rising Sun Disk */}
        <circle cx="100" cy="80" r="16" fill="#fde047" opacity="0.85" />

        {/* Water Waves (Lalar Dighi Symbolism) */}
        <path d="M 64,118 Q 72,114 80,118 T 96,118 T 112,118 T 128,118 T 136,118" stroke="#0284c7" strokeWidth="1.5" fill="none" opacity="0.5" />
        <path d="M 66,122 Q 74,119 82,122 T 98,122 T 114,122 T 130,122" stroke="#38bdf8" strokeWidth="1.5" fill="none" opacity="0.4" />

        {/* Golden Laurel / Paddy Sheaf Wreath */}
        <g fill="url(#crestGold)" stroke="#a16207" strokeWidth="0.5">
          {/* Left Laurel */}
          <path d="M 66,95 C 62,88 64,78 70,82 C 67,88 69,92 66,95 Z" />
          <path d="M 62,108 C 58,101 60,93 66,96 C 64,102 65,106 62,108 Z" />
          <path d="M 65,120 C 62,114 65,107 70,110 C 68,115 69,118 65,120 Z" />
          <path d="M 74,130 C 70,126 73,119 79,122 C 77,126 78,128 74,130 Z" />
          
          {/* Right Laurel */}
          <path d="M 134,95 C 138,88 136,78 130,82 C 133,88 131,92 134,95 Z" />
          <path d="M 138,108 C 142,101 140,93 134,96 C 136,102 135,106 138,108 Z" />
          <path d="M 135,120 C 138,114 135,107 130,110 C 132,115 131,118 135,120 Z" />
          <path d="M 126,130 C 130,126 127,119 121,122 C 123,126 122,128 126,130 Z" />
        </g>

        {/* Central Torch / Flame of Knowledge */}
        <g transform="translate(0, -6)">
          {/* Torch Handle */}
          <path d="M 98,100 L 102,100 L 101,112 L 99,112 Z" fill="#b45309" stroke="#78350f" strokeWidth="0.5" />
          <polygon points="95,99 105,99 103,94 97,94" fill="#d97706" />
          {/* Flame */}
          <path
            d="M 100,74 C 94,83 95,89 97,93 C 98,94 102,94 103,93 C 105,89 106,83 100,74 Z"
            fill="url(#flameGrad)"
            stroke="#b91c1c"
            strokeWidth="0.5"
          />
          <circle cx="100" cy="88" r="2.5" fill="#fef08a" />
        </g>

        {/* Open Book of Education */}
        <g transform="translate(0, 10)">
          {/* Pages Base */}
          <path
            d="M 76,102 C 86,97 96,99 100,103 C 104,99 114,97 124,102 L 122,117 C 112,112 104,114 100,118 C 96,114 88,112 78,117 Z"
            fill="#ffffff"
            stroke="#0f172a"
            strokeWidth="1.2"
          />
          {/* Spine & Page Lines */}
          <path d="M 100,103 L 100,118" stroke="#0f172a" strokeWidth="1.5" />
          <line x1="81" y1="105" x2="95" y2="103" stroke="#94a3b8" strokeWidth="1" />
          <line x1="81" y1="109" x2="95" y2="107" stroke="#94a3b8" strokeWidth="1" />
          <line x1="81" y1="113" x2="94" y2="111" stroke="#94a3b8" strokeWidth="1" />
          
          <line x1="105" y1="103" x2="119" y2="105" stroke="#94a3b8" strokeWidth="1" />
          <line x1="105" y1="107" x2="119" y2="109" stroke="#94a3b8" strokeWidth="1" />
          <line x1="106" y1="111" x2="119" y2="113" stroke="#94a3b8" strokeWidth="1" />
        </g>

        {/* EIIN Mini Ribbon Badge */}
        <g transform="translate(0, 16)">
          <rect x="74" y="124" width="52" height="15" rx="3" fill="#045d39" stroke="#ca8a04" strokeWidth="1" />
          <text x="100" y="135" fill="#ffffff" fontSize="8" fontWeight="800" textAnchor="middle" letterSpacing="0.5">
            EIIN: 104111
          </text>
        </g>
      </svg>

      {/* Optional Side Text */}
      {showText && (
        <div className="flex flex-col">
          <span className={`font-bengali-serif text-lg sm:text-xl font-bold leading-tight tracking-tight ${textClassName}`}>
            কধুরখীল ইউনাইটেড মুসলিম উচ্চ বিদ্যালয়
          </span>
          <span className={`text-xs sm:text-sm font-semibold tracking-wide ${subTextClassName}`}>
            Kadhurkhil United Muslim High School • Boalkhali, Chattogram
          </span>
          <div className="flex items-center gap-2 mt-0.5">
            <span className="text-[10px] font-bold bg-amber-100 text-amber-900 border border-amber-300 px-1.5 py-0.5 rounded">
              স্থাপিত: ১৯৪৭
            </span>
            <span className="text-[10px] font-bold bg-emerald-100 text-emerald-900 border border-emerald-300 px-1.5 py-0.5 rounded">
              EIIN: ১০৪১১১
            </span>
            <span className="text-[10px] font-bold bg-slate-100 text-slate-700 border border-slate-300 px-1.5 py-0.5 rounded hidden sm:inline">
              কোড: ৩৪৫০
            </span>
          </div>
        </div>
      )}
    </div>
  );
};
