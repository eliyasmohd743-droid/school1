import React, { useState, useMemo, useEffect } from 'react';
import { useSchool } from '../context/SchoolContext';
import { Teacher } from '../types';
import { 
  Search, 
  Phone, 
  Mail, 
  Award, 
  GraduationCap, 
  Calendar, 
  Droplet, 
  UserCheck, 
  X, 
  Briefcase,
  Users,
  ShieldCheck,
  CheckCircle2,
  Camera,
  Upload,
  RotateCcw,
  User,
  Sparkles
} from 'lucide-react';

interface TeachersDirectoryProps {
  lang: 'bn' | 'en';
}

// Resilient Image component with fallback
const TeacherImage: React.FC<{
  src: string;
  alt: string;
  className?: string;
  initials: string;
}> = ({ src, alt, className = '', initials }) => {
  const [hasError, setHasError] = useState(false);

  if (hasError || !src) {
    return (
      <div className={`flex flex-col items-center justify-center bg-gradient-to-br from-emerald-800 to-emerald-950 text-white font-bold ${className}`}>
        <User size={32} className="text-amber-300 mb-1 opacity-80" />
        <span className="text-xs font-mono tracking-wider">{initials}</span>
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={alt}
      className={className}
      onError={() => setHasError(true)}
      loading="lazy"
    />
  );
};

export const TeachersDirectory: React.FC<TeachersDirectoryProps> = ({ lang }) => {
  const { teachers, committee } = useSchool();
  const [selectedDept, setSelectedDept] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeTeacher, setActiveTeacher] = useState<Teacher | null>(null);
  const [showCommittee, setShowCommittee] = useState<boolean>(false);

  // Local storage custom photo overrides so user can upload real photos of teachers!
  const [customPhotos, setCustomPhotos] = useState<{ [id: string]: string }>({});
  const [isEditingPhoto, setIsEditingPhoto] = useState<boolean>(false);
  const [photoInputUrl, setPhotoInputUrl] = useState<string>('');

  useEffect(() => {
    try {
      const saved = localStorage.getItem('kumhs_teacher_custom_photos');
      if (saved) {
        setCustomPhotos(JSON.parse(saved));
      }
    } catch (e) {
      console.error(e);
    }
  }, []);

  const saveCustomPhoto = (teacherId: string, url: string) => {
    const updated = { ...customPhotos, [teacherId]: url };
    setCustomPhotos(updated);
    try {
      localStorage.setItem('kumhs_teacher_custom_photos', JSON.stringify(updated));
    } catch (e) {
      console.error(e);
    }
    setIsEditingPhoto(false);
    setPhotoInputUrl('');
    if (activeTeacher) {
      setActiveTeacher({ ...activeTeacher, photoUrl: url });
    }
  };

  const resetCustomPhoto = (teacherId: string) => {
    const updated = { ...customPhotos };
    delete updated[teacherId];
    setCustomPhotos(updated);
    try {
      localStorage.setItem('kumhs_teacher_custom_photos', JSON.stringify(updated));
    } catch (e) {
      console.error(e);
    }
    const original = teachers.find((t: Teacher) => t.id === teacherId);
    if (original && activeTeacher) {
      setActiveTeacher({ ...activeTeacher, photoUrl: original.photoUrl });
    }
    setIsEditingPhoto(false);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>, teacherId: string) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (uploadEvent) => {
        const result = uploadEvent.target?.result as string;
        if (result) {
          saveCustomPhoto(teacherId, result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const departments = [
    { id: 'all', labelBn: 'সকল শিক্ষক ও স্টাফ', labelEn: 'All Faculty & Staff' },
    { id: 'admin', labelBn: 'প্রশাসন ও প্রধান শিক্ষক', labelEn: 'Administration' },
    { id: 'science', labelBn: 'বিজ্ঞান ও গণিত', labelEn: 'Science & Math' },
    { id: 'arts', labelBn: 'ভাষা ও মানবিক', labelEn: 'Languages & Humanities' },
    { id: 'commerce', labelBn: 'ব্যবসায় শিক্ষা', labelEn: 'Commerce' },
    { id: 'ict-sports', labelBn: 'আইসিটি ও ক্রীড়া', labelEn: 'ICT & Sports' },
    { id: 'office', labelBn: 'অফিস প্রশাসন', labelEn: 'Office Staff' },
  ];

  const filteredTeachers = useMemo(() => {
    return teachers.filter((teacher) => {
      // Dept filtering
      const matchesDept = 
        selectedDept === 'all' ||
        (selectedDept === 'admin' && (teacher.isHeadmaster || teacher.isAssistantHead)) ||
        (selectedDept === 'science' && (teacher.departmentBn.includes('বিজ্ঞান') || teacher.subjectBn.includes('পদার্থ') || teacher.subjectBn.includes('রসায়ন') || teacher.subjectBn.includes('গণিত') || teacher.subjectBn.includes('জীব'))) ||
        (selectedDept === 'arts' && (teacher.departmentBn.includes('ভাষা') || teacher.departmentBn.includes('মানবিক') || teacher.departmentBn.includes('ধর্ম') || teacher.subjectBn.includes('বাংলা') || teacher.subjectBn.includes('ইংরেজি'))) ||
        (selectedDept === 'commerce' && (teacher.departmentBn.includes('ব্যবসায়') || teacher.subjectBn.includes('হিসাববিজ্ঞান'))) ||
        (selectedDept === 'ict-sports' && (teacher.departmentBn.includes('তথ্য') || teacher.departmentBn.includes('শারীরিক') || teacher.subjectBn.includes('ICT') || teacher.subjectBn.includes('খেলাধুলা'))) ||
        (selectedDept === 'office' && (teacher.departmentBn.includes('অফিস') || teacher.departmentBn.includes('হিসাব ও অডিট')));

      // Search query
      const query = searchQuery.toLowerCase().trim();
      const matchesSearch = 
        !query ||
        teacher.nameBn.toLowerCase().includes(query) ||
        teacher.nameEn.toLowerCase().includes(query) ||
        teacher.subjectBn.toLowerCase().includes(query) ||
        teacher.designationBn.toLowerCase().includes(query);

      return matchesDept && matchesSearch;
    });
  }, [selectedDept, searchQuery]);

  return (
    <section id="teachers" className="py-14 sm:py-20 bg-slate-100 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-10">
          <span className="text-xs font-bold uppercase tracking-wider text-emerald-800 bg-emerald-100 px-3 py-1 rounded-full border border-emerald-300">
            {lang === 'bn' ? 'আমাদের শিক্ষকমণ্ডলী' : 'Our Faculty & Staff'}
          </span>
          <h2 className="font-bengali-serif text-2xl sm:text-4xl font-black text-slate-900 mt-2">
            {lang === 'bn' 
              ? 'অভিজ্ঞ ও নিবেদিতপ্রাণ শিক্ষক-কর্মচারীবৃন্দ' 
              : 'Dedicated Mentors & Staff Members'}
          </h2>
          <p className="text-slate-600 text-xs sm:text-sm mt-2">
            {lang === 'bn'
              ? 'কধুরখীল ইউনাইটেড মুসলিম উচ্চ বিদ্যালয়ের শিক্ষার্থীদের মেধা ও চরিত্র গঠনে নিরলস পরিশ্রম করে চলেছেন আমাদের অভিজ্ঞ শিক্ষকমণ্ডলী।'
              : 'Our accomplished educators guiding students towards intellectual brilliance and moral integrity.'}
          </p>
          <div className="w-16 h-1 bg-amber-500 mx-auto mt-3 rounded-full"></div>
        </div>

        {/* View Switcher: Teachers vs Managing Committee */}
        <div className="flex justify-center mb-8">
          <div className="inline-flex p-1 bg-white rounded-xl shadow-xs border border-slate-300">
            <button
              onClick={() => setShowCommittee(false)}
              className={`flex items-center gap-2 px-5 py-2 rounded-lg text-xs sm:text-sm font-bold transition ${
                !showCommittee
                  ? 'bg-emerald-800 text-white shadow-sm'
                  : 'text-slate-600 hover:text-emerald-800'
              }`}
            >
              <Users size={16} />
              <span>{lang === 'bn' ? 'শিক্ষক ও কর্মচারীবৃন্দ (১৪+)' : 'Faculty & Staff (14+)'}</span>
            </button>
            <button
              onClick={() => setShowCommittee(true)}
              className={`flex items-center gap-2 px-5 py-2 rounded-lg text-xs sm:text-sm font-bold transition ${
                showCommittee
                  ? 'bg-emerald-800 text-white shadow-sm'
                  : 'text-slate-600 hover:text-emerald-800'
              }`}
            >
              <ShieldCheck size={16} />
              <span>{lang === 'bn' ? 'ম্যানেজিং কমিটি (পরিচালনা পর্ষদ)' : 'Managing Committee'}</span>
            </button>
          </div>
        </div>

        {!showCommittee ? (
          <>
            {/* Search Bar & Department Filter Chips */}
            <div className="bg-white p-4 rounded-2xl shadow-sm border border-slate-200 mb-8 space-y-4">
              {/* Search box */}
              <div className="relative max-w-md mx-auto">
                <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder={lang === 'bn' ? 'নাম বা বিষয় দিয়ে শিক্ষক খুঁজুন...' : 'Search teacher by name or subject...'}
                  className="w-full pl-10 pr-4 py-2 text-xs sm:text-sm rounded-xl border border-slate-300 focus:outline-none focus:border-emerald-600 focus:ring-2 focus:ring-emerald-100"
                />
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery('')}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                  >
                    <X size={16} />
                  </button>
                )}
              </div>

              {/* Department Pills */}
              <div className="flex flex-wrap items-center justify-center gap-1.5 sm:gap-2 pt-1">
                {departments.map((dept) => (
                  <button
                    key={dept.id}
                    onClick={() => setSelectedDept(dept.id)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
                      selectedDept === dept.id
                        ? 'bg-emerald-800 text-amber-300 shadow-xs'
                        : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                    }`}
                  >
                    {lang === 'bn' ? dept.labelBn : dept.labelEn}
                  </button>
                ))}
              </div>
            </div>

            {/* Teachers Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
              {filteredTeachers.map((teacher) => {
                const isLeader = teacher.isHeadmaster || teacher.isAssistantHead;
                const activePhotoUrl = customPhotos[teacher.id] || teacher.photoUrl;

                return (
                  <div
                    key={teacher.id}
                    onClick={() => {
                      setActiveTeacher({ ...teacher, photoUrl: activePhotoUrl });
                      setIsEditingPhoto(false);
                    }}
                    className={`bg-white rounded-2xl shadow-sm border hover:shadow-xl transition-all duration-300 flex flex-col overflow-hidden cursor-pointer group transform hover:-translate-y-1 ${
                      isLeader 
                        ? 'border-amber-400/80 ring-2 ring-amber-400/20' 
                        : 'border-slate-200'
                    }`}
                  >
                    {/* Photo Container */}
                    <div className="relative aspect-4/3 bg-slate-200 overflow-hidden">
                      <TeacherImage
                        src={activePhotoUrl}
                        alt={teacher.nameBn}
                        initials={teacher.nameBn.slice(0, 2)}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent opacity-80"></div>
                      
                      {/* Designation Tag in Photo */}
                      <div className="absolute bottom-2.5 left-2.5 right-2.5 flex items-center justify-between">
                        <span className={`text-[11px] font-bold px-2 py-0.5 rounded shadow-sm ${
                          teacher.isHeadmaster
                            ? 'bg-amber-500 text-slate-950'
                            : teacher.isAssistantHead
                            ? 'bg-emerald-600 text-white'
                            : 'bg-slate-900/80 text-amber-300 backdrop-blur-xs'
                        }`}>
                          {lang === 'bn' ? teacher.designationBn : teacher.designationEn}
                        </span>

                        <span className="text-[10px] font-bold bg-white/90 text-rose-700 px-1.5 py-0.5 rounded">
                          {teacher.bloodGroup}
                        </span>
                      </div>
                    </div>

                    {/* Teacher Details */}
                    <div className="p-4 flex-1 flex flex-col justify-between space-y-2.5">
                      <div>
                        <h3 className="font-bengali-serif text-base sm:text-lg font-bold text-slate-900 group-hover:text-emerald-800 transition-colors">
                          {lang === 'bn' ? teacher.nameBn : teacher.nameEn}
                        </h3>
                        <p className="text-[11px] font-semibold text-emerald-800">
                          {lang === 'bn' ? teacher.subjectBn : teacher.subjectEn}
                        </p>
                        <p className="text-[11px] text-slate-500 mt-1 line-clamp-1">
                          {lang === 'bn' ? teacher.qualificationBn : teacher.qualificationEn}
                        </p>
                      </div>

                      {/* Footer Actions */}
                      <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
                        <span className="text-[11px] text-slate-500 font-medium">
                          {lang === 'bn' ? `যোগদান: ${teacher.joinDate}` : `Joined: ${teacher.joinDate}`}
                        </span>

                        <span className="text-emerald-700 font-bold group-hover:underline text-[11px]">
                          {lang === 'bn' ? 'বিস্তারিত' : 'View Profile'} &rarr;
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {filteredTeachers.length === 0 && (
              <div className="text-center py-12 bg-white rounded-2xl border border-slate-200">
                <Users className="w-12 h-12 text-slate-300 mx-auto mb-2" />
                <p className="text-sm font-semibold text-slate-600">
                  {lang === 'bn' ? 'কোনো শিক্ষকের তথ্য খুঁজে পাওয়া যায়নি।' : 'No teachers found matching criteria.'}
                </p>
                <button
                  onClick={() => { setSelectedDept('all'); setSearchQuery(''); }}
                  className="mt-3 text-xs font-bold text-emerald-700 hover:underline"
                >
                  {lang === 'bn' ? 'সকল শিক্ষক দেখুন' : 'Reset Filters'}
                </button>
              </div>
            )}
          </>
        ) : (
          /* Managing Committee Grid */
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
            {committee.map((member) => (
              <div
                key={member.id}
                className="bg-white rounded-2xl shadow-sm border border-slate-200 p-5 flex items-center gap-4 hover:shadow-md transition"
              >
                <TeacherImage
                  src={member.photoUrl}
                  alt={member.nameBn}
                  initials={member.nameBn.slice(0, 2)}
                  className="w-20 h-20 rounded-xl object-cover border-2 border-amber-400 shrink-0"
                />
                <div className="space-y-1">
                  <span className="text-[10px] font-bold bg-amber-100 text-amber-900 border border-amber-300 px-2 py-0.5 rounded">
                    {lang === 'bn' ? member.roleBn : member.roleEn}
                  </span>
                  <h3 className="font-bengali-serif text-base font-bold text-slate-900">
                    {lang === 'bn' ? member.nameBn : member.nameEn}
                  </h3>
                  <p className="text-xs text-slate-600">
                    {lang === 'bn' ? member.occupationBn : 'Distinguished Committee Member'}
                  </p>
                  {member.phone && (
                    <p className="text-xs font-semibold text-emerald-800 pt-1">
                      📞 {member.phone}
                    </p>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Teacher Detailed Modal with Custom Real Photo Upload Option */}
        {activeTeacher && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fadeIn">
            <div 
              className="bg-white rounded-3xl max-w-lg w-full shadow-2xl border border-slate-200 overflow-hidden transform animate-scaleUp max-h-[90vh] overflow-y-auto"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Modal Header */}
              <div className="bg-gradient-to-r from-emerald-900 to-emerald-800 text-white p-6 relative">
                <button
                  onClick={() => { setActiveTeacher(null); setIsEditingPhoto(false); }}
                  className="absolute top-4 right-4 p-1.5 rounded-full bg-black/30 hover:bg-black/50 text-white transition"
                  aria-label="Close"
                >
                  <X size={20} />
                </button>

                <div className="flex items-center gap-4">
                  <div className="relative">
                    <TeacherImage
                      src={customPhotos[activeTeacher.id] || activeTeacher.photoUrl}
                      alt={activeTeacher.nameBn}
                      initials={activeTeacher.nameBn.slice(0, 2)}
                      className="w-20 h-20 rounded-2xl object-cover border-3 border-amber-400 shadow-md"
                    />
                    <button
                      onClick={() => setIsEditingPhoto(!isEditingPhoto)}
                      className="absolute -bottom-1 -right-1 p-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-full shadow-md text-xs font-bold transition"
                      title="বাস্তব ছবি আপলোড বা পরিবর্তন করুন"
                    >
                      <Camera size={14} />
                    </button>
                  </div>

                  <div>
                    <span className="text-[10px] font-bold bg-amber-400 text-slate-950 px-2 py-0.5 rounded uppercase">
                      {lang === 'bn' ? activeTeacher.designationBn : activeTeacher.designationEn}
                    </span>
                    <h3 className="font-bengali-serif text-xl font-bold text-white mt-1">
                      {lang === 'bn' ? activeTeacher.nameBn : activeTeacher.nameEn}
                    </h3>
                    <p className="text-emerald-200 text-xs font-medium">
                      {lang === 'bn' ? activeTeacher.departmentBn : activeTeacher.departmentEn}
                    </p>
                  </div>
                </div>
              </div>

              {/* Photo Upload / Update Panel */}
              {isEditingPhoto && (
                <div className="bg-amber-50 p-4 border-b border-amber-200 text-xs text-amber-950 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="font-bold flex items-center gap-1.5 text-emerald-900">
                      <Camera size={15} />
                      <span>{lang === 'bn' ? 'শিক্ষকের আসল ছবি যুক্ত করুন' : 'Upload Real Teacher Photo'}</span>
                    </span>
                    {customPhotos[activeTeacher.id] && (
                      <button
                        onClick={() => resetCustomPhoto(activeTeacher.id)}
                        className="text-[11px] text-rose-700 hover:underline flex items-center gap-1 font-semibold"
                      >
                        <RotateCcw size={12} />
                        <span>ডিফল্ট রিসেট</span>
                      </button>
                    )}
                  </div>

                  {/* File Upload Button */}
                  <div className="flex flex-col gap-2">
                    <label className="flex items-center justify-center gap-2 bg-emerald-800 hover:bg-emerald-700 text-white font-bold py-2 px-3 rounded-xl cursor-pointer transition">
                      <Upload size={14} />
                      <span>{lang === 'bn' ? 'কম্পিউটার/মোবাইল থেকে ছবি আপলোড করুন' : 'Upload Image from Device'}</span>
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={(e) => handleFileUpload(e, activeTeacher.id)}
                      />
                    </label>

                    {/* Or URL Input */}
                    <div className="flex gap-2 pt-1">
                      <input
                        type="url"
                        placeholder={lang === 'bn' ? 'বা ফেসবুক / ছবির অনলাইন লিংক পেস্ট করুন...' : 'Or paste image URL...'}
                        value={photoInputUrl}
                        onChange={(e) => setPhotoInputUrl(e.target.value)}
                        className="flex-1 bg-white border border-amber-300 rounded-lg px-2.5 py-1.5 text-xs focus:outline-none"
                      />
                      <button
                        onClick={() => {
                          if (photoInputUrl.trim()) {
                            saveCustomPhoto(activeTeacher.id, photoInputUrl.trim());
                          }
                        }}
                        className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold px-3 py-1.5 rounded-lg text-xs"
                      >
                        সংরক্ষণ
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* Modal Body */}
              <div className="p-6 space-y-4 text-xs sm:text-sm text-slate-700">
                <div className="grid grid-cols-2 gap-3 bg-slate-50 p-3.5 rounded-xl border border-slate-200">
                  <div>
                    <span className="text-[10px] text-slate-400 uppercase font-bold block">পাঠদানের বিষয়</span>
                    <span className="font-bold text-emerald-900">{activeTeacher.subjectBn}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 uppercase font-bold block">রক্তের গ্রুপ</span>
                    <span className="font-bold text-rose-600">{activeTeacher.bloodGroup}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 uppercase font-bold block">শিক্ষাগত যোগ্যতা</span>
                    <span className="font-bold text-slate-800">{activeTeacher.qualificationBn}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 uppercase font-bold block">যোগদানের সাল</span>
                    <span className="font-bold text-slate-800">{activeTeacher.joinDate}</span>
                  </div>
                </div>

                <div>
                  <h4 className="font-bold text-slate-900 mb-1">শিক্ষক পরিচিতি ও ভূমিকা</h4>
                  <p className="leading-relaxed text-slate-600 bg-emerald-50/50 p-3 rounded-lg border border-emerald-100">
                    {lang === 'bn' ? activeTeacher.bioBn : activeTeacher.bioEn}
                  </p>
                </div>

                <div className="pt-2 flex flex-col sm:flex-row gap-2">
                  <a
                    href={`tel:${activeTeacher.phone}`}
                    className="flex-1 flex items-center justify-center gap-2 bg-emerald-800 hover:bg-emerald-900 text-white font-bold py-2.5 rounded-xl transition"
                  >
                    <Phone size={15} />
                    <span>কল করুন ({activeTeacher.phone})</span>
                  </a>
                  <a
                    href={`mailto:${activeTeacher.email}`}
                    className="flex-1 flex items-center justify-center gap-2 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold py-2.5 rounded-xl border border-slate-300 transition"
                  >
                    <Mail size={15} />
                    <span>ইমেইল পাঠান</span>
                  </a>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
