import React, { useState } from 'react';
import { SchoolLogo } from './SchoolLogo';
import { schoolInfo } from '../data/schoolData';
import { 
  Phone, 
  Mail, 
  MapPin, 
  Globe, 
  Menu, 
  X, 
  GraduationCap, 
  FileText, 
  Users, 
  Calendar, 
  Award, 
  Image as ImageIcon, 
  Building2, 
  ExternalLink,
  Search,
  Settings,
  Sparkles
} from 'lucide-react';
import { useSchool } from '../context/SchoolContext';

interface NavbarProps {
  currentSection: string;
  onNavigate: (sectionId: string) => void;
  lang: 'bn' | 'en';
  onToggleLang: () => void;
  onOpenResultModal: () => void;
  onOpenAdmissionModal: () => void;
  onOpenCustomizer: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentSection,
  onNavigate,
  lang,
  onToggleLang,
  onOpenResultModal,
  onOpenAdmissionModal,
  onOpenCustomizer
}) => {
  const { schoolInfo } = useSchool();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = [
    { id: 'hero', labelBn: 'হোম', labelEn: 'Home', icon: null },
    { id: 'about', labelBn: 'আমাদের কথা', labelEn: 'About Us', icon: Building2 },
    { id: 'teachers', labelBn: 'শিক্ষক মণ্ডলী', labelEn: 'Teachers', icon: Users },
    { id: 'notices', labelBn: 'নোটিশ বোর্ড', labelEn: 'Notices', icon: FileText },
    { id: 'results', labelBn: 'ফলাফল', labelEn: 'Results', icon: Award },
    { id: 'routine', labelBn: 'রুটিন', labelEn: 'Routine', icon: Calendar },
    { id: 'admission', labelBn: 'ভর্তি তথ্য', labelEn: 'Admission', icon: GraduationCap },
    { id: 'facilities', labelBn: 'সুযোগ-সুবিধা', labelEn: 'Facilities', icon: Building2 },
    { id: 'gallery', labelBn: 'চিত্রশালা', labelEn: 'Gallery', icon: ImageIcon },
    { id: 'location-contact', labelBn: 'যোগাযোগ ও ম্যাপ', labelEn: 'Contact & Map', icon: MapPin },
  ];

  const handleNavClick = (id: string) => {
    onNavigate(id);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-50 bg-white shadow-md border-b border-emerald-900/10">
      {/* Top Utility Ribbon */}
      <div className="bg-emerald-900 text-emerald-100 text-xs py-1.5 px-4 sm:px-8 border-b border-emerald-800">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
          {/* Left contact info */}
          <div className="flex flex-wrap items-center gap-4 sm:gap-6 text-[11px] sm:text-xs">
            <span className="flex items-center gap-1.5 text-emerald-200">
              <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse"></span>
              <strong className="text-white">EIIN:</strong> {lang === 'bn' ? schoolInfo.eiin : schoolInfo.eiinEn}
              <span className="mx-1 text-emerald-400/60 hidden sm:inline">|</span>
              <span className="hidden sm:inline"><strong className="text-white">কোড:</strong> {lang === 'bn' ? schoolInfo.schoolCode : schoolInfo.schoolCodeEn}</span>
            </span>

            <a href={`tel:${schoolInfo.phone}`} className="flex items-center gap-1 hover:text-white transition-colors hidden md:flex">
              <Phone size={12} className="text-amber-400" />
              <span>{schoolInfo.phone}</span>
            </a>

            <a href={`mailto:${schoolInfo.email}`} className="flex items-center gap-1 hover:text-white transition-colors hidden lg:flex">
              <Mail size={12} className="text-amber-400" />
              <span>{schoolInfo.email}</span>
            </a>
          </div>

          {/* Right Links & Language Toggle */}
          <div className="flex items-center gap-3 sm:gap-4 ml-auto">
            {/* Facebook Page direct link */}
            <a
              href={schoolInfo.facebookPage}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1 text-emerald-200 hover:text-amber-300 text-[11px] font-medium transition-colors"
              title="Official Facebook Page"
            >
              <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24">
                <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
              </svg>
              <span className="hidden sm:inline">ফেসবুক পেজ</span>
            </a>

            {/* Google Maps Pin */}
            <button
              onClick={() => handleNavClick('location-contact')}
              className="flex items-center gap-1 text-emerald-200 hover:text-amber-300 text-[11px] font-medium transition-colors"
            >
              <MapPin size={12} className="text-rose-400" />
              <span>লালার দীঘি, বোয়ালখালী</span>
            </button>

            {/* Customizer Button in Top Bar */}
            <button
              onClick={onOpenCustomizer}
              className="flex items-center gap-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 px-2.5 py-0.5 rounded font-black text-xs transition shadow-sm animate-pulse"
              title="সম্পূর্ণ ওয়েবসাইট কাস্টমাইজ করুন"
            >
              <Settings size={12} />
              <span>{lang === 'bn' ? 'কাস্টমাইজার' : 'Customize'}</span>
            </button>

            {/* Language Switch */}
            <button
              onClick={onToggleLang}
              className="flex items-center gap-1 bg-emerald-800 hover:bg-emerald-700 text-amber-300 px-2.5 py-0.5 rounded border border-emerald-600 font-bold text-xs transition"
            >
              <Globe size={11} />
              <span>{lang === 'bn' ? 'English' : 'বাংলা'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Branding Header Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-8 py-3 flex items-center justify-between gap-4">
        {/* School Logo + Titles */}
        <div 
          onClick={() => handleNavClick('hero')}
          className="flex items-center gap-3 sm:gap-4 cursor-pointer group"
        >
          <SchoolLogo size={56} className="sm:w-16 sm:h-16" />
          <div className="flex flex-col">
            <h1 className="font-bengali-serif text-lg sm:text-2xl md:text-2xl font-black text-emerald-950 tracking-tight leading-tight group-hover:text-emerald-800 transition-colors">
              {lang === 'bn' ? schoolInfo.nameBn : schoolInfo.nameEn}
            </h1>
            <p className="text-xs sm:text-sm font-semibold text-emerald-800 flex items-center gap-1.5 flex-wrap">
              <span>{lang === 'bn' ? 'বোয়ালখালী, চট্টগ্রাম' : 'Boalkhali, Chattogram'}</span>
              <span className="text-amber-600">•</span>
              <span className="text-amber-700 font-bold">{lang === 'bn' ? 'স্থাপিত: ১৯৪৭ খ্রি.' : 'Estd: 1947'}</span>
              <span className="text-slate-400 hidden md:inline">•</span>
              <span className="text-slate-600 text-xs hidden md:inline">EIIN: {schoolInfo.eiinEn}</span>
            </p>
          </div>
        </div>

        {/* Quick Action Buttons on Desktop */}
        <div className="hidden lg:flex items-center gap-2.5">
          <button
            onClick={onOpenCustomizer}
            className="flex items-center gap-1.5 bg-amber-50 hover:bg-amber-100 text-amber-950 border border-amber-300 px-3 py-2 rounded-lg text-xs font-bold transition shadow-xs"
            title="তথ্য ও ছবি কাস্টমাইজ করুন"
          >
            <Settings size={15} className="text-amber-700" />
            <span>{lang === 'bn' ? 'কাস্টমাইজ প্যানেল' : 'Customize Site'}</span>
          </button>

          <button
            onClick={onOpenResultModal}
            className="flex items-center gap-1.5 bg-slate-100 hover:bg-emerald-50 text-emerald-900 border border-emerald-200 px-3 py-2 rounded-lg text-xs font-bold transition shadow-sm hover:border-emerald-400"
          >
            <Search size={14} className="text-emerald-600" />
            <span>{lang === 'bn' ? 'ফলাফল' : 'Results'}</span>
          </button>

          <button
            onClick={onOpenAdmissionModal}
            className="flex items-center gap-2 bg-gradient-to-r from-emerald-700 to-emerald-800 hover:from-emerald-800 hover:to-emerald-900 text-white px-3.5 py-2 rounded-lg text-xs font-bold transition shadow-md hover:shadow-emerald-900/20"
          >
            <GraduationCap size={15} className="text-amber-300" />
            <span>{lang === 'bn' ? 'ভর্তি ২০২৬' : 'Admission 2026'}</span>
            <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping"></span>
          </button>
        </div>

        {/* Mobile menu toggle */}
        <div className="flex items-center gap-2 lg:hidden">
          <button
            onClick={onOpenAdmissionModal}
            className="bg-emerald-700 text-white text-[11px] font-bold px-2.5 py-1.5 rounded-md"
          >
            {lang === 'bn' ? 'ভর্তি' : 'Apply'}
          </button>

          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 text-slate-700 hover:text-emerald-800 hover:bg-slate-100 rounded-lg focus:outline-none"
            aria-label="Toggle menu"
          >
            {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Primary Sticky Nav Bar */}
      <nav className="bg-emerald-800 border-t border-emerald-700 text-white hidden lg:block">
        <div className="max-w-7xl mx-auto px-4 sm:px-8">
          <ul className="flex items-center justify-between text-[13px] font-semibold tracking-wide">
            {navItems.map((item) => {
              const isActive = currentSection === item.id;
              return (
                <li key={item.id}>
                  <button
                    onClick={() => handleNavClick(item.id)}
                    className={`py-2.5 px-3 border-b-2 flex items-center gap-1.5 transition-all duration-200 ${
                      isActive
                        ? 'border-amber-400 text-amber-300 bg-emerald-900/60 font-bold'
                        : 'border-transparent text-emerald-50 hover:text-amber-200 hover:bg-emerald-700/60'
                    }`}
                  >
                    <span>{lang === 'bn' ? item.labelBn : item.labelEn}</span>
                  </button>
                </li>
              );
            })}
          </ul>
        </div>
      </nav>

      {/* Mobile Menu Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-emerald-950 text-white border-t border-emerald-800 px-4 py-4 space-y-2 animate-fadeIn shadow-2xl">
          <button
            onClick={() => { onOpenCustomizer(); setMobileMenuOpen(false); }}
            className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 py-2.5 rounded-xl text-xs font-black shadow-md"
          >
            <Settings size={15} />
            <span>{lang === 'bn' ? 'অ্যাডমিন কাস্টমাইজেশন প্যানেল' : 'Admin Customizer'}</span>
          </button>

          <div className="grid grid-cols-2 gap-2 pb-3 border-b border-emerald-800/80 pt-1">
            <button
              onClick={() => { onOpenResultModal(); setMobileMenuOpen(false); }}
              className="flex items-center justify-center gap-1.5 bg-emerald-800 text-amber-300 py-2 rounded text-xs font-bold"
            >
              <Award size={14} />
              <span>{lang === 'bn' ? 'ফলাফল চেক' : 'Results'}</span>
            </button>
            <button
              onClick={() => { onOpenAdmissionModal(); setMobileMenuOpen(false); }}
              className="flex items-center justify-center gap-1.5 bg-amber-500 text-emerald-950 py-2 rounded text-xs font-bold"
            >
              <GraduationCap size={14} />
              <span>{lang === 'bn' ? 'ভর্তি ফরম' : 'Apply Now'}</span>
            </button>
          </div>

          <div className="space-y-1 pt-1">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className={`w-full text-left px-3 py-2.5 rounded-lg text-sm flex items-center gap-2.5 transition ${
                  currentSection === item.id 
                    ? 'bg-emerald-800 text-amber-300 font-bold' 
                    : 'text-emerald-100 hover:bg-emerald-900'
                }`}
              >
                {item.icon && <item.icon size={16} className="text-amber-400" />}
                <span>{lang === 'bn' ? item.labelBn : item.labelEn}</span>
              </button>
            ))}
          </div>

          <div className="pt-3 border-t border-emerald-800/80 text-xs text-emerald-300 space-y-1">
            <p>📞 {schoolInfo.phone}</p>
            <p>✉️ {schoolInfo.email}</p>
            <a 
              href={schoolInfo.facebookPage} 
              target="_blank" 
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1 text-amber-400 hover:underline pt-1"
            >
              ফেসবুক অফিসিয়াল পেজ <ExternalLink size={12} />
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
