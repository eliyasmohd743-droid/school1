import React, { useState } from 'react';
import { useSchool } from '../context/SchoolContext';
import { Notice } from '../types';
import { SchoolLogo } from './SchoolLogo';
import { 
  FileText, 
  Calendar, 
  Download, 
  Search, 
  ChevronRight, 
  Bell, 
  X, 
  Printer, 
  CheckCircle,
  Tag
} from 'lucide-react';

interface NoticeBoardProps {
  lang: 'bn' | 'en';
  activeNotice: Notice | null;
  onSelectNotice: (notice: Notice | null) => void;
}

export const NoticeBoard: React.FC<NoticeBoardProps> = ({
  lang,
  activeNotice,
  onSelectNotice
}) => {
  const { notices, schoolInfo } = useSchool();
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const categories = [
    { id: 'all', labelBn: 'সকল বিজ্ঞপ্তি', labelEn: 'All Notices' },
    { id: 'exam', labelBn: 'পরীক্ষা সংক্রান্ত', labelEn: 'Examinations' },
    { id: 'admission', labelBn: 'ভর্তি কার্যক্রম', labelEn: 'Admissions' },
    { id: 'academic', labelBn: 'শিক্ষা ও একাডেমিক', labelEn: 'Academic' },
    { id: 'holiday', labelBn: 'ছুটির নোটিশ', labelEn: 'Holidays' },
    { id: 'event', labelBn: 'ক্রীড়া ও সাংস্কৃতিক', labelEn: 'Events & Sports' },
  ];

  const filteredNotices = notices.filter((n) => {
    const matchesCategory = selectedCategory === 'all' || n.category === selectedCategory;
    const query = searchQuery.toLowerCase().trim();
    const matchesQuery = 
      !query || 
      n.titleBn.toLowerCase().includes(query) || 
      n.titleEn.toLowerCase().includes(query) ||
      n.contentBn.toLowerCase().includes(query);
    return matchesCategory && matchesQuery;
  });

  return (
    <section id="notices" className="py-14 sm:py-20 bg-white border-b border-slate-200">
      <div className="max-w-6xl mx-auto px-4 sm:px-8">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-10">
          <span className="text-xs font-bold uppercase tracking-wider text-emerald-800 bg-emerald-100 px-3 py-1 rounded-full border border-emerald-300">
            {lang === 'bn' ? 'অফিসিয়াল নোটিশ বোর্ড' : 'Official Notice Board'}
          </span>
          <h2 className="font-bengali-serif text-2xl sm:text-4xl font-black text-slate-900 mt-2">
            {lang === 'bn' ? 'জরুরি বিজ্ঞপ্তি ও পরিপত্র' : 'Announcements & Circulars'}
          </h2>
          <p className="text-slate-600 text-xs sm:text-sm mt-2">
            {lang === 'bn'
              ? 'বিদ্যালয়ের সকল একাডেমিক কার্যক্রম, পরীক্ষার সময়সূচি, ভর্তি ও ছুটির সর্বশেষ বিজ্ঞপ্তি।'
              : 'Stay informed with the latest updates from Kadhurkhil United Muslim High School.'}
          </p>
          <div className="w-16 h-1 bg-amber-500 mx-auto mt-3 rounded-full"></div>
        </div>

        {/* Filters and Search Bar */}
        <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 mb-8 space-y-4">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
            {/* Category Filter Pills */}
            <div className="flex flex-wrap items-center gap-1.5 sm:gap-2">
              {categories.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategory(cat.id)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
                    selectedCategory === cat.id
                      ? 'bg-emerald-800 text-amber-300 shadow-xs'
                      : 'bg-white text-slate-700 hover:bg-slate-200 border border-slate-200'
                  }`}
                >
                  {lang === 'bn' ? cat.labelBn : cat.labelEn}
                </button>
              ))}
            </div>

            {/* Search Box */}
            <div className="relative w-full sm:w-64">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={15} />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={lang === 'bn' ? 'বিজ্ঞপ্তি খুঁজুন...' : 'Search notices...'}
                className="w-full pl-9 pr-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-emerald-600"
              />
            </div>
          </div>
        </div>

        {/* Notices List */}
        <div className="space-y-3.5">
          {filteredNotices.map((notice) => (
            <div
              key={notice.id}
              onClick={() => onSelectNotice(notice)}
              className="bg-white border border-slate-200 hover:border-emerald-500 rounded-2xl p-4 sm:p-5 shadow-xs hover:shadow-md transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4 cursor-pointer group"
            >
              <div className="flex items-start gap-4">
                {/* Date badge */}
                <div className="shrink-0 bg-emerald-50 text-emerald-900 border border-emerald-200 rounded-xl px-3 py-2 text-center w-20">
                  <Calendar size={14} className="mx-auto text-emerald-700 mb-0.5" />
                  <span className="text-[11px] font-bold block">{notice.date}</span>
                </div>

                <div className="space-y-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    {notice.isUrgent && (
                      <span className="bg-red-500 text-white text-[10px] font-black px-2 py-0.5 rounded uppercase tracking-wider animate-pulse">
                        {lang === 'bn' ? 'জরুরি' : 'Urgent'}
                      </span>
                    )}
                    <span className="text-[10px] font-bold bg-slate-100 text-slate-600 px-2 py-0.5 rounded border border-slate-200">
                      {notice.category}
                    </span>
                  </div>

                  <h3 className="font-bengali-serif text-base sm:text-lg font-bold text-slate-900 group-hover:text-emerald-800 transition-colors">
                    {lang === 'bn' ? notice.titleBn : notice.titleEn}
                  </h3>

                  <p className="text-xs text-slate-500 line-clamp-1">
                    {lang === 'bn' ? notice.summaryBn : notice.summaryEn}
                  </p>
                </div>
              </div>

              {/* View detail button */}
              <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
                <span className="text-xs font-bold text-emerald-700 group-hover:underline flex items-center gap-1">
                  <span>{lang === 'bn' ? 'বিস্তারিত পড়ুন' : 'Read Notice'}</span>
                  <ChevronRight size={14} />
                </span>
              </div>
            </div>
          ))}

          {filteredNotices.length === 0 && (
            <div className="text-center py-10 bg-slate-50 rounded-2xl border border-slate-200">
              <FileText className="w-10 h-10 text-slate-300 mx-auto mb-2" />
              <p className="text-xs sm:text-sm font-semibold text-slate-600">
                {lang === 'bn' ? 'কোনো নোটিশ পাওয়া যায়নি।' : 'No notices match your selection.'}
              </p>
            </div>
          )}
        </div>

        {/* Notice Full View Modal */}
        {activeNotice && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fadeIn">
            <div 
              className="bg-white rounded-3xl max-w-2xl w-full shadow-2xl border border-slate-200 overflow-hidden transform animate-scaleUp max-h-[90vh] flex flex-col"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Modal Header */}
              <div className="bg-emerald-900 text-white p-5 sm:p-6 flex items-center justify-between border-b border-emerald-800 shrink-0">
                <div className="flex items-center gap-3">
                  <SchoolLogo size={42} />
                  <div>
                    <h4 className="font-bengali-serif text-sm sm:text-base font-bold">
                      {schoolInfo.nameBn}
                    </h4>
                    <span className="text-[11px] text-amber-300">
                      স্মারক নং: KUMHS/{activeNotice.id.toUpperCase()}/{new Date().getFullYear()}
                    </span>
                  </div>
                </div>

                <button
                  onClick={() => onSelectNotice(null)}
                  className="p-1.5 rounded-full bg-emerald-950/60 hover:bg-emerald-950 text-white transition"
                  aria-label="Close"
                >
                  <X size={18} />
                </button>
              </div>

              {/* Notice Content */}
              <div className="p-6 sm:p-8 overflow-y-auto space-y-4 text-slate-800 text-xs sm:text-sm leading-relaxed">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100 text-xs text-slate-500">
                  <span className="font-semibold text-emerald-800">তারিখ: {activeNotice.date}</span>
                  <span className="bg-amber-100 text-amber-900 px-2 py-0.5 rounded font-bold">
                    ক্যাটাগরি: {activeNotice.category}
                  </span>
                </div>

                <h3 className="font-bengali-serif text-lg sm:text-xl font-black text-slate-950">
                  {lang === 'bn' ? activeNotice.titleBn : activeNotice.titleEn}
                </h3>

                <p className="text-slate-700 whitespace-pre-line leading-relaxed text-sm bg-slate-50 p-4 rounded-xl border border-slate-200">
                  {lang === 'bn' ? activeNotice.contentBn : activeNotice.contentEn}
                </p>

                <div className="pt-6 border-t border-slate-200 flex items-center justify-between">
                  <div>
                    <p className="text-[11px] text-slate-400">অনুলিপি প্রেরিত ও নোটিশ জারি:</p>
                    <p className="font-bold text-xs text-slate-700">{activeNotice.authorBn}</p>
                    <p className="text-[10px] text-emerald-800 font-semibold">{schoolInfo.nameBn}</p>
                  </div>
                  <div className="text-right">
                    <button
                      onClick={() => window.print()}
                      className="inline-flex items-center gap-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold px-3 py-1.5 rounded-lg border border-slate-300 transition"
                    >
                      <Printer size={14} />
                      <span>প্রিন্ট করুন</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
