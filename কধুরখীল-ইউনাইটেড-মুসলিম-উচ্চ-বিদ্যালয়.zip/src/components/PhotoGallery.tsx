import React, { useState } from 'react';
import { useSchool } from '../context/SchoolContext';
import { GalleryItem } from '../types';
import { Image as ImageIcon, X, Calendar, Eye } from 'lucide-react';

interface PhotoGalleryProps {
  lang: 'bn' | 'en';
}

export const PhotoGallery: React.FC<PhotoGalleryProps> = ({ lang }) => {
  const { gallery } = useSchool();
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [activePhoto, setActivePhoto] = useState<GalleryItem | null>(null);

  const categories = [
    { id: 'all', labelBn: 'সকল আলোকচিত্র', labelEn: 'All Photos' },
    { id: 'campus', labelBn: 'ক্যাম্পাস ও দীঘি', labelEn: 'Campus & Lake' },
    { id: 'academic', labelBn: 'শিক্ষা ও বিজ্ঞান মেলা', labelEn: 'Academic & Science' },
    { id: 'sports', labelBn: 'খেলাধুলা ও অ্যাথলেটিক্স', labelEn: 'Sports' },
    { id: 'national', labelBn: 'জাতীয় দিবস ও স্মৃতিসৌধ', labelEn: 'National Days' },
    { id: 'cultural', labelBn: 'সাংস্কৃতিক অনুষ্ঠান', labelEn: 'Cultural' }
  ];

  const filteredPhotos = gallery.filter(
    (photo) => selectedCategory === 'all' || photo.category === selectedCategory
  );

  return (
    <section id="gallery" className="py-14 sm:py-20 bg-slate-50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-8">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-10">
          <span className="text-xs font-bold uppercase tracking-wider text-emerald-800 bg-emerald-100 px-3 py-1 rounded-full border border-emerald-300">
            {lang === 'bn' ? 'ছবি ও স্মৃতিময় মুহূর্ত' : 'Visual Gallery'}
          </span>
          <h2 className="font-bengali-serif text-2xl sm:text-4xl font-black text-slate-900 mt-2">
            {lang === 'bn' ? 'বিদ্যালয়ের চিত্রশালা' : 'Moments & Memories'}
          </h2>
          <p className="text-slate-600 text-xs sm:text-sm mt-2">
            {lang === 'bn'
              ? 'কধুরখীল ইউনাইটেড মুসলিম উচ্চ বিদ্যালয়ের গৌরবোজ্জ্বল উৎসব, ক্রীড়া ও শিক্ষা জীবনের স্থিরচিত্র।'
              : 'Glimpses of vibrant school life, athletic milestones, and community celebrations.'}
          </p>
          <div className="w-16 h-1 bg-amber-500 mx-auto mt-3 rounded-full"></div>
        </div>

        {/* Filter Chips */}
        <div className="flex flex-wrap items-center justify-center gap-2 mb-8">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-4 py-2 rounded-xl text-xs font-semibold transition ${
                selectedCategory === cat.id
                  ? 'bg-emerald-800 text-amber-300 shadow-sm ring-1 ring-emerald-700'
                  : 'bg-white text-slate-700 hover:bg-slate-200 border border-slate-200'
              }`}
            >
              {lang === 'bn' ? cat.labelBn : cat.labelEn}
            </button>
          ))}
        </div>

        {/* Photos Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
          {filteredPhotos.map((photo) => (
            <div
              key={photo.id}
              onClick={() => setActivePhoto(photo)}
              className="group bg-white rounded-2xl overflow-hidden shadow-xs hover:shadow-xl border border-slate-200 cursor-pointer transition transform hover:-translate-y-1 flex flex-col"
            >
              <div className="relative aspect-4/3 overflow-hidden bg-slate-200">
                <img
                  src={photo.imageUrl}
                  alt={photo.titleBn}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  loading="lazy"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1562774053-701939374585?auto=format&fit=crop&w=800&q=80';
                  }}
                />
                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                  <span className="p-3 bg-white/90 rounded-full text-slate-900 shadow-lg transform scale-75 group-hover:scale-100 transition-transform">
                    <Eye size={20} />
                  </span>
                </div>
                <div className="absolute top-3 right-3">
                  <span className="bg-black/60 backdrop-blur-xs text-white text-[10px] font-bold px-2 py-0.5 rounded">
                    {photo.date}
                  </span>
                </div>
              </div>

              <div className="p-4 flex-1 flex flex-col justify-between">
                <h3 className="font-bengali-serif text-sm font-bold text-slate-900 group-hover:text-emerald-800 transition-colors">
                  {lang === 'bn' ? photo.titleBn : photo.titleEn}
                </h3>
                <p className="text-[11px] text-slate-500 mt-1 line-clamp-1">
                  {photo.captionBn}
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* Lightbox Modal */}
        {activePhoto && (
          <div
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn"
            onClick={() => setActivePhoto(null)}
          >
            <div 
              className="bg-white rounded-3xl max-w-3xl w-full shadow-2xl overflow-hidden border border-slate-700 animate-scaleUp"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="relative bg-black flex items-center justify-center max-h-[65vh] overflow-hidden">
                <img
                  src={activePhoto.imageUrl}
                  alt={activePhoto.titleBn}
                  className="max-h-[65vh] w-auto object-contain"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1562774053-701939374585?auto=format&fit=crop&w=1000&q=80';
                  }}
                />
                <button
                  onClick={() => setActivePhoto(null)}
                  className="absolute top-4 right-4 p-2 rounded-full bg-black/60 hover:bg-black/80 text-white transition"
                  aria-label="Close"
                >
                  <X size={20} />
                </button>
              </div>

              <div className="p-6 bg-white space-y-2">
                <div className="flex items-center justify-between text-xs text-slate-500">
                  <span className="bg-emerald-100 text-emerald-900 px-2 py-0.5 rounded font-bold">
                    {activePhoto.category}
                  </span>
                  <span>তারিখ: {activePhoto.date}</span>
                </div>
                <h3 className="font-bengali-serif text-lg font-bold text-slate-900">
                  {lang === 'bn' ? activePhoto.titleBn : activePhoto.titleEn}
                </h3>
                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                  {activePhoto.captionBn}
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
