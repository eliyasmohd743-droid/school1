import React, { useState } from 'react';
import { useSchool } from '../context/SchoolContext';
import { Calendar, Clock, BookOpen, User, Printer } from 'lucide-react';

interface ClassRoutineProps {
  lang: 'bn' | 'en';
}

export const ClassRoutine: React.FC<ClassRoutineProps> = ({ lang }) => {
  const { routines, schoolInfo } = useSchool();
  const [activeDayIdx, setActiveDayIdx] = useState<number>(0);
  const currentDay = routines[activeDayIdx] || routines[0];

  return (
    <section id="routine" className="py-14 sm:py-20 bg-slate-100 border-b border-slate-200">
      <div className="max-w-6xl mx-auto px-4 sm:px-8">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-10">
          <span className="text-xs font-bold uppercase tracking-wider text-emerald-800 bg-emerald-100 px-3 py-1 rounded-full border border-emerald-300">
            {lang === 'bn' ? 'সাপ্তাহিক ক্লাস রুটিন' : 'Weekly Class Schedule'}
          </span>
          <h2 className="font-bengali-serif text-2xl sm:text-4xl font-black text-slate-900 mt-2">
            {lang === 'bn' ? 'দৈনিক পাঠদান সময়সূচি' : 'Daily Academic Timetable'}
          </h2>
          <p className="text-slate-600 text-xs sm:text-sm mt-2">
            {lang === 'bn'
              ? 'মাধ্যমিক শাখার সকল শ্রেণির সুবিন্যস্ত ৭-পিরিয়ডের একাডেমিক ক্লাস ও ব্যবহারিক ল্যাব রুটিন।'
              : 'Structured 7-period schedule balancing theoretical courses, computer ICT and science labs.'}
          </p>
          <div className="w-16 h-1 bg-amber-500 mx-auto mt-3 rounded-full"></div>
        </div>

        {/* Day selection tabs */}
        <div className="flex flex-wrap items-center justify-center gap-2 mb-8">
          {routines.map((day, idx) => (
            <button
              key={idx}
              onClick={() => setActiveDayIdx(idx)}
              className={`px-5 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition flex items-center gap-2 ${
                activeDayIdx === idx
                  ? 'bg-emerald-800 text-amber-300 shadow-md ring-2 ring-emerald-600'
                  : 'bg-white text-slate-700 hover:bg-slate-200 border border-slate-300'
              }`}
            >
              <Calendar size={15} />
              <span>{lang === 'bn' ? day.dayBn : day.dayEn}</span>
            </button>
          ))}
        </div>

        {/* Periods Table */}
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="bg-emerald-950 text-white p-4 sm:p-5 flex flex-wrap items-center justify-between gap-3">
            <div>
              <h3 className="font-bengali-serif text-lg font-bold text-amber-300">
                {lang === 'bn' ? `${currentDay.dayBn}বারের ক্লাস সময়সূচি` : `${currentDay.dayEn} Schedule`}
              </h3>
              <p className="text-xs text-emerald-200">
                সময়: সকাল ১০:০০ টা হতে বিকাল ০৩:৪৫ টা পর্যন্ত (মাঝখানে টিফিন বিরতি)
              </p>
            </div>
            <button
              onClick={() => window.print()}
              className="flex items-center gap-1.5 bg-emerald-800 hover:bg-emerald-700 text-white text-xs font-bold px-3 py-1.5 rounded-lg border border-emerald-600 transition"
            >
              <Printer size={14} />
              <span>{lang === 'bn' ? 'রুটিন প্রিন্ট' : 'Print Routine'}</span>
            </button>
          </div>

          <div className="divide-y divide-slate-100">
            {currentDay.periods.map((period, idx) => (
              <div
                key={idx}
                className="p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-slate-50 transition"
              >
                <div className="flex items-center gap-4">
                  {/* Period Badge */}
                  <div className="w-12 h-12 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-900 flex flex-col items-center justify-center shrink-0">
                    <span className="text-[10px] font-bold text-slate-400">পিরিয়ড</span>
                    <span className="text-base font-black font-mono leading-none">{period.period}</span>
                  </div>

                  <div>
                    <h4 className="font-bengali-serif text-base font-bold text-slate-900 flex items-center gap-2">
                      <BookOpen size={16} className="text-emerald-700" />
                      <span>{lang === 'bn' ? period.subjectBn : period.subjectEn}</span>
                    </h4>
                    <div className="flex items-center gap-3 text-xs text-slate-500 mt-1 flex-wrap">
                      <span className="flex items-center gap-1 font-medium text-emerald-800">
                        <User size={13} />
                        <span>{lang === 'bn' ? period.teacherBn : period.teacherEn}</span>
                      </span>
                      <span className="text-slate-300">•</span>
                      <span className="bg-slate-100 px-2 py-0.5 rounded font-mono text-[11px] font-semibold text-slate-700">
                        {period.room}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-1.5 text-xs font-bold text-slate-700 bg-amber-50 border border-amber-200 px-3 py-1.5 rounded-lg self-start sm:self-center">
                  <Clock size={14} className="text-amber-700" />
                  <span>{period.time}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
