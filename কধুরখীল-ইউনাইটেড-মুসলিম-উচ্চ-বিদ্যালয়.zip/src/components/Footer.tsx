import React from 'react';
import { useSchool } from '../context/SchoolContext';
import { SchoolLogo } from './SchoolLogo';
import { 
  Phone, 
  Mail, 
  MapPin, 
  ExternalLink, 
  ShieldCheck, 
  Heart,
  Globe,
  ArrowUp
} from 'lucide-react';

interface FooterProps {
  lang: 'bn' | 'en';
  onNavigate: (sectionId: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ lang, onNavigate }) => {
  const { schoolInfo } = useSchool();
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const govLinks = [
    { title: 'মাধ্যমিক ও উচ্চ শিক্ষা অধিদপ্তর (মাউশি)', url: 'https://dshe.gov.bd' },
    { title: 'চট্টগ্রাম শিক্ষা বোর্ড', url: 'https://bise-ctg.portal.gov.bd' },
    { title: 'শিক্ষা মন্ত্রণালয়', url: 'https://moedu.gov.bd' },
    { title: 'জাতীয় শিক্ষাক্রম ও পাঠ্যপুস্তক বোর্ড (এনসিটিবি)', url: 'http://www.nctb.gov.bd' },
    { title: 'বাংলাদেশ শিক্ষক বাতায়ন', url: 'https://teachers.gov.bd' },
    { title: 'ব্যানবেইস (BANBEIS)', url: 'https://banbeis.gov.bd' },
  ];

  return (
    <footer className="bg-emerald-950 text-slate-300 border-t-4 border-amber-500 pt-14 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-8">
        {/* Main Footer Columns */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-8 pb-12 border-b border-emerald-900/80">
          {/* Column 1: School Identity */}
          <div className="lg:col-span-5 space-y-4">
            <div className="flex items-center gap-3">
              <SchoolLogo size={60} />
              <div>
                <h3 className="font-bengali-serif text-lg sm:text-xl font-bold text-white leading-tight">
                  {lang === 'bn' ? schoolInfo.nameBn : schoolInfo.nameEn}
                </h3>
                <p className="text-xs text-amber-300 font-medium">
                  {lang === 'bn' ? 'স্থাপিত: ১৯৪৭ খ্রিষ্টাব্দ • বোয়ালখালী, চট্টগ্রাম' : 'Estd: 1947 • Boalkhali, Chattogram'}
                </p>
              </div>
            </div>

            <p className="text-xs sm:text-sm text-emerald-100/80 leading-relaxed max-w-md">
              {lang === 'bn'
                ? 'বোয়ালখালী উপজেলার ১নং কধুরখীল ইউনিয়নে ঐতিহাসিক লালার দীঘির পাড়ে অবস্থিত এক গৌরবোজ্জ্বল ও প্রাচীন মাধ্যমিক শিক্ষাপ্রতিষ্ঠান। মানবিক ও প্রযুক্তিনির্ভর আধুনিক সুশিক্ষায় আলোকিত প্রজন্ম গড়ে তোলাই আমাদের অঙ্গীকার।'
                : 'A historic secondary educational sanctuary situated by Lalar Dighi, Boalkhali, empowering students with holistic, moral, and technological education.'}
            </p>

            {/* Badges */}
            <div className="flex flex-wrap items-center gap-2 pt-1 text-xs">
              <span className="bg-emerald-900 text-amber-300 px-2.5 py-1 rounded-md border border-emerald-700 font-bold">
                EIIN: {schoolInfo.eiinEn}
              </span>
              <span className="bg-emerald-900 text-emerald-200 px-2.5 py-1 rounded-md border border-emerald-700 font-bold">
                কোড: {schoolInfo.schoolCodeEn}
              </span>
              <span className="bg-emerald-900 text-emerald-200 px-2.5 py-1 rounded-md border border-emerald-700 font-bold">
                কেন্দ্র কোড: {schoolInfo.centerCodeEn}
              </span>
            </div>

            {/* Social Links */}
            <div className="pt-2">
              <a
                href={schoolInfo.facebookPage}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold px-3 py-1.5 rounded-lg transition"
              >
                <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                  <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                </svg>
                <span>অফিসিয়াল ফেসবুক পেজে যুক্ত হন</span>
                <ExternalLink size={12} />
              </a>
            </div>
          </div>

          {/* Column 2: Quick Navigation */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="font-bengali-serif text-sm font-bold text-amber-300 uppercase tracking-wider">
              {lang === 'bn' ? 'দ্রুত লিঙ্কসমূহ' : 'Quick Navigation'}
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button onClick={() => onNavigate('about')} className="hover:text-amber-300 transition">
                  • {lang === 'bn' ? 'আমাদের ইতিহাস ও বাণী' : 'About & Messages'}
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('teachers')} className="hover:text-amber-300 transition">
                  • {lang === 'bn' ? 'শিক্ষক ও কর্মচারীবৃন্দ' : 'Teachers & Staff'}
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('notices')} className="hover:text-amber-300 transition">
                  • {lang === 'bn' ? 'নোটিশ বোর্ড ও সার্কুলার' : 'Notices & Circulars'}
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('results')} className="hover:text-amber-300 transition">
                  • {lang === 'bn' ? 'পরীক্ষার ফলাফল অনুসন্ধান' : 'Check Results'}
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('routine')} className="hover:text-amber-300 transition">
                  • {lang === 'bn' ? 'ক্লাস সময়সূচি ও রুটিন' : 'Class Routine'}
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('admission')} className="hover:text-amber-300 transition">
                  • {lang === 'bn' ? 'অনলাইন ভর্তি আবেদন' : 'Online Admission'}
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('location-contact')} className="hover:text-amber-300 transition">
                  • {lang === 'bn' ? 'গুগল ম্যাপে বিদ্যালয় ও যোগাযোগ' : 'Google Maps Location'}
                </button>
              </li>
            </ul>
          </div>

          {/* Column 3: Government & Education Portals */}
          <div className="lg:col-span-4 space-y-3">
            <h4 className="font-bengali-serif text-sm font-bold text-amber-300 uppercase tracking-wider">
              {lang === 'bn' ? 'সরকারি ও শিক্ষা বোর্ড পোর্টাল' : 'Government & Board Links'}
            </h4>
            <ul className="space-y-2 text-xs">
              {govLinks.map((link, idx) => (
                <li key={idx}>
                  <a
                    href={link.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-1.5 text-emerald-200/90 hover:text-amber-300 transition"
                  >
                    <ExternalLink size={12} className="shrink-0 text-amber-400" />
                    <span>{link.title}</span>
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom Copyright & Scroll to Top */}
        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-400">
          <div className="text-center sm:text-left">
            <p>
              © {new Date().getFullYear()} {schoolInfo.nameBn} (KUMHS)। সর্বস্বত্ব সংরক্ষিত।
            </p>
            <p className="text-[11px] text-slate-500 mt-0.5">
              EIIN: ১০৪১১১ • বোয়ালখালী, চট্টগ্রাম-৪৩৬১, বাংলাদেশ
            </p>
          </div>

          <button
            onClick={scrollToTop}
            className="flex items-center gap-1.5 bg-emerald-900 hover:bg-emerald-800 text-amber-300 px-3.5 py-1.5 rounded-xl border border-emerald-700 transition font-bold"
          >
            <span>উপরে ফিরুন</span>
            <ArrowUp size={14} />
          </button>
        </div>
      </div>
    </footer>
  );
};
