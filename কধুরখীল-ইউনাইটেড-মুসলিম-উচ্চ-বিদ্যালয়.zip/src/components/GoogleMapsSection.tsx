import React, { useState } from 'react';
import { useSchool } from '../context/SchoolContext';
import { 
  MapPin, 
  Phone, 
  Mail, 
  Clock, 
  Send, 
  Navigation, 
  ExternalLink, 
  CheckCircle, 
  Bus, 
  Car,
  Compass
} from 'lucide-react';

interface GoogleMapsSectionProps {
  lang: 'bn' | 'en';
}

export const GoogleMapsSection: React.FC<GoogleMapsSectionProps> = ({ lang }) => {
  const { schoolInfo } = useSchool();
  const [contactForm, setContactForm] = useState({
    name: '',
    phone: '',
    subject: '',
    message: ''
  });
  const [isSent, setIsSent] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!contactForm.name || !contactForm.phone || !contactForm.message) return;
    setIsSent(true);
    setTimeout(() => {
      setContactForm({ name: '', phone: '', subject: '', message: '' });
      setIsSent(false);
    }, 4000);
  };

  return (
    <section id="location-contact" className="py-14 sm:py-20 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <span className="text-xs font-bold uppercase tracking-wider text-emerald-800 bg-emerald-100 px-3 py-1 rounded-full border border-emerald-300">
            {lang === 'bn' ? 'গুগল ম্যাপ ও যোগাযোগ' : 'Location, Google Maps & Contact'}
          </span>
          <h2 className="font-bengali-serif text-2xl sm:text-4xl font-black text-slate-900 mt-2">
            {lang === 'bn' ? 'আমাদের অবস্থান ও যোগাযোগের ঠিকানা' : 'Find Us on Google Maps & Get in Touch'}
          </h2>
          <p className="text-slate-600 text-xs sm:text-sm mt-2">
            {lang === 'bn'
              ? 'চট্টগ্রাম শহর থেকে বোয়ালখালী উপজেলার লালার দীঘির পাড়ে অবস্থিত কধুরখীল ইউনাইটেড মুসলিম উচ্চ বিদ্যালয়ে সহজেই পৌঁছানো যায়।'
              : 'Conveniently accessible from Chattogram Metropolitan area via Kalurghat & Shah Amanat Bridges.'}
          </p>
          <div className="w-16 h-1 bg-amber-500 mx-auto mt-3 rounded-full"></div>
        </div>

        {/* Google Maps & Directions Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 mb-14">
          {/* Map Embed Card */}
          <div className="lg:col-span-7 bg-slate-100 rounded-3xl overflow-hidden shadow-md border border-slate-200 flex flex-col">
            <div className="p-4 bg-emerald-950 text-white flex items-center justify-between flex-wrap gap-2">
              <div className="flex items-center gap-2">
                <MapPin size={18} className="text-rose-400" />
                <span className="font-bold text-xs sm:text-sm">
                  {lang === 'bn' ? 'গুগল ম্যাপস অবস্থান (কধুরখীল, বোয়ালখালী)' : 'Google Maps Location'}
                </span>
              </div>
              <div className="flex items-center gap-2">
                {/* External Maps Link */}
                <a
                  href="https://maps.google.com/?q=Kadhurkhil+United+Muslim+High+School+Boalkhali+Chittagong"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1 bg-emerald-800 hover:bg-emerald-700 text-amber-300 text-xs font-bold px-3 py-1 rounded-lg border border-emerald-600 transition"
                >
                  <Navigation size={12} />
                  <span>{lang === 'bn' ? 'ম্যাপে ডিরেকশন' : 'Get Directions'}</span>
                  <ExternalLink size={12} />
                </a>

                {/* Facebook Check-in */}
                <a
                  href={schoolInfo.facebookPage}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1 bg-blue-700 hover:bg-blue-600 text-white text-xs font-bold px-2.5 py-1 rounded-lg transition"
                >
                  <svg className="w-3 h-3 fill-current" viewBox="0 0 24 24">
                    <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                  </svg>
                  <span>ফেসবুক পেজ</span>
                </a>
              </div>
            </div>

            {/* Live Interactive Map Box */}
            <div className="relative w-full h-[360px] sm:h-[420px] bg-slate-200">
              <iframe
                title="Google Maps Location for Kadhurkhil United Muslim High School"
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3689.873523456789!2d91.9168453!3d22.3789123!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x30ad2885994f7d43%3A0x6b19a3b68f3a3881!2sKadhurkhil%20United%20Muslim%20High%20School!5e0!3m2!1sen!2sbd!4v1700000000000!5m2!1sen!2sbd"
                width="100%"
                height="100%"
                style={{ border: 0 }}
                allowFullScreen={true}
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                className="w-full h-full"
              ></iframe>

              {/* Floating Overlay Info card */}
              <div className="absolute bottom-3 left-3 bg-white/95 backdrop-blur-md p-3 rounded-xl border border-slate-300 shadow-lg text-xs space-y-1 max-w-xs hidden sm:block">
                <p className="font-bold text-slate-900 font-bengali-serif">কধুরখীল ইউনাইটেড মুসলিম উচ্চ বিদ্যালয়</p>
                <p className="text-slate-600 text-[11px]">লালার দীঘির পাড়, ইউনিয়ন পরিষদ সংলগ্ন, বোয়ালখালী</p>
                <p className="text-[10px] text-emerald-800 font-bold">জিআইএস কোঅর্ডিনেট: ২২.৩৭৮৯° উ., ৯১.৯১৬৮° পূ.</p>
              </div>
            </div>
          </div>

          {/* Transportation & Route Directions */}
          <div className="lg:col-span-5 space-y-5">
            <div className="bg-slate-50 p-6 rounded-3xl border border-slate-200 shadow-xs space-y-4">
              <h3 className="font-bengali-serif text-lg font-bold text-emerald-950 flex items-center gap-2">
                <Compass className="text-emerald-700" size={20} />
                <span>{lang === 'bn' ? 'যাতায়াত ও পৌঁছানোর নির্দেশিকা' : 'How to Reach the Campus'}</span>
              </h3>

              <div className="space-y-3 text-xs sm:text-sm text-slate-700">
                <div className="flex items-start gap-3 p-3 bg-white rounded-xl border border-slate-200">
                  <div className="p-2 bg-emerald-100 text-emerald-900 rounded-lg shrink-0">
                    <Bus size={18} />
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-900">বহদ্দারহাট হতে (কালুরঘাট সেতু পথ):</h4>
                    <p className="text-xs text-slate-600 mt-0.5">
                      বহদ্দারহাট বাস টার্মিনাল থেকে বোয়ালখালীগামী বাস বা সিএনজি যোগে কালুরঘাট ব্রিজ পার হয়ে কানুনগোপাড়া রোড ধরে কধুরখীল লালার দীঘির মোড়ে নামতে হবে।
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3 bg-white rounded-xl border border-slate-200">
                  <div className="p-2 bg-amber-100 text-amber-900 rounded-lg shrink-0">
                    <Car size={18} />
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-900">কর্ণফুলী নতুন ব্রিজ (শাহ আমানত সেতু) পথ:</h4>
                    <p className="text-xs text-slate-600 mt-0.5">
                      শাহ আমানত সেতু পার হয়ে মইজ্জ্যার টেক হয়ে বোয়ালখালী গোমদণ্ডী সদর দিয়ে সরাসরি কধুরখীল লালার দীঘির পাড় পৌঁছানো যায়।
                    </p>
                  </div>
                </div>
              </div>

              <div className="pt-2 border-t border-slate-200 text-xs text-slate-600 space-y-2">
                <div className="flex items-center gap-2 text-emerald-900 font-semibold">
                  <Clock size={15} />
                  <span>অফিস সময়: শনিবার হতে বৃহস্পতিবার (সকাল ৯:০০ - বিকাল ৪:৩০)</span>
                </div>
                <div className="flex items-center gap-2 text-slate-700">
                  <Phone size={15} className="text-emerald-700" />
                  <span>অফিস ফোন: {schoolInfo.officePhone} / {schoolInfo.phone}</span>
                </div>
                <div className="flex items-center gap-2 text-slate-700">
                  <Mail size={15} className="text-emerald-700" />
                  <span>ইমেইল: {schoolInfo.email}</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Contact Message Form */}
        <div className="bg-gradient-to-br from-emerald-900 via-emerald-950 to-slate-950 rounded-3xl p-6 sm:p-10 text-white shadow-xl border border-emerald-800">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            <div className="lg:col-span-5 space-y-3">
              <span className="text-amber-400 text-xs font-bold uppercase tracking-wider">অভিভাবক ও দর্শনার্থী বার্তা</span>
              <h3 className="font-bengali-serif text-2xl sm:text-3xl font-black">
                {lang === 'bn' ? 'বিদ্যালয় কর্তৃপক্ষের সাথে যোগাযোগ করুন' : 'Send an Inquiry to School Office'}
              </h3>
              <p className="text-xs sm:text-sm text-emerald-100 leading-relaxed">
                {lang === 'bn'
                  ? 'ভর্তি সংক্রান্ত তথ্য, ছাত্র-ছাত্রীদের খোঁজ-খবর কিংবা যেকোনো পরামর্শের জন্য বার্তা প্রেরণ করুন। প্রধান শিক্ষক ও অফিস কর্তৃপক্ষ দ্রুত উত্তর প্রদান করবেন।'
                  : 'For admissions queries, student records, or recommendations, please message our administrative desk.'}
              </p>
            </div>

            <div className="lg:col-span-7">
              {isSent ? (
                <div className="bg-emerald-800/80 p-6 rounded-2xl border border-emerald-600 text-center space-y-2 animate-fadeIn">
                  <CheckCircle size={32} className="text-amber-400 mx-auto" />
                  <h4 className="font-bold text-lg text-white">আপনার বার্তা সফলভাবে প্রেরিত হয়েছে!</h4>
                  <p className="text-xs text-emerald-100">বিদ্যালয় কর্তৃপক্ষ শীঘ্রই আপনার প্রদত্ত নম্বরে যোগাযোগ করবে। ধন্যবাদ।</p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-3 text-xs sm:text-sm">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <input
                      type="text"
                      placeholder="আপনার পূর্ণ নাম *"
                      value={contactForm.name}
                      onChange={(e) => setContactForm({ ...contactForm, name: e.target.value })}
                      required
                      className="bg-emerald-950/70 border border-emerald-700 rounded-xl px-3.5 py-2.5 text-white placeholder:text-emerald-300/60 focus:outline-none focus:border-amber-400"
                    />
                    <input
                      type="tel"
                      placeholder="মোবাইল নম্বর *"
                      value={contactForm.phone}
                      onChange={(e) => setContactForm({ ...contactForm, phone: e.target.value })}
                      required
                      className="bg-emerald-950/70 border border-emerald-700 rounded-xl px-3.5 py-2.5 text-white placeholder:text-emerald-300/60 focus:outline-none focus:border-amber-400"
                    />
                  </div>
                  <input
                    type="text"
                    placeholder="বার্তার বিষয় (যেমন: ভর্তি তথ্য, প্রশংসাপত্র)"
                    value={contactForm.subject}
                    onChange={(e) => setContactForm({ ...contactForm, subject: e.target.value })}
                    className="w-full bg-emerald-950/70 border border-emerald-700 rounded-xl px-3.5 py-2.5 text-white placeholder:text-emerald-300/60 focus:outline-none focus:border-amber-400"
                  />
                  <textarea
                    rows={3}
                    placeholder="আপনার বার্তা বিস্তারিত লিখুন... *"
                    value={contactForm.message}
                    onChange={(e) => setContactForm({ ...contactForm, message: e.target.value })}
                    required
                    className="w-full bg-emerald-950/70 border border-emerald-700 rounded-xl px-3.5 py-2.5 text-white placeholder:text-emerald-300/60 focus:outline-none focus:border-amber-400"
                  ></textarea>

                  <button
                    type="submit"
                    className="w-full bg-amber-500 hover:bg-amber-400 text-emerald-950 font-black py-3 rounded-xl transition flex items-center justify-center gap-2 shadow-lg"
                  >
                    <Send size={16} />
                    <span>{lang === 'bn' ? 'বার্তা প্রেরণ করুন' : 'Send Message'}</span>
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
