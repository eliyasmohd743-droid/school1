import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  schoolInfo as defaultSchoolInfo, 
  teachersList as defaultTeachersList, 
  committeeMembers as defaultCommittee, 
  noticesList as defaultNotices, 
  sampleResults as defaultResults, 
  classRoutines as defaultRoutines, 
  facilitiesList as defaultFacilities, 
  galleryPhotos as defaultGallery 
} from '../data/schoolData';
import { 
  Teacher, 
  CommitteeMember, 
  Notice, 
  StudentResult, 
  ClassRoutineDay, 
  Facility, 
  GalleryItem 
} from '../types';

interface SchoolInfoType {
  nameBn: string;
  nameEn: string;
  shortName: string;
  mottoBn: string;
  mottoEn: string;
  eiin: string;
  eiinEn: string;
  schoolCode: string;
  schoolCodeEn: string;
  centerCode: string;
  centerCodeEn: string;
  boardBn: string;
  boardEn: string;
  estdBn: string;
  estdEn: string;
  typeBn: string;
  typeEn: string;
  classesBn: string;
  classesEn: string;
  streamsBn: string;
  streamsEn: string;
  addressBn: string;
  addressEn: string;
  phone: string;
  officePhone: string;
  email: string;
  website: string;
  facebookPage: string;
  mapEmbedUrl: string;
  stats: { labelBn: string; labelEn: string; valueBn: string; valueEn: string }[];
}

interface SchoolContextType {
  schoolInfo: SchoolInfoType;
  updateSchoolInfo: (info: Partial<SchoolInfoType>) => void;
  
  teachers: Teacher[];
  addTeacher: (teacher: Teacher) => void;
  updateTeacher: (teacher: Teacher) => void;
  deleteTeacher: (id: string) => void;

  committee: CommitteeMember[];
  updateCommittee: (members: CommitteeMember[]) => void;

  notices: Notice[];
  addNotice: (notice: Notice) => void;
  updateNotice: (notice: Notice) => void;
  deleteNotice: (id: string) => void;

  results: StudentResult[];
  addOrUpdateResult: (result: StudentResult) => void;
  deleteResult: (rollNo: string) => void;

  routines: ClassRoutineDay[];
  updateRoutine: (dayIdx: number, updatedDay: ClassRoutineDay) => void;

  facilities: Facility[];
  updateFacility: (facility: Facility) => void;

  gallery: GalleryItem[];
  addGalleryItem: (item: GalleryItem) => void;
  deleteGalleryItem: (id: string) => void;

  resetAllData: () => void;
  exportBackupJson: () => string;
  importBackupJson: (jsonString: string) => boolean;

  themeColor: 'emerald' | 'navy' | 'maroon' | 'forest';
  setThemeColor: (color: 'emerald' | 'navy' | 'maroon' | 'forest') => void;
}

const LOCAL_STORAGE_KEY = 'kumhs_master_website_data_v1';

const SchoolContext = createContext<SchoolContextType | undefined>(undefined);

export const SchoolProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [schoolInfo, setSchoolInfo] = useState<SchoolInfoType>(defaultSchoolInfo);
  const [teachers, setTeachers] = useState<Teacher[]>(defaultTeachersList);
  const [committee, setCommittee] = useState<CommitteeMember[]>(defaultCommittee);
  const [notices, setNotices] = useState<Notice[]>(defaultNotices);
  const [results, setResults] = useState<StudentResult[]>(defaultResults);
  const [routines, setRoutines] = useState<ClassRoutineDay[]>(defaultRoutines);
  const [facilities, setFacilities] = useState<Facility[]>(defaultFacilities);
  const [gallery, setGallery] = useState<GalleryItem[]>(defaultGallery);
  const [themeColor, setThemeColor] = useState<'emerald' | 'navy' | 'maroon' | 'forest'>('emerald');

  // Load from localStorage on startup
  useEffect(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.schoolInfo) setSchoolInfo(parsed.schoolInfo);
        if (parsed.teachers) setTeachers(parsed.teachers);
        if (parsed.committee) setCommittee(parsed.committee);
        if (parsed.notices) setNotices(parsed.notices);
        if (parsed.results) setResults(parsed.results);
        if (parsed.routines) setRoutines(parsed.routines);
        if (parsed.facilities) setFacilities(parsed.facilities);
        if (parsed.gallery) setGallery(parsed.gallery);
        if (parsed.themeColor) setThemeColor(parsed.themeColor);
      }
    } catch (err) {
      console.error('Failed to load local storage state:', err);
    }
  }, []);

  // Save to localStorage helper
  const persist = (dataToSave: any) => {
    try {
      localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(dataToSave));
    } catch (e) {
      console.error('Failed to save to localStorage:', e);
    }
  };

  const currentPayload = () => ({
    schoolInfo,
    teachers,
    committee,
    notices,
    results,
    routines,
    facilities,
    gallery,
    themeColor,
  });

  const updateSchoolInfo = (info: Partial<SchoolInfoType>) => {
    setSchoolInfo((prev) => {
      const updated = { ...prev, ...info };
      persist({ ...currentPayload(), schoolInfo: updated });
      return updated;
    });
  };

  const addTeacher = (teacher: Teacher) => {
    setTeachers((prev) => {
      const updated = [teacher, ...prev];
      persist({ ...currentPayload(), teachers: updated });
      return updated;
    });
  };

  const updateTeacher = (teacher: Teacher) => {
    setTeachers((prev) => {
      const updated = prev.map((t) => (t.id === teacher.id ? teacher : t));
      persist({ ...currentPayload(), teachers: updated });
      return updated;
    });
  };

  const deleteTeacher = (id: string) => {
    setTeachers((prev) => {
      const updated = prev.filter((t) => t.id !== id);
      persist({ ...currentPayload(), teachers: updated });
      return updated;
    });
  };

  const updateCommittee = (members: CommitteeMember[]) => {
    setCommittee(members);
    persist({ ...currentPayload(), committee: members });
  };

  const addNotice = (notice: Notice) => {
    setNotices((prev) => {
      const updated = [notice, ...prev];
      persist({ ...currentPayload(), notices: updated });
      return updated;
    });
  };

  const updateNotice = (notice: Notice) => {
    setNotices((prev) => {
      const updated = prev.map((n) => (n.id === notice.id ? notice : n));
      persist({ ...currentPayload(), notices: updated });
      return updated;
    });
  };

  const deleteNotice = (id: string) => {
    setNotices((prev) => {
      const updated = prev.filter((n) => n.id !== id);
      persist({ ...currentPayload(), notices: updated });
      return updated;
    });
  };

  const addOrUpdateResult = (result: StudentResult) => {
    setResults((prev) => {
      const existingIdx = prev.findIndex((r) => r.rollNo === result.rollNo);
      let updated: StudentResult[];
      if (existingIdx >= 0) {
        updated = [...prev];
        updated[existingIdx] = result;
      } else {
        updated = [result, ...prev];
      }
      persist({ ...currentPayload(), results: updated });
      return updated;
    });
  };

  const deleteResult = (rollNo: string) => {
    setResults((prev) => {
      const updated = prev.filter((r) => r.rollNo !== rollNo);
      persist({ ...currentPayload(), results: updated });
      return updated;
    });
  };

  const updateRoutine = (dayIdx: number, updatedDay: ClassRoutineDay) => {
    setRoutines((prev) => {
      const updated = [...prev];
      updated[dayIdx] = updatedDay;
      persist({ ...currentPayload(), routines: updated });
      return updated;
    });
  };

  const updateFacility = (facility: Facility) => {
    setFacilities((prev) => {
      const updated = prev.map((f) => (f.id === facility.id ? facility : f));
      persist({ ...currentPayload(), facilities: updated });
      return updated;
    });
  };

  const addGalleryItem = (item: GalleryItem) => {
    setGallery((prev) => {
      const updated = [item, ...prev];
      persist({ ...currentPayload(), gallery: updated });
      return updated;
    });
  };

  const deleteGalleryItem = (id: string) => {
    setGallery((prev) => {
      const updated = prev.filter((g) => g.id !== id);
      persist({ ...currentPayload(), gallery: updated });
      return updated;
    });
  };

  const resetAllData = () => {
    setSchoolInfo(defaultSchoolInfo);
    setTeachers(defaultTeachersList);
    setCommittee(defaultCommittee);
    setNotices(defaultNotices);
    setResults(defaultResults);
    setRoutines(defaultRoutines);
    setFacilities(defaultFacilities);
    setGallery(defaultGallery);
    setThemeColor('emerald');
    try {
      localStorage.removeItem(LOCAL_STORAGE_KEY);
      localStorage.removeItem('kumhs_teacher_custom_photos');
    } catch (e) {
      console.error(e);
    }
  };

  const exportBackupJson = () => {
    return JSON.stringify(currentPayload(), null, 2);
  };

  const importBackupJson = (jsonString: string): boolean => {
    try {
      const parsed = JSON.parse(jsonString);
      if (parsed.schoolInfo) setSchoolInfo(parsed.schoolInfo);
      if (parsed.teachers) setTeachers(parsed.teachers);
      if (parsed.committee) setCommittee(parsed.committee);
      if (parsed.notices) setNotices(parsed.notices);
      if (parsed.results) setResults(parsed.results);
      if (parsed.routines) setRoutines(parsed.routines);
      if (parsed.facilities) setFacilities(parsed.facilities);
      if (parsed.gallery) setGallery(parsed.gallery);
      if (parsed.themeColor) setThemeColor(parsed.themeColor);
      persist(parsed);
      return true;
    } catch (e) {
      console.error('Import error:', e);
      return false;
    }
  };

  const handleSetThemeColor = (color: 'emerald' | 'navy' | 'maroon' | 'forest') => {
    setThemeColor(color);
    persist({ ...currentPayload(), themeColor: color });
  };

  return (
    <SchoolContext.Provider
      value={{
        schoolInfo,
        updateSchoolInfo,
        teachers,
        addTeacher,
        updateTeacher,
        deleteTeacher,
        committee,
        updateCommittee,
        notices,
        addNotice,
        updateNotice,
        deleteNotice,
        results,
        addOrUpdateResult,
        deleteResult,
        routines,
        updateRoutine,
        facilities,
        updateFacility,
        gallery,
        addGalleryItem,
        deleteGalleryItem,
        resetAllData,
        exportBackupJson,
        importBackupJson,
        themeColor,
        setThemeColor: handleSetThemeColor,
      }}
    >
      {children}
    </SchoolContext.Provider>
  );
};

export const useSchool = () => {
  const context = useContext(SchoolContext);
  if (!context) {
    throw new Error('useSchool must be used within a SchoolProvider');
  }
  return context;
};
