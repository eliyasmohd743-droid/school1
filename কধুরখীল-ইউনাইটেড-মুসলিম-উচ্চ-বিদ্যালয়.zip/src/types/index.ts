export interface Teacher {
  id: string;
  nameBn: string;
  nameEn: string;
  designationBn: string;
  designationEn: string;
  departmentBn: string;
  departmentEn: string;
  subjectBn: string;
  subjectEn: string;
  qualificationBn: string;
  qualificationEn: string;
  photoUrl: string;
  email: string;
  phone: string;
  bloodGroup: string;
  joinDate: string;
  bioBn: string;
  bioEn: string;
  isHeadmaster?: boolean;
  isAssistantHead?: boolean;
}

export interface CommitteeMember {
  id: string;
  nameBn: string;
  nameEn: string;
  roleBn: string;
  roleEn: string;
  occupationBn: string;
  photoUrl: string;
  phone?: string;
}

export interface Notice {
  id: string;
  titleBn: string;
  titleEn: string;
  category: 'academic' | 'exam' | 'admission' | 'holiday' | 'event';
  date: string;
  isUrgent?: boolean;
  summaryBn: string;
  summaryEn: string;
  contentBn: string;
  contentEn: string;
  downloadUrl?: string;
  authorBn: string;
}

export interface SubjectResult {
  code: string;
  subjectNameBn: string;
  subjectNameEn: string;
  totalMarks: number;
  obtainedMarks: number;
  letterGrade: string;
  gradePoint: number;
}

export interface StudentResult {
  rollNo: string;
  regNo: string;
  studentNameBn: string;
  studentNameEn: string;
  fatherNameBn: string;
  motherNameBn: string;
  classGrade: string; // e.g. "Class 10", "Class 9"
  section: string;
  group: 'Science' | 'Humanities' | 'Business Studies' | 'General';
  examType: 'Half-Yearly' | 'Annual' | 'Pre-Test' | 'Test (SSC)';
  examYear: string;
  gpa: number;
  overallGrade: string;
  resultStatus: 'Passed' | 'Failed';
  subjects: SubjectResult[];
}

export interface RoutinePeriod {
  period: number;
  time: string;
  subjectBn: string;
  subjectEn: string;
  teacherBn: string;
  teacherEn: string;
  room: string;
}

export interface ClassRoutineDay {
  dayBn: string;
  dayEn: string;
  periods: RoutinePeriod[];
}

export interface GalleryItem {
  id: string;
  titleBn: string;
  titleEn: string;
  category: 'campus' | 'academic' | 'sports' | 'national' | 'cultural';
  imageUrl: string;
  date: string;
  captionBn: string;
}

export interface Facility {
  id: string;
  titleBn: string;
  titleEn: string;
  descriptionBn: string;
  descriptionEn: string;
  imageUrl: string;
  features: string[];
}
