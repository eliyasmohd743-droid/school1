import React, { useState } from 'react';
import { SchoolProvider, useSchool } from './context/SchoolContext';
import { Navbar } from './components/Navbar';
import { NoticeTicker } from './components/NoticeTicker';
import { Hero } from './components/Hero';
import { HeadmasterMessage } from './components/HeadmasterMessage';
import { TeachersDirectory } from './components/TeachersDirectory';
import { ResultChecker } from './components/ResultChecker';
import { NoticeBoard } from './components/NoticeBoard';
import { ClassRoutine } from './components/ClassRoutine';
import { AdmissionPortal } from './components/AdmissionPortal';
import { CampusFacilities } from './components/CampusFacilities';
import { PhotoGallery } from './components/PhotoGallery';
import { GoogleMapsSection } from './components/GoogleMapsSection';
import { Footer } from './components/Footer';
import { AdminCustomizerModal } from './components/AdminCustomizerModal';
import { Notice } from './types';
import { Sliders, Sparkles } from 'lucide-react';

function SchoolWebsite() {
  const [lang, setLang] = useState<'bn' | 'en'>('bn');
  const [currentSection, setCurrentSection] = useState<string>('hero');
  const [activeNotice, setActiveNotice] = useState<Notice | null>(null);
  const [isAdmissionModalOpen, setIsAdmissionModalOpen] = useState<boolean>(false);
  const [isCustomizerOpen, setIsCustomizerOpen] = useState<boolean>(false);

  const handleToggleLang = () => {
    setLang((prev) => (prev === 'bn' ? 'en' : 'bn'));
  };

  const handleNavigate = (sectionId: string) => {
    setCurrentSection(sectionId);
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleOpenResults = () => {
    handleNavigate('results');
  };

  const handleOpenAdmissionModal = () => {
    setIsAdmissionModalOpen(true);
  };

  const handleCloseAdmissionModal = () => {
    setIsAdmissionModalOpen(false);
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-800 antialiased font-sans relative selection:bg-amber-300 selection:text-emerald-950">
      {/* Primary Navigation Bar */}
      <Navbar
        currentSection={currentSection}
        onNavigate={handleNavigate}
        lang={lang}
        onToggleLang={handleToggleLang}
        onOpenResultModal={handleOpenResults}
        onOpenAdmissionModal={handleOpenAdmissionModal}
        onOpenCustomizer={() => setIsCustomizerOpen(true)}
      />

      {/* Emergency & Latest Notice Ticker */}
      <NoticeTicker
        lang={lang}
        onSelectNotice={(notice) => setActiveNotice(notice)}
        onViewAllNotices={() => handleNavigate('notices')}
      />

      {/* Main Content Sections */}
      <main className="flex-1">
        <section id="hero">
          <Hero
            lang={lang}
            onOpenAdmission={handleOpenAdmissionModal}
            onOpenResults={handleOpenResults}
            onNavigateTeachers={() => handleNavigate('teachers')}
            onNavigateNotices={() => handleNavigate('notices')}
          />
        </section>

        {/* Headmaster and President's Message & History */}
        <HeadmasterMessage lang={lang} />

        {/* Teachers and Staff Directory with Photos */}
        <TeachersDirectory lang={lang} />

        {/* Interactive Student Result Portal & Official Marksheet */}
        <ResultChecker lang={lang} />

        {/* Notice Board & Circulars */}
        <NoticeBoard
          lang={lang}
          activeNotice={activeNotice}
          onSelectNotice={setActiveNotice}
        />

        {/* Daily Class Routine & Period Timetable */}
        <ClassRoutine lang={lang} />

        {/* Campus Facilities & Laboratories */}
        <CampusFacilities lang={lang} />

        {/* Admission Information & Online Application Form */}
        <AdmissionPortal lang={lang} />

        {/* Visual Gallery */}
        <PhotoGallery lang={lang} />

        {/* Google Maps, Travel Route Guide & Contact Desk */}
        <GoogleMapsSection lang={lang} />
      </main>

      {/* Online Admission Quick Modal */}
      {isAdmissionModalOpen && (
        <AdmissionPortal
          lang={lang}
          isModal={true}
          onCloseModal={handleCloseAdmissionModal}
        />
      )}

      {/* Full Live Website Customizer Modal */}
      <AdminCustomizerModal
        isOpen={isCustomizerOpen}
        onClose={() => setIsCustomizerOpen(false)}
        lang={lang}
      />

      {/* Floating Action Button for Instant Customization */}
      <aside aria-label="Quick Customizer Floating Button" className="fixed bottom-6 right-6 z-40 group no-print">
        <button
          onClick={() => setIsCustomizerOpen(true)}
          className="flex items-center gap-2.5 bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 hover:from-amber-400 hover:to-amber-300 text-slate-950 font-black px-4 sm:px-5 py-3 sm:py-3.5 rounded-full shadow-2xl border-2 border-white/90 hover:scale-105 active:scale-95 transition-all duration-200 cursor-pointer"
          title={lang === 'bn' ? 'ওয়েবসাইট সম্পূর্ণ কাস্টমাইজ করুন' : 'Fully Customize Website'}
        >
          <Sliders size={20} className="animate-spin-slow text-emerald-950" />
          <span className="font-bengali-serif text-xs sm:text-sm tracking-wide">
            {lang === 'bn' ? 'কাস্টমাইজ করুন' : 'Customize Website'}
          </span>
          <span className="flex h-2.5 w-2.5 relative">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-600 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-800"></span>
          </span>
        </button>
      </aside>

      {/* Institutional Footer */}
      <Footer lang={lang} onNavigate={handleNavigate} />
    </div>
  );
}

export default function App() {
  return (
    <SchoolProvider>
      <SchoolWebsite />
    </SchoolProvider>
  );
}
